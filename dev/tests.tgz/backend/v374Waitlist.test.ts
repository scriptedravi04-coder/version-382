// v374 (Ravi): live + pending creators on top of the waitlist, Instagram / contact filters, fetch only new usernames,
// keep part of Meta's hourly limit for sign-ups, auto refresh every 7 days by cron, eye button on the sign-up password.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { makeBudget } from "./instagramAutofill";
import { usageFromHeaders } from "./instagramConnect";
import { waitlistIgState, waitlistContacts, waitlistOrder } from "../src/components/admin/WaitlistManager";

const read = (f: string) => fs.readFileSync(path.join(__dirname, "..", f), "utf8");

describe("v374 · waitlist order and filters", () => {
  const rows = [
    { id: "a", status: "Approved", ig_followers: 900000 },
    { id: "b", status: "Pending", ig_error: "Personal or private account" },
    { id: "c", status: "Pending" },
    { id: "d", status: "Pending", ig_followers: 6400 },
    { id: "e", status: "Rejected", ig_followers: 5 },
    { id: "f", status: "Pending", ig_followers: 846900 },
  ];
  it("pending + live first (most followers), then not fetched, then private, approved, rejected", () => {
    expect([...rows].sort(waitlistOrder).map((r) => r.id)).toEqual(["f", "d", "c", "b", "a", "e"]);
  });
  it("Instagram state and contacts", () => {
    expect(rows.map(waitlistIgState)).toEqual(["live", "failed", "none", "live", "live", "live"]);
    expect(waitlistContacts({ handle: "riya", email: "unclaimed_x@ybex.io" })).toEqual({ email: false, mobile: false, username: true });
    expect(waitlistContacts({ handle: "riya", email: "riya@gmail.com", phone: "+91 98765 43210" })).toEqual({ email: true, mobile: true, username: false });
  });
  it("filters are on the screen", () => {
    const s = read("src/components/admin/WaitlistManager.jsx");
    expect(s).toContain('data-testid="wl-ig-filter"');
    expect(s).toContain('data-testid="wl-contact-filter"');
    expect(s).toContain("filteredItems.sort(sortBy === 'followers' ? waitlistOrder : waitlistNewestOrder)") // v402: Ravi made newest-first the default;
  });
});

describe("v374 · Instagram budget kept for sign-ups", () => {
  it("background waits once only the reserve is left; people can still use it", () => {
    const b = makeBudget(5, 1000);
    for (let i = 0; i < 3; i++) b.take(i);
    expect(b.waitMs(10, 2)).toBe(1000 - 10); // 3 used, 2 kept → background waits for the first to age out
    expect(b.waitMs(10)).toBe(0); // a sign-up still fits
    expect(b.take(11)).toBe(true);
  });
  it("reads Meta's usage header", () => {
    const h: Record<string, string> = { "x-app-usage": JSON.stringify({ call_count: 72, total_time: 10 }) };
    expect(usageFromHeaders((k) => h[k])).toBe(72);
    const bu: Record<string, string> = { "x-business-use-case-usage": JSON.stringify({ "123": [{ call_count: 12, total_cputime: 81 }] }) };
    expect(usageFromHeaders((k) => bu[k])).toBe(81);
    expect(usageFromHeaders(() => null)).toBeNull();
  });
  it("Fetch button = new usernames only; cron refreshes in the background share", () => {
    const s = read("backend/instagramConnect.ts");
    expect(s).toContain('mode: "new" | "old" | "since" = since ? "since" : req.body?.mode === "old" ? "old" : "new"');
    expect(s).toContain('router.post("/internal/cron/instagram-refresh"');
    expect(s).toContain("cronAuthorized(req.headers[\"x-cron-secret\"])");
    expect(read("src/components/admin/AdminInstagramBulkFetch.jsx")).toContain('mode: force ? "old" : "new"');
  });
});

describe("v374 · sign-up password eye", () => {
  // v376 (Ravi): no password at sign-up any more (set later in Settings), so the sign-up eye button went with it.
  it("sign-up has no password box (v376); the login password box keeps its eye", () => {
    const src = read("src/pages/app/AppContinue.jsx");
    expect(src).not.toContain('data-testid="app-signup-password"');
    expect(src).toContain('aria-label={showPass ? "Hide password" : "Show password"}');
  });
});
