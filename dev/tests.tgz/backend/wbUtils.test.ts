// White-box tests: age gate, crash-safe ₹ formatting, brief payment retry storage, support ticket payload,
// creator home picks, legal copy, refund accounts, agreement text, invite budget parsing.
// Tests marked it.fails document a real bug in the CURRENT code (see the "BUG:" comment above each).
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("../src/lib/api", () => ({ api: { post: vi.fn(async (_p: string, body: any) => ({ data: { paid: body.order_id === "paid_1" } })) } }));

import { ageFromDob, isUnder18 } from "../src/lib/age";
import safe, { toNumber, formatAmount, formatINR, formatINROrDash, safeUpper, safeLower, safeArray, safeJsonParse } from "../src/utils/safeFormat";
import {
  getPaidBriefOrder, savePaidBriefOrder, clearPaidBriefOrder, savePendingBriefOrder, recoverPendingBriefOrder,
  FINAL_ORDER_CODES, BRIEF_POSTED_PATH, markBriefPosted, takeRecentBriefPost, watchPaidOrder, checkBriefOrderPaid, goToPostedBriefs,
} from "../src/lib/briefPaymentRetry";
import { ORDER_TICKET_CATEGORIES, buildOrderTicketPayload, raiseOrderTicket } from "../src/components/chat/orderTicket";
import { toHomePick, isShowableCreator, autoHomePicks, landingCreatorCards, HOME_PICKS_MAX } from "./creatorHomePicks";
import { LEGAL, LEGAL_LINKS, PUBLIC_TERMS, REFUND_POLICY, PRIVACY_POLICY, IN_APP_CARDS, roleTermsPage } from "../src/lib/legal/legalContent";
import { parseRefundAccount, toPublicRefundAccount, toAdminRefundSnapshot } from "./ugcRefundAccounts";
import { toBrandRefund } from "./campaignRefunds";
import { refundMessageLine } from "./refunds";
import { campaignAgreement, ugcAgreement, agreementPlainText, asCaptureSource, POST_LIVE_DAYS } from "../src/lib/agreementTerms";
import { getDeliverablesCount, formatBudget } from "../src/utils/invitationUtils";
import { parseInviteBudget, inviteAmount, MIN_INVITE_AMOUNT } from "./directInvites";

describe("age gate (18+)", () => {
  const now = new Date("2026-10-19T12:00:00Z");
  it("whole years; birthday boundary", () => {
    expect(ageFromDob("19", "10", "2008", now)).toBe(18);
    expect(ageFromDob(20, 10, 2008, now)).toBe(17);
    expect(isUnder18(20, 10, 2008, now)).toBe(true);
    expect(isUnder18(19, 10, 2008, now)).toBe(false);
  });
  it("rejects impossible dates and short years; invalid → not 'under 18'", () => {
    expect(ageFromDob(31, 2, 2000, now)).toBeNull();
    expect(ageFromDob(29, 2, 2001, now)).toBeNull();
    expect(ageFromDob(29, 2, 2004, now)).toBe(22);
    expect(ageFromDob(1, 1, "08", now)).toBeNull();
    expect(ageFromDob(0, 1, 2000, now)).toBeNull();
    expect(ageFromDob(1, 1, 2030, now)).toBeNull(); // future
    expect(ageFromDob(1, 1, 1800, now)).toBeNull(); // > 120
    expect(isUnder18("", "", "", now)).toBe(false);
  });
  // BUG (low): the age is worked out on the UTC calendar. Between 00:00 and 05:29 IST on an Indian user's 18th
  // birthday the app still says they are 17 and blocks onboarding ("You must be 18+"). Fix (age.js:8-9): compare
  // against the IST date (new Date(now.getTime() + 5.5*3600e3) and its getUTC* fields).
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("turning 18 at 00:30 IST counts as 18 in India", () => {
    const istHalfPastMidnight = new Date("2026-10-19T19:00:00Z"); // 20 Oct 00:30 IST
    expect(ageFromDob(20, 10, 2008, istHalfPastMidnight)).toBe(18);
  });
});

describe("safeFormat", () => {
  it("toNumber handles ₹, commas, negatives, junk", () => {
    expect(toNumber("₹1,50,000")).toBe(150000);
    expect(toNumber("-₹500")).toBe(-500);
    expect(toNumber(NaN, 7)).toBe(7);
    expect(toNumber(Infinity, 7)).toBe(7);
    expect(toNumber(null, 3)).toBe(3);
    expect(toNumber("1.2.3", 9)).toBe(9);
    expect(toNumber({}, 4)).toBe(4);
  });
  it("Indian grouping, never throws", () => {
    expect(formatAmount(150000)).toBe("1,50,000");
    expect(formatINR(undefined)).toBe("₹0");
    expect(formatINR("12345.5")).toBe("₹12,345.5");
    expect(formatINROrDash(null)).toBe("—");
    expect(formatINROrDash("")).toBe("—");
    expect(formatINROrDash(0)).toBe("₹0");
  });
  // BUG (low): formatINROrDash exists so an unknown amount shows "—" instead of "₹0 (free)", but toNumber("")
  // after stripping is Number("") = 0, so "N/A", "TBD", "abc" all render "₹0". Fix (safeFormat.js:33-35):
  // return fallback when `cleaned` has no digit.
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("formatINROrDash: a non-numeric string shows a dash, not ₹0", () => {
    expect(formatINROrDash("N/A")).toBe("—");
  });
  it("case + array + json helpers", () => {
    expect(safeUpper(5)).toBe("5");
    expect(safeUpper(null, "X")).toBe("X");
    expect(safeLower(undefined)).toBe("");
    expect(safeArray("x")).toEqual([]);
    expect(safeJsonParse("{bad")).toBeNull();
    expect(safeJsonParse('{"a":1}')).toEqual({ a: 1 });
    const o = { a: 1 };
    expect(safeJsonParse(o)).toBe(o);
    expect(safe.formatINR(1)).toBe("₹1");
  });
});

describe("briefPaymentRetry (device storage, tied to the signed-in brand)", () => {
  beforeEach(() => { localStorage.clear(); sessionStorage.clear(); localStorage.setItem("ybex_user", JSON.stringify({ user_id: "brandA" })); });
  afterEach(() => { vi.useRealTimers(); });

  it("paid order is kept for the same brand only, and cleared", () => {
    savePaidBriefOrder("order_1", "1500");
    expect(getPaidBriefOrder()).toMatchObject({ order_id: "order_1", amount: 1500, user_id: "brandA" });
    localStorage.setItem("ybex_user", JSON.stringify({ user_id: "brandB" }));
    expect(getPaidBriefOrder()).toBeNull();
    clearPaidBriefOrder();
    localStorage.setItem("ybex_user", JSON.stringify({ user_id: "brandA" }));
    expect(getPaidBriefOrder()).toBeNull();
    savePaidBriefOrder("", 5);
    expect(getPaidBriefOrder()).toBeNull();
    localStorage.setItem("ugc_paid_order", "{not json");
    expect(getPaidBriefOrder()).toBeNull();
  });

  it("recoverPendingBriefOrder: paid → becomes the paid order; unpaid → forgotten; error → kept; old → forgotten", async () => {
    const now = Date.now();
    savePendingBriefOrder("o1", 100);
    expect(await recoverPendingBriefOrder(async () => true, now)).toBe("o1");
    expect(getPaidBriefOrder()?.order_id).toBe("o1");
    expect(localStorage.getItem("ugc_pending_order")).toBeNull();

    savePendingBriefOrder("o2", 100);
    expect(await recoverPendingBriefOrder(async () => { throw new Error("net"); }, now)).toBeNull();
    expect(localStorage.getItem("ugc_pending_order")).not.toBeNull();
    expect(await recoverPendingBriefOrder(async () => false, now)).toBeNull();
    expect(localStorage.getItem("ugc_pending_order")).toBeNull();

    savePendingBriefOrder("o3", 100);
    expect(await recoverPendingBriefOrder(async () => true, now + 25 * 3600e3)).toBeNull();
    expect(await recoverPendingBriefOrder(async () => true, now)).toBeNull(); // nothing left
  });

  it("posted flag: true once within the window", () => {
    markBriefPosted(1000);
    expect(takeRecentBriefPost(60000, 2000)).toBe(true);
    expect(takeRecentBriefPost(60000, 2000)).toBe(false);
    markBriefPosted(1000);
    expect(takeRecentBriefPost(60000, 1000 + 60001)).toBe(false);
    markBriefPosted(5000);
    expect(takeRecentBriefPost(60000, 4000)).toBe(false); // clock went back
    expect(FINAL_ORDER_CODES).toContain("PAYMENT_TOO_LOW");
    expect(BRIEF_POSTED_PATH).toMatch(/^\/brand\/ugc\/briefs/);
  });

  it("watchPaidOrder: calls onPaid once, survives transient errors, stops after maxMs or stop()", async () => {
    vi.useFakeTimers();
    let n = 0;
    const onPaid = vi.fn();
    watchPaidOrder(async () => { n++; if (n === 1) throw new Error("x"); return n >= 3; }, "o", onPaid, { startAfterMs: 10, intervalMs: 10, maxMs: 1000 });
    await vi.advanceTimersByTimeAsync(100);
    expect(onPaid).toHaveBeenCalledTimes(1);
    expect(n).toBe(3);

    const never = vi.fn(async () => false);
    const stop = watchPaidOrder(never, "o", onPaid, { startAfterMs: 10, intervalMs: 10, maxMs: 1000 });
    await vi.advanceTimersByTimeAsync(35);
    stop();
    const calls = never.mock.calls.length;
    await vi.advanceTimersByTimeAsync(100);
    expect(never.mock.calls.length).toBe(calls);
    expect(typeof watchPaidOrder(null as any, "o", onPaid)).toBe("function");
    expect(typeof watchPaidOrder(never, "", onPaid)).toBe("function");
  });

  it("checkBriefOrderPaid asks the server; goToPostedBriefs navigates and marks the post", async () => {
    expect(await checkBriefOrderPaid("paid_1")).toBe(true);
    expect(await checkBriefOrderPaid("other")).toBe(false);
    vi.useFakeTimers();
    const nav = vi.fn();
    goToPostedBriefs(nav, { settleMs: 5, fallbackMs: 10 });
    expect(nav).toHaveBeenCalledWith(BRIEF_POSTED_PATH);
    await vi.advanceTimersByTimeAsync(20);
    expect(takeRecentBriefPost()).toBe(true);
  });
});

describe("orderTicket", () => {
  it("payload carries order id, amount and both parties; never crashes on a bare thread", () => {
    const p = buildOrderTicketPayload({ thread: { deal_id: 12345678901, agreed_amount: 5000, brand: { name: "B", phone_number: "9" }, creator_name: "C" }, threadId: "t", category: "X", message: "  help " });
    expect(p.order_id).toBe("12345678901");
    expect(p.subject).toContain("#12345678");
    expect(p.deal_amount).toBe(5000);
    expect(p.message).toBe("help");
    expect(p.brand_details.phone).toBe("9");
    expect(p.creator_details.name).toBe("C");
    const bare = buildOrderTicketPayload({ thread: null, threadId: undefined, category: "x", message: null } as any);
    expect(bare.order_id).toBe("ORD-PENDING");
    expect(ORDER_TICKET_CATEGORIES.brand.length).toBeGreaterThan(0);
  });
  it("raiseOrderTicket returns the server id or null, never invents one", async () => {
    expect(await raiseOrderTicket({ post: async () => ({ data: { ticket: { ticket_id: "T1" } } }) }, { thread: {}, threadId: "t" })).toBe("T1");
    expect(await raiseOrderTicket({ post: async () => ({}) }, { thread: {}, threadId: "t" })).toBeNull();
  });
});

describe("creatorHomePicks (public cards)", () => {
  const ok = (o: any) => ({ user_id: "u", name: "Asha", profile_status: "approved", ...o });
  it("only public fields; followers summed", () => {
    const c = toHomePick(ok({ email: "e", phone: "p", followers_instagram: "100", followers_youtube: 50, rate_reel: 9 }));
    expect(Object.keys(c).sort()).toEqual(["avg_reach", "category", "city", "followers", "id", "name", "picture"]);
    expect(c.followers).toBe(150);
  });
  it("hides test / bypass / unapproved / deleted / one-letter names", () => {
    expect(isShowableCreator(ok({}))).toBe(true);
    expect(isShowableCreator(ok({ name: "Test user" }))).toBe(false);
    expect(isShowableCreator(ok({ instagram_handle: "x_dev_bypass" }))).toBe(false);
    expect(isShowableCreator(ok({ profile_status: "pending" }))).toBe(false);
    expect(isShowableCreator(ok({ is_deleted: true }))).toBe(false);
    expect(isShowableCreator(ok({ name: "c" }))).toBe(false);
    expect(isShowableCreator(null)).toBe(false);
  });
  it("auto picks: photo first, then followers; never the viewer; capped", () => {
    const rows = [
      ok({ user_id: "a", followers_instagram: 900 }),
      ok({ user_id: "b", picture: "p", followers_instagram: 10 }),
      ok({ user_id: "me", picture: "p", followers_instagram: 1e6 }),
      ok({ user_id: "c", picture: "p", followers_instagram: 500 }),
      ...Array.from({ length: 5 }, (_, i) => ok({ user_id: `x${i}` })),
    ];
    const picks = autoHomePicks(rows, "me").map((p) => p.user_id);
    expect(picks.slice(0, 3)).toEqual(["c", "b", "a"]);
    expect(picks.length).toBe(HOME_PICKS_MAX);
    expect(autoHomePicks(null as any, "me")).toEqual([]);
  });
  it("landing wall: only http(s) or site-relative photos", () => {
    const r = landingCreatorCards([ok({ user_id: "a", picture: "https://x/p.jpg" }), ok({ user_id: "b", picture: "javascript:alert(1)" }), ok({ user_id: "c", photo: "/img/c.jpg" })]);
    expect(r.map((x) => x.id)).toEqual(["a", "c"]);
  });
});

describe("legal copy", () => {
  it("links, versions and role pages are consistent", () => {
    expect(LEGAL.emails.grievance).toMatch(/@ybexmedia\.in$/);
    expect(Object.values(LEGAL_LINKS).every((l) => l.startsWith("/"))).toBe(true);
    for (const page of [PUBLIC_TERMS, REFUND_POLICY, PRIVACY_POLICY]) {
      expect(page.title.length).toBeGreaterThan(0);
      expect(page.sections.length).toBeGreaterThan(0);
    }
    const creator = roleTermsPage("creator");
    const brand = roleTermsPage("brand");
    expect(creator.title).toBe("Creator Terms");
    expect(brand.title).toBe("Brand Terms");
    const common = IN_APP_CARDS.filter((c) => c.role === "common").length;
    expect(creator.sections.length).toBe(common + IN_APP_CARDS.filter((c) => c.role === "creator").length);
    expect(brand.sections.length).toBe(common + IN_APP_CARDS.filter((c) => c.role === "brand").length);
    expect(LEGAL.termsChanges[0]).toContain(`v${LEGAL.termsVersion}`);
  });
});

describe("agreement text", () => {
  it("campaign agreement: fee, revisions (0 → 'None'), live days, fee & TDS deduction disclosed", () => {
    const a = campaignAgreement({ amount: 15000, revisions: 0 } as any);
    expect(a.keyPoints.find((k) => k.label === "Agreed fee")!.value).toBe("₹15,000");
    expect(a.keyPoints.find((k) => k.label === "Revisions")!.value).toBe("None");
    const text = agreementPlainText(a);
    expect(text).toContain(`${POST_LIVE_DAYS} days`);
    expect(text).toContain("Convenience fee & TDS");
    expect(asCaptureSource(a).innerText).toBe(text);
    expect(agreementPlainText(null)).toBe("");
    expect(campaignAgreement().keyPoints[0].value).toBe("₹0");
  });
  it("UGC agreement: payout, hours, revisions", () => {
    const u = ugcAgreement({ payout: 2000, hours: 48, revisions: 3 } as any);
    const t = agreementPlainText(u);
    expect(t).toContain("₹2,000");
    expect(t).toContain("48 hours");
    expect(t).toContain("Up to 3");
  });
  // BUG (money / contract text): the UGC agreement the creator signs says "₹X is held … and released to the
  // Creator's bank or UPI" and mentions only TDS, but the server deducts the platform / convenience fee (+GST)
  // from UGC payouts too (ugcLifecycleService feeAtPaymentTime → creator_net_amount). A creator who signs for
  // ₹10,000 receives ₹8,500. The campaign agreement already discloses "Convenience fee & TDS". Fix
  // (agreementTerms.js:68): same wording as the campaign clause ("The Convenience fee & TDS … are deducted as shown").
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("UGC agreement discloses the fee deducted from the payout", () => {
    expect(agreementPlainText(ugcAgreement({ payout: 10000 } as any))).toMatch(/convenience fee|platform fee/i);
  });
});

describe("refund helpers", () => {
  it("parseRefundAccount: UPI / bank validation", () => {
    expect(parseRefundAccount({ upi_id: "brand@okhdfc" }).row?.method_type).toBe("UPI");
    expect(parseRefundAccount({ method_type: "upi", upi_id: "bad" }).error).toBeTruthy();
    expect(parseRefundAccount({ method_type: "card" } as any).error).toBe("Choose UPI or bank account.");
    const ok = parseRefundAccount({ method_type: "BANK", account_details: { account_no: "1234 5678 9012", confirm_account_no: "123456789012", ifsc: "hdfc0001234", holder_name: "Acme" } });
    expect(ok.row).toMatchObject({ bank_account_number: "123456789012", bank_ifsc: "HDFC0001234" });
    expect(parseRefundAccount({ method_type: "BANK", bank_account_number: "123456789", bank_account_confirm: "123456788", bank_ifsc: "HDFC0001234", account_holder_name: "AB" }).error).toMatch(/match/);
    expect(parseRefundAccount({ method_type: "BANK", bank_account_number: "12345678", bank_ifsc: "HDFC0001234", account_holder_name: "AB" }).error).toMatch(/9 to 18/);
    expect(parseRefundAccount({ method_type: "BANK", bank_account_number: "123456789", bank_ifsc: "HDFC1001234", account_holder_name: "AB" }).error).toMatch(/IFSC/);
    expect(parseRefundAccount({ method_type: "BANK", bank_account_number: "123456789", bank_ifsc: "HDFC0001234", account_holder_name: "A" }).error).toMatch(/holder/);
    expect(parseRefundAccount(null as any).error).toBeTruthy();
  });
  it("public view never carries the full account number; admin snapshot does", () => {
    const m = { id: "1", method_type: "BANK", bank_account_number: "123456789012", bank_ifsc: "HDFC0001234" };
    const pub = toPublicRefundAccount(m)!;
    expect(JSON.stringify(pub)).not.toContain("123456789012");
    expect(pub.account_last4).toBe("9012");
    expect(toPublicRefundAccount({ upi_id: "brand@okhdfc" })!.upi_id).toBe("br***@okhdfc");
    expect(toAdminRefundSnapshot(m)!.bank_account_number).toBe("123456789012");
    expect(toPublicRefundAccount(null)).toBeNull();
    expect(toAdminRefundSnapshot(null)).toBeNull();
  });
  it("toBrandRefund: UTR shown only once PROCESSED", () => {
    expect(toBrandRefund({ id: "t", refund_amount: "500", refund_status: "pending", refund_reference: "U" })).toMatchObject({ amount: 500, status: "PENDING", reference: null });
    expect(toBrandRefund({ id: "t", campaign_deal_id: "d", refund_status: "processed", refund_reference: "U" })).toMatchObject({ deal_id: "d", reference: "U" });
  });
  it("refundMessageLine is true to what happened", () => {
    expect(refundMessageLine({ refund_status: "PROCESSED" } as any, 1500)).toContain("has been sent");
    expect(refundMessageLine({ refund_status: "PENDING" } as any, undefined as any)).toContain("₹0 is due");
  });
});

describe("invite budget parsing", () => {
  it("plain amounts", () => {
    expect(parseInviteBudget(15000)).toBe(15000);
    expect(parseInviteBudget("₹15,000")).toBe(15000);
    expect(parseInviteBudget(-5)).toBe(0);
    expect(parseInviteBudget(null)).toBe(0);
    expect(parseInviteBudget("Barter Friendly")).toBe(0);
    expect(inviteAmount({ amount: 0, proposed_budget: "", budget_range: "₹3,000" })).toBe(MIN_INVITE_AMOUNT);
    expect(inviteAmount(null)).toBe(0);
  });
  // BUG (money): every digit in the text is glued together. The desktop invite box is free text ("e.g. 54,903 or
  // ₹15,000"); a brand typing "15000 + 18% GST" creates an invite — and, when the creator accepts, a campaign deal
  // with agreed_amount ₹15,00,018; "10,000-15,000" becomes ₹1,00,00,15,000. The creator then signs an agreement for
  // that amount. Fix (directInvites.ts:20): take the FIRST number only:
  // const m = String(raw ?? "").replace(/,/g, "").match(/\d+(\.\d+)?/); n = m ? Number(m[0]) : 0.
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("'15000 + 18% GST' is ₹15,000, not ₹15,00,018", () => {
    expect(parseInviteBudget("15000 + 18% GST")).toBe(15000);
  });
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("a range '10,000-15,000' never becomes ₹100 crore", () => {
    expect(parseInviteBudget("10,000-15,000")).toBeLessThanOrEqual(15000);
  });
  it("frontend formatBudget / getDeliverablesCount", () => {
    expect(formatBudget(null)).toBe("Negotiable");
    expect(formatBudget(0)).toBe("₹0");
    expect(formatBudget("Barter")).toBe("Barter");
    expect(formatBudget("15000")).toBe("₹15,000");
    expect(getDeliverablesCount("1 Dedicated Reel + 2 Stories")).toBe(3);
    expect(getDeliverablesCount("Reel, Story; Post")).toBe(3);
    expect(getDeliverablesCount(0)).toBe(1);
    expect(getDeliverablesCount(4)).toBe(4);
    expect(getDeliverablesCount("100 reels")).toBe(1);
    expect(getDeliverablesCount("  ")).toBe(1);
  });
  // BUG (display, same root cause as parseInviteBudget): the creator's invitation card shows "₹1,00,00,15,000"
  // for a "10000-15000" budget. Fix (invitationUtils.js:27): first number only, or show the raw range text.
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("formatBudget keeps a range readable", () => {
    expect(formatBudget("10000-15000")).not.toBe("₹1,00,00,15,000");
  });
});
