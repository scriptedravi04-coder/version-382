import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "fs";
import { sign, validEntries, numberEntries, parsePortfolio } from "./challenge_routes";
import {
  CHALLENGE_ID, ENTRIES_CLOSE_AT, STARTS_AT, RESULTS_AT, MAX_ENTRIES, phaseAt, isEntryLink, qualifies, brandIsYbex,
  captionHasTag, stampMessage, rankMessage, countdown, daysLeftText,
} from "../src/lib/diwaliChallenge";
import { finalizeItem, mediaToPending, toSaved } from "../src/components/portfolio/portfolioModel";

const read = (p: string) => readFileSync(p, "utf8");
const at = (ms: number) => new Date(ms).toISOString();
const entry = (uid: string, id: string, url: string, when = STARTS_AT + 3600_000, extra: any = {}) => {
  const a = at(when);
  return JSON.stringify({ id, content_url: url, brand_name: "Ybex", challenge: CHALLENGE_ID, challenge_at: a, challenge_sig: sign(stampMessage(uid, id, a)), ...extra });
};
const REEL = (c: string) => `https://www.instagram.com/reel/${c}/`;

describe("v367 · Diwali Challenge rules", () => {
  it("default dates: open till 15 Nov 23:59 IST (Admin can change), results 18 Nov", () => {
    expect(new Date(ENTRIES_CLOSE_AT).toISOString()).toBe("2026-11-15T18:29:59.000Z");
    expect(phaseAt(STARTS_AT - 1)).toBe("soon");
    expect(phaseAt(STARTS_AT + 1)).toBe("open");
    expect(phaseAt(ENTRIES_CLOSE_AT + 1000)).toBe("judging");
    expect(phaseAt(RESULTS_AT + 1)).toBe("results");
    expect(MAX_ENTRIES).toBe(3);
  });
  it("only instagram.com/reel or /p links count", () => {
    expect(isEntryLink("https://www.instagram.com/reel/Cabc123/")).toBe(true);
    expect(isEntryLink("https://instagram.com/p/Cabc123")).toBe(true);
    expect(isEntryLink("https://youtube.com/watch?v=abcdef")).toBe(false);
    expect(isEntryLink("https://www.instagram.com/elite_ravi/")).toBe(false);
  });
  it("toggle shows for brand Ybex or the hashtag / mention in the caption", () => {
    expect(brandIsYbex("Ybex")).toBe(true);
    expect(brandIsYbex("@ybex.in")).toBe(true);
    expect(brandIsYbex("Lenskart")).toBe(false);
    expect(captionHasTag("new reel\n#ybexdiwalichallenge")).toBe(true);
    expect(captionHasTag("collab with @ybex.in")).toBe(true);
    expect(captionHasTag("email me at ravi@ybex.in.co")).toBe(false);
    expect(qualifies("Lenskart", ["hi #YbexDiwaliChallenge"])).toBe(true);
    // v377 (Ravi, "Diwali Challenge v2"): ANY reel of the creator's own can be entered — the toggle shows for every reel;
    // the tags are checked by the admin review (captionChecks) instead.
    expect(qualifies("Lenskart", ["hi"])).toBe(true);
  });
  it("countdown + days left", () => {
    expect(countdown(90061000)).toEqual({ d: 1, h: 1, m: 1, s: 1 });
    expect(daysLeftText(ENTRIES_CLOSE_AT - 3 * 86400_000 - 10)).toBe("3 days left");
    expect(daysLeftText(ENTRIES_CLOSE_AT + 10)).toBe("");
  });
});

describe("v367 · signed entries in the portfolio JSON", () => {
  it("a valid signed stamp counts; a forged one does not", () => {
    const list = [entry("u1", "pf_a", REEL("AAAAA1")), JSON.stringify({ id: "pf_b", content_url: REEL("BBBBB1"), challenge: CHALLENGE_ID, challenge_at: at(STARTS_AT + 10), challenge_sig: "forged" })];
    const v = validEntries("u1", list);
    expect(v.map((e) => e.id)).toEqual(["pf_a"]);
    // a stamp copied to another creator's profile does not count there
    expect(validEntries("u2", list)).toEqual([]);
  });
  it("after the deadline, non-Instagram links, duplicates and past 3 are ignored", () => {
    const list = [
      entry("u1", "a", REEL("AAAAA1"), STARTS_AT + 1000),
      entry("u1", "b", REEL("AAAAA1"), STARTS_AT + 2000), // same reel twice
      entry("u1", "c", "https://youtu.be/xyzxyz", STARTS_AT + 3000),
      entry("u1", "d", REEL("DDDDD1"), STARTS_AT + 4000),
      entry("u1", "e", REEL("EEEEE1"), STARTS_AT + 5000),
      entry("u1", "f", REEL("FFFFF1"), STARTS_AT + 6000), // 4th valid one
      entry("u1", "g", REEL("GGGGG1"), ENTRIES_CLOSE_AT + 1000),
    ];
    expect(validEntries("u1", list).map((e) => e.id)).toEqual(["a", "d", "e"]);
  });
  it("winner rank needs its own signature", () => {
    const good = entry("u1", "a", REEL("AAAAA1"), STARTS_AT + 1000, { challenge_rank: "1st", challenge_rank_sig: sign(rankMessage("u1", "a", "1st")) });
    const fake = entry("u2", "z", REEL("ZZZZZ1"), STARTS_AT + 2000, { challenge_rank: "1st", challenge_rank_sig: "nope" });
    const all = numberEntries([{ user_id: "u1", name: "Ravi", instagram: "https://instagram.com/elite_ravi", portfolio: [good] }, { user_id: "u2", portfolio: [fake] }]);
    expect(all.map((e) => [e.no, e.user_id, e.rank])).toEqual([[1, "u1", "1st"], [2, "u2", null]]);
    expect(all[0].handle).toBe("elite_ravi");
  });
  it("parses string and object portfolio entries, skips junk", () => {
    expect(parsePortfolio(["https://x.com", "{bad", { id: 1 }, '{"id":"a"}']).filter(Boolean)).toEqual([{ id: 1 }, { id: "a" }]);
  });
  it("the stamp is saved with the item; UI keys are not", () => {
    const p = { ...mediaToPending({ id: "1", permalink: REEL("AAAAA1"), caption: "line one\n#YbexDiwaliChallenge" }), enter: true, stamp: { challenge: CHALLENGE_ID, challenge_at: "x", challenge_sig: "y" } };
    expect(p.challenge_hit).toBe(true);
    const saved = toSaved([finalizeItem(p, "Ybex")])[0] as any;
    expect(saved.challenge).toBe(CHALLENGE_ID);
    expect(saved.challenge_sig).toBe("y");
    expect(saved.enter).toBeUndefined();
    expect(saved.challenge_hit).toBeUndefined();
  });
});

describe("v367 · wiring", () => {
  it("routes, page, admin tab, version", () => {
    expect(read("backend/server.ts")).toContain("setupChallengeRoutes(router");
    expect(read("src/App.jsx")).toContain('path="/challenge"');
    expect(read("src/pages/admin/Admin.jsx")).toContain("case 'challenge':");
    expect(read("src/lib/appVersion.js")).toMatch(/const BUILT_IN = "v(3(6[7-9]|[7-9]\d)|[4-9]\d\d)"/);
    expect(existsSync("public/challenge-hero.webp")).toBe(true);
  });
  it("screens make no direct api calls (calls live in src/lib/challengeApi.js)", () => {
    for (const f of ["src/pages/ChallengePage.jsx", "src/components/challenge/ChallengeUi.jsx", "src/components/admin/AdminChallengeEntries.jsx", "src/pages/creator/profileScreens/PortfolioScreen.jsx"]) {
      expect(read(f), f).not.toMatch(/\bapi\.(get|post|put|patch|delete)\(/);
    }
  });
  it("no new table: entries live in creator_profiles.portfolio", () => {
    const src = read("backend/challenge_routes.ts");
    // v377: + reads the existing users table (WhatsApp / email for the review list and "no reel yet") — still no new table
    expect(src.match(/\.from\("([a-z_]+)"\)/g)?.every((m) => m.includes("creator_profiles") || m.includes('"users"'))).toBe(true);
  });
  it("the locked portfolio save route is untouched (no challenge code in creators_routes.ts)", () => {
    expect(read("backend/creators_routes.ts")).not.toContain("challenge");
  });
});

describe("v368 · offer links in banners and popups", () => {
  it("/offer opens the current offer; both pickers list it", async () => {
    const app = read("src/App.jsx");
    expect(app).toContain('path="/offer"');
    expect(app).toContain('path="/challenge"');
    const { APP_PAGES } = await import("../src/components/admin/AdminPromoPopups");
    const offers = APP_PAGES.find((g: any) => g.group === "Offers");
    expect(offers.items.map((i: any) => i[1])).toEqual(["/offer", "/creator/settings?section=portfolio&add=1&diwali=1"]); // v377
    const banner = read("src/components/admin/BannerManager.jsx");
    expect(banner).toContain("APP_PAGES");
    expect(banner).toContain("toAppPath(e.target.value)");
  });
});

import { datesFrom, dayText, dayTimeText, challengeOn } from "../src/lib/diwaliChallenge";
import { cleanConfig } from "./challenge_routes";
describe("v369 · dates from Admin", () => {
  it("valid admin dates are used; wrong ones fall back to the defaults", () => {
    const c = Date.parse("2026-11-20T18:29:59Z"), r = Date.parse("2026-11-22T18:30:00Z");
    expect(datesFrom({ closes_at: new Date(c).toISOString(), results_at: new Date(r).toISOString() })).toMatchObject({ closesAt: c, resultsAt: r });
    expect(datesFrom({ closes_at: "2025-01-01" }).closesAt).toBe(ENTRIES_CLOSE_AT); // before the start
    expect(datesFrom({ closes_at: "2027-09-01T00:00:00Z" }).closesAt).toBe(ENTRIES_CLOSE_AT); // > 120 days
    expect(datesFrom({ closes_at: new Date(c).toISOString(), results_at: "2026-11-01T00:00:00Z" }).resultsAt).toBeGreaterThan(c); // results before close
    expect(dayText(c)).toBe("20 Nov");
    expect(dayTimeText(c)).toMatch(/^20 Nov, 11:59 PM$/);
  });
  it("cleanConfig keeps good dates, drops bad ones", () => {
    expect(cleanConfig({ sponsors: [], prizes: [], closes_at: "2026-11-20T18:29:59.000Z", results_at: "2026-11-22T18:30:00.000Z" }).closes_at).toBe("2026-11-20T18:29:59.000Z");
    expect(cleanConfig({ sponsors: [], prizes: [], closes_at: "2020-01-01" }).closes_at).toBeUndefined();
  });
  it("the challenge stays on screen till a week after results", () => {
    const d = datesFrom(null);
    expect(challengeOn(d.resultsAt + 6 * 86400_000, d)).toBe(true);
    expect(challengeOn(d.resultsAt + 8 * 86400_000, d)).toBe(false);
    expect(phaseAt(d.resultsAt + 8 * 86400_000, d)).toBe("over");
  });
});

describe("v371 · example reels in the config", () => {
  it("only https links, max 3, caption cut to 80", () => {
    const c = cleanConfig({ sponsors: [], prizes: [], reels: [
      { url: "https://cdn.x/a.mp4", poster: "javascript:x", caption: "y".repeat(120) }, { url: "http://cdn.x/b.mp4" },
      { url: "https://cdn.x/c.mp4" }, { url: "https://cdn.x/d.mp4" }, { url: "https://cdn.x/e.mp4" }] });
    expect(c.reels.map((r: any) => r.url)).toEqual(["https://cdn.x/a.mp4", "https://cdn.x/c.mp4", "https://cdn.x/d.mp4"]);
    expect(c.reels[0].poster).toBe("");
    expect(c.reels[0].caption).toHaveLength(80);
  });
});
