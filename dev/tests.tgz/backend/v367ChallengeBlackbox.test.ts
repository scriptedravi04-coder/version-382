// v367 deep test (Ravi: "deploy se pehle deep whitebox + blackbox"): the real challenge router over HTTP, with a fake
// Supabase that keeps creator_profiles (portfolio = text[] of JSON) and the ybex_ephemeral ledger. The creator's app
// is played step by step: stamp → normal portfolio save → /challenge/me → admin → winners.
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import express from "express";
import type { AddressInfo } from "net";
import { setupChallengeRoutes } from "./challenge_routes";
import { STARTS_AT, ENTRIES_CLOSE_AT, RESULTS_AT, CHALLENGE_ID } from "../src/lib/diwaliChallenge";

type Row = Record<string, any>;
function fakeSupabase(opts: { noLedger?: boolean } = {}) {
  const tables: Record<string, Row[]> = { creator_profiles: [], ybex_ephemeral: [] };
  const calls: string[] = [];
  function q(table: string) {
    let rows = () => tables[table] || [];
    const filters: Array<(r: Row) => boolean> = [];
    let range: [number, number] | null = null;
    let lim = Infinity;
    let op: "select" | "update" | "upsert" = "select";
    let patch: any = null;
    let single = false;
    const missing = () => opts.noLedger && table === "ybex_ephemeral";
    const api: any = {
      select() { return api; },
      not(col: string, _o: string, _v: any) { filters.push((r) => r[col] != null); return api; },
      eq(col: string, v: any) { filters.push((r) => String(r[col]) === String(v)); return api; },
      in(col: string, vs: any[]) { filters.push((r) => vs.map(String).includes(String(r[col]))); return api; },
      like(col: string, pat: string) { const p = pat.replace(/%$/, ""); filters.push((r) => String(r[col]).startsWith(p)); return api; },
      range(a: number, b: number) { range = [a, b]; return api; },
      limit(n: number) { lim = n; return api; },
      maybeSingle() { single = true; return api; },
      update(p: any) { op = "update"; patch = p; return api; },
      upsert(p: any) { op = "upsert"; patch = p; return api; },
      then(res: any, rej: any) {
        try {
          calls.push(`${op}:${table}`);
          if (missing()) return Promise.resolve({ data: null, error: { message: "relation \"ybex_ephemeral\" does not exist", code: "42P01" } }).then(res, rej);
          if (op === "upsert") {
            const i = tables[table].findIndex((r) => r.key === patch.key);
            if (i >= 0) tables[table][i] = JSON.parse(JSON.stringify(patch)); else tables[table].push(JSON.parse(JSON.stringify(patch)));
            return Promise.resolve({ data: null, error: null }).then(res, rej);
          }
          let out = rows().filter((r) => filters.every((f) => f(r)));
          if (op === "update") { out.forEach((r) => Object.assign(r, JSON.parse(JSON.stringify(patch)))); return Promise.resolve({ data: null, error: null }).then(res, rej); }
          if (range) out = out.slice(range[0], range[1] + 1);
          out = out.slice(0, lim).map((r) => JSON.parse(JSON.stringify(r)));
          return Promise.resolve({ data: single ? (out[0] || null) : out, error: null }).then(res, rej);
        } catch (e) { return Promise.reject(e).then(res, rej); }
      },
    };
    return api;
  }
  return { client: { from: (t: string) => q(t) }, tables, calls };
}

const USERS: Record<string, any> = {
  c1: { user_id: "c1", role: "creator", onboarded: true },
  c2: { user_id: "c2", role: "creator", onboarded: true },
  newbie: { user_id: "newbie", role: "creator", onboarded: false },
  basic: { user_id: "basic", role: "creator", onboarded: false, name: "Basic User", email: "basic@x.com" }, // v371: signed up, skipped onboarding
  brand: { user_id: "b1", role: "brand", onboarded: true },
  admin: { user_id: "a1", role: "admin" },
  sub: { user_id: "a2", role: "admin", team_role: "sub_admin" },
};

let server: any; let base = ""; let fake: ReturnType<typeof fakeSupabase>;
async function start(noLedger = false) {
  fake = fakeSupabase({ noLedger });
  fake.tables.creator_profiles.push(
    { user_id: "c1", name: "Ravi", instagram: "https://instagram.com/elite_ravi", portfolio: [], onboarding_complete: true },
    { user_id: "c2", name: "Ananya", instagram: "ananya.eats", portfolio: [], onboarding_complete: true },
    { user_id: "newbie", name: "", portfolio: [], onboarding_complete: false },
    { user_id: "basic", name: "", portfolio: [], onboarding_complete: false },
  );
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupChallengeRoutes(router, { supabase: null, privilegedSupabase: fake.client, parseAuthUser: async (req: any) => USERS[String(req.headers["x-u"] || "")] || null });
  app.use("/api", router);
  await new Promise<void>((r) => { server = app.listen(0, () => r()); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
}
const call = async (path: string, who = "", body?: any) => {
  const r = await fetch(base + path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", "x-u": who }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: await r.json() };
};
const reel = (c: string) => `https://www.instagram.com/reel/${c}/`;
const profile = (uid: string) => fake.tables.creator_profiles.find((r) => r.user_id === uid)!;
/** what the app's normal portfolio save does (locked creators_routes.ts just stores body.portfolio) */
const save = (uid: string, items: any[]) => { profile(uid).portfolio = items.map((i) => JSON.stringify(i)); };
async function enter(uid: string, items: any[]) {
  const r = await call("/challenge/stamp", uid, { items });
  if (r.status === 200) save(uid, [...items.map((i) => ({ ...i, ...(r.body.stamps[i.id] || {}) })), ...profile(uid).portfolio.map((s: string) => JSON.parse(s))]);
  return r;
}
const setNow = (ms: number) => vi.setSystemTime(new Date(ms));

beforeEach(async () => { vi.useFakeTimers({ toFake: ["Date"] }); setNow(STARTS_AT + 86400_000); await start(); });
afterEach(async () => { vi.useRealTimers(); await new Promise((r) => server.close(r)); });

describe("v367 black-box · entering", () => {
  it("public page works without login", async () => {
    const r = await call("/challenge/public");
    expect(r.status).toBe(200);
    expect(r.body).toMatchObject({ phase: "open", entries: 0, creators: 0, winners: [] });
  });
  it("who may enter: logged out 401, brand 403, profile not finished 400", async () => {
    const it = { id: "pf_1", content_url: reel("AAAAA1") };
    expect((await call("/challenge/stamp", "", { items: [it] })).status).toBe(401);
    expect((await call("/challenge/stamp", "brand", { items: [it] })).status).toBe(403);
    const n = await call("/challenge/stamp", "newbie", { items: [it] });
    expect(n.status).toBe(400); expect(n.body.code).toBe("NOT_ONBOARDED");
    expect((await call("/challenge/me", "")).status).toBe(401);
  });
  it("bad link refused; good reel → stamp → saved → Entry #1, 2 left", async () => {
    const bad = await call("/challenge/stamp", "c1", { items: [{ id: "pf_x", content_url: "https://youtu.be/abcdefg" }] });
    expect(bad.body.code).toBe("BAD_LINK");
    const r = await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1"), cover: "https://img/a.jpg", views: 1200, likes: 90 }]);
    expect(r.status).toBe(200);
    const me = await call("/challenge/me", "c1");
    expect(me.body.entries).toHaveLength(1);
    expect(me.body.entries[0]).toMatchObject({ no: 1, item_id: "pf_1", views: 1200, likes: 90, cover: "https://img/a.jpg" });
    expect(me.body.left).toBe(2);
    expect(me.body.onboarded).toBe(true);
  });
  it("same reel twice → DUPLICATE; 4th reel → LIMIT", async () => {
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]);
    expect((await enter("c1", [{ id: "pf_9", content_url: "https://instagram.com/p/AAAAA1" }])).body.code).toBe("DUPLICATE");
    expect((await enter("c1", [{ id: "pf_2", content_url: reel("BBBBB1") }, { id: "pf_3", content_url: reel("CCCCC1") }, { id: "pf_4", content_url: reel("DDDDD1") }])).body.code).toBe("LIMIT");
    expect((await enter("c1", [{ id: "pf_2", content_url: reel("BBBBB1") }, { id: "pf_3", content_url: reel("CCCCC1") }])).status).toBe(200);
    expect((await call("/challenge/me", "c1")).body.left).toBe(0);
    expect((await enter("c1", [{ id: "pf_4", content_url: reel("DDDDD1") }])).body.error).toMatch(/used all 3/);
  });
  it("a stamp that was never saved does not count (save failed)", async () => {
    const r = await call("/challenge/stamp", "c1", { items: [{ id: "pf_1", content_url: reel("AAAAA1") }] });
    expect(r.status).toBe(200);
    expect((await call("/challenge/me", "c1")).body.entries).toHaveLength(0);
  });
  it("entries close 2 Nov 23:59 IST", async () => {
    setNow(ENTRIES_CLOSE_AT + 1000);
    const r = await call("/challenge/stamp", "c1", { items: [{ id: "pf_1", content_url: reel("AAAAA1") }] });
    expect(r.status).toBe(400); expect(r.body.error).toMatch(/closed/);
  });
  it("entry numbers follow time across creators, and /me is right straight after saving", async () => {
    expect((await enter("c2", [{ id: "pf_x1", content_url: reel("XXXXX1") }])).status).toBe(200);
    await call("/challenge/public"); // warms the 60 s cache without c1
    setNow(STARTS_AT + 86400_000 + 5000);
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]);
    await call("/challenge/public"); // another request in between refills the cache
    expect((await call("/challenge/me", "c1")).body.entries[0].no).toBe(2);
    expect((await call("/challenge/me", "c2")).body.entries[0].no).toBe(1);
  });
});

describe("v367 black-box · entries survive other saves (server ledger)", () => {
  it("a later save from an old screen drops the stamp fields → still an entry; removing the reel removes it", async () => {
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]);
    save("c1", [{ id: "pf_1", content_url: reel("AAAAA1"), brand_name: "Ybex" }]); // stale copy, no stamp
    expect((await call("/challenge/me", "c1")).body.entries).toHaveLength(1);
    save("c1", []);
    expect((await call("/challenge/me", "c1")).body.entries).toHaveLength(0);
  });
  it("a forged stamp typed into the portfolio never counts", async () => {
    save("c2", [{ id: "f1", content_url: reel("FFFFF1"), challenge: CHALLENGE_ID, challenge_at: new Date(STARTS_AT + 10).toISOString(), challenge_sig: "x".repeat(32) }]);
    expect((await call("/challenge/me", "c2")).body.entries).toHaveLength(0);
    expect((await call("/admin/challenge/entries?fresh=1", "admin")).body.entries).toHaveLength(0);
  });
  it("without the ledger table it still works from the portfolio stamps", async () => {
    await new Promise((r) => server.close(r)); await start(true);
    expect((await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }])).status).toBe(200);
    expect((await call("/challenge/me", "c1")).body.entries).toHaveLength(1);
    expect((await call("/challenge/public")).body.entries).toBe(1);
  });
  it("10 people opening Home at once → one profile load, not 10", async () => {
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]);
    fake.calls.length = 0;
    await Promise.all(Array.from({ length: 10 }, () => call("/challenge/public")));
    // one ledger read + one sponsors/prizes read (both shared by all 10 requests)
    expect(fake.calls.filter((c) => c === "select:ybex_ephemeral").length).toBeLessThanOrEqual(2);
    expect(fake.calls.filter((c) => c === "select:creator_profiles").length).toBeLessThanOrEqual(2); // ledger creators + one safety scan, once
  });
});

describe("v367 black-box · admin + winners", () => {
  it("admin list; sub-admin can read but not mark; winners hidden till 5 Nov; prize survives the creator's own save", async () => {
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1"), views: 500 }]);
    expect((await call("/admin/challenge/entries", "c1")).status).toBe(403);
    const list = await call("/admin/challenge/entries?fresh=1", "sub");
    expect(list.body.entries).toHaveLength(1);
    expect(list.body.entries[0]).toMatchObject({ handle: "elite_ravi", name: "Ravi", views: 500 });
    expect((await call("/admin/challenge/winner", "sub", { user_id: "c1", item_id: "pf_1", rank: "1st" })).status).toBe(403);
    expect((await call("/admin/challenge/winner", "admin", { user_id: "c1", item_id: "pf_1", rank: "gold" })).status).toBe(400);
    expect((await call("/admin/challenge/winner", "admin", { user_id: "c1", item_id: "pf_1", rank: "1st" })).status).toBe(200);
    expect((await call("/challenge/public")).body.winners).toEqual([]); // before 5 Nov
    setNow(RESULTS_AT + 1000);
    save("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]); // creator saves from an old screen: no stamp, no rank
    const pub = await call("/challenge/public");
    expect(pub.body.phase).toBe("results");
    expect(pub.body.winners).toHaveLength(1);
    expect(pub.body.winners[0]).toMatchObject({ rank: "1st", name: "Ravi", handle: "elite_ravi" });
    // clear the prize
    expect((await call("/admin/challenge/winner", "admin", { user_id: "c1", item_id: "pf_1", rank: null })).status).toBe(200);
    expect((await call("/challenge/public")).body.winners).toEqual([]);
  });
  it("marking a reel that is no longer an entry is refused", async () => {
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]);
    save("c1", []);
    expect((await call("/admin/challenge/winner", "admin", { user_id: "c1", item_id: "pf_1", rank: "2nd" })).status).toBe(400);
  });
});

describe("v368 black-box · sponsors & prizes from admin", () => {
  const LOGO = "data:image/webp;base64," + "A".repeat(200);
  it("full admin saves once → /challenge, /me and the toggle all get it; sub-admin / creator can't", async () => {
    const cfg = { sponsors: [{ name: "Wefrnd", logo: LOGO, scripts: ["Find a real friend in 15s", ""] }, { name: "ProRewards", logo: "javascript:alert(1)", scripts: [] }], prizes: [{ title: "1st prize", value: "₹25,000", note: "" }, { title: "", value: "x" }] };
    expect((await call("/admin/challenge/config", "c1", { config: cfg })).status).toBe(403);
    expect((await call("/admin/challenge/config", "sub", { config: cfg })).status).toBe(403);
    const bad = await call("/admin/challenge/config", "admin", { config: cfg });
    expect(bad.status).toBe(400); // the javascript: "logo" is refused with a clear message
    expect(bad.body.error).toMatch(/ProRewards/);
    cfg.sponsors[1].logo = "";
    const ok = await call("/admin/challenge/config", "admin", { config: cfg });
    expect(ok.status).toBe(200);
    expect(ok.body.config.sponsors).toEqual([{ name: "Wefrnd", logo: LOGO, scripts: ["Find a real friend in 15s"] }, { name: "ProRewards", logo: "", scripts: [] }]);
    expect(ok.body.config.prizes).toEqual([{ title: "1st prize", value: "₹25,000", note: "" }]);
    const pub = await call("/challenge/public");
    expect(pub.body.config.sponsors.map((x: any) => x.name)).toEqual(["Wefrnd", "ProRewards"]);
    expect((await call("/challenge/me", "c1")).body.sponsor_names).toEqual(["Wefrnd", "ProRewards"]);
    expect((await call("/admin/challenge/config", "sub")).body.config.sponsors).toHaveLength(2);
  });
  it("the settings row is never read as a creator's entries", async () => {
    await call("/admin/challenge/config", "admin", { config: { sponsors: [{ name: "Ybex", scripts: ["x"] }], prizes: [] } });
    await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }]);
    const list = await call("/admin/challenge/entries?fresh=1", "admin");
    expect(list.body.entries.map((e: any) => e.user_id)).toEqual(["c1"]);
  });
  it("without the table: saving says what's missing, the page keeps working on defaults", async () => {
    await new Promise((r) => server.close(r)); await start(true);
    const r = await call("/admin/challenge/config", "admin", { config: { sponsors: [{ name: "Wefrnd" }], prizes: [] } });
    expect(r.status).toBe(500); expect(r.body.error).toMatch(/ybex_ephemeral/);
    expect((await call("/challenge/public")).body.config).toBeNull();
  });
});

describe("v369 black-box · admin moves the close date", () => {
  it("later close date → entries open again; earlier → closed, message says the date", async () => {
    setNow(ENTRIES_CLOSE_AT + 86400_000); // a day after the default close
    expect((await call("/challenge/stamp", "c1", { items: [{ id: "pf_1", content_url: reel("AAAAA1") }] })).status).toBe(400);
    const later = new Date(ENTRIES_CLOSE_AT + 5 * 86400_000).toISOString();
    const save1 = await call("/admin/challenge/config", "admin", { config: { sponsors: [], prizes: [], closes_at: later, results_at: new Date(ENTRIES_CLOSE_AT + 7 * 86400_000).toISOString() } });
    expect(save1.status).toBe(200);
    expect((await call("/challenge/public")).body).toMatchObject({ phase: "open", closes_at: Date.parse(later) });
    expect((await enter("c1", [{ id: "pf_1", content_url: reel("AAAAA1") }])).status).toBe(200);
    expect((await call("/challenge/me", "c1")).body.entries).toHaveLength(1);
    // close earlier than that entry → it no longer counts, and the stamp says when it closed
    const early = new Date(STARTS_AT + 3 * 86400_000).toISOString();
    expect((await call("/admin/challenge/config", "admin", { config: { sponsors: [], prizes: [], closes_at: early, results_at: early } })).status).toBe(200);
    const r = await call("/challenge/stamp", "c1", { items: [{ id: "pf_2", content_url: reel("BBBBB1") }] });
    expect(r.status).toBe(400); expect(r.body.error).toMatch(/closed on \d+ (Oct|Nov)/);
    expect((await call("/challenge/me", "c1")).body.entries).toHaveLength(0);
    expect((await call("/admin/challenge/config", "admin", { config: { sponsors: [], prizes: [], closes_at: "2020-01-01T00:00:00Z" } })).status).toBe(400);
  });
});

describe("v371 black-box · basics are enough, remind me", () => {
  it("not onboarded but name + email: needs an Instagram username, then enters", async () => {
    const it1 = { id: "pf_b1", content_url: reel("BASIC1") };
    const me = await call("/challenge/me", "basic");
    expect(me.body).toMatchObject({ onboarded: false, eligible: true, need_handle: true });
    const r1 = await call("/challenge/stamp", "basic", { items: [it1] });
    expect(r1.status).toBe(400); expect(r1.body.code).toBe("NEED_HANDLE");
    const r2 = await call("/challenge/stamp", "basic", { items: [it1], handle: "@Basic.User" });
    expect(r2.status).toBe(200);
    save("basic", [{ ...it1, ...r2.body.stamps.pf_b1 }]);
    expect((await call("/challenge/me", "basic")).body).toMatchObject({ need_handle: false, handle: "basic.user" });
    const list = await call("/admin/challenge/entries?fresh=1", "admin");
    expect(list.body.entries.find((e: any) => e.user_id === "basic")?.handle).toBe("basic.user");
  });
  it("no name / contact → still refused", async () => {
    const r = await call("/challenge/stamp", "newbie", { items: [{ id: "pf_n1", content_url: reel("NEWBI1") }], handle: "newbie" });
    expect(r.body.code).toBe("NOT_ONBOARDED");
  });
  it("remind me → on the admin list until the creator enters", async () => {
    expect((await call("/challenge/remind", "basic", { handle: "basic.user" })).status).toBe(200);
    expect((await call("/challenge/remind", "brand", {})).status).toBe(403);
    let rem = await call("/admin/challenge/reminders", "admin");
    expect(rem.body.reminders.map((r: any) => [r.user_id, r.email])).toEqual([["basic", "basic@x.com"]]);
    expect((await call("/admin/challenge/reminders", "c1")).status).toBe(403);
    const r = await call("/challenge/stamp", "basic", { items: [{ id: "pf_b2", content_url: reel("BASIC2") }] });
    save("basic", [{ id: "pf_b2", content_url: reel("BASIC2"), ...r.body.stamps.pf_b2 }]);
    rem = await call("/admin/challenge/reminders", "admin");
    expect(rem.body.reminders).toEqual([]);
  });
});
