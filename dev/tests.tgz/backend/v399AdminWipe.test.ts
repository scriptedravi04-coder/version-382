import { describe, it, expect } from "vitest";
import bcrypt from "bcryptjs";
import { setupAdminWipeRoutes } from "./admin_wipe_routes";
import { WIPE_UNLINK_COLUMNS } from "./accountWipe";

// v399 (Ravi 4 Nov): wiping the admins "Rishi & Vini" and "commonuseforpro" said "wiped completely" twice, but both
// stayed in the Admins list. Their admin_activity_logs rows (admin_id → users, no cascade) blocked the users delete,
// and the route answered ok anyway. Now those links are cleared first, and a wipe that leaves the account says so.

type Row = Record<string, any>;
function fakeClient(tables: Record<string, Row[]>, opts: { blockUsersDelete?: boolean } = {}) {
  const fkBlocks = (ids: string[]) =>
    opts.blockUsersDelete ||
    WIPE_UNLINK_COLUMNS.some(({ table, column }) => (tables[table] || []).some((r) => ids.includes(String(r[column]))));
  const query = (table: string) => {
    let filters: Array<(r: Row) => boolean> = [];
    let op: "select" | "delete" | "update" = "select";
    let patch: Row = {};
    const run = () => {
      const rows = tables[table] || (tables[table] = []);
      const hit = rows.filter((r) => filters.every((f) => f(r)));
      if (op === "select") return { data: hit, error: null };
      if (op === "update") { hit.forEach((r) => Object.assign(r, patch)); return { data: hit, error: null }; }
      if (table === "users" && fkBlocks(hit.map((r) => String(r.user_id)))) {
        return { data: null, error: { message: 'update or delete on table "users" violates foreign key constraint' }, count: 0 };
      }
      tables[table] = rows.filter((r) => !hit.includes(r));
      return { data: hit, error: null, count: hit.length };
    };
    const q: any = {
      select: () => q,
      delete: () => { op = "delete"; return q; },
      update: (p: Row) => { op = "update"; patch = p; return q; },
      eq: (c: string, v: any) => { filters.push((r) => String(r[c]) === String(v)); return q; },
      in: (c: string, vs: any[]) => { filters.push((r) => vs.map(String).includes(String(r[c]))); return q; },
      limit: () => q,
      then: (ok: any, bad: any) => Promise.resolve(run()).then(ok, bad),
    };
    return q;
  };
  return {
    from: query,
    rpc: async () => ({ data: 0, error: null }),
    auth: { admin: { deleteUser: async () => ({ error: null }), listUsers: async () => ({ data: { users: [] } }) } },
  };
}

async function setup(tables: Record<string, Row[]>, opts = {}) {
  const client = fakeClient(tables, opts);
  let handler: any;
  const router: any = { post: (path: string, h: any) => { if (path === "/admin/users/:id/wipe") handler = h; } };
  const me = { user_id: "admin_me", role: "admin", team_role: "admin" };
  setupAdminWipeRoutes(router, {
    supabase: client, privilegedSupabase: client,
    getDb: () => ({ users: [] }), saveDb: () => {},
    parseAuthUser: async () => me,
    logAdminAction: async () => {},
  });
  const call = async (id: string) => {
    let status = 200; let body: any = null;
    const res: any = { status: (s: number) => { status = s; return res; }, json: (b: any) => { body = b; return res; } };
    await handler({ params: { id }, body: { password: "Secret#123" } }, res);
    return { status, body };
  };
  return { call, tables };
}

const baseTables = async () => ({
  users: [
    { user_id: "admin_me", role: "admin", team_role: "admin", email: "me@admin.ybex", password_hash: await bcrypt.hash("Secret#123", 4) },
    { user_id: "0ae7b96f-b15e-4e76-b161-285fe928f37f", role: "admin", team_role: "", email: "old@gmail.com" },
    { user_id: "user_1788364031208", role: "admin", team_role: "", email: "other@gmail.com" },
  ],
  admin_activity_logs: [
    { id: 1, admin_id: "0ae7b96f-b15e-4e76-b161-285fe928f37f", action: "approve_campaign" },
    { id: 2, admin_id: "admin_me", action: "x" },
  ],
});

describe("v399 wiping an admin who has admin logs", () => {
  it("removes the account and keeps the log rows (only the link to the wiped admin is cleared)", async () => {
    const { call, tables } = await setup(await baseTables());
    const r = await call("0ae7b96f-b15e-4e76-b161-285fe928f37f");
    expect(r.status).toBe(200);
    expect(r.body.ok).toBe(true);
    expect(tables.users.some((u) => u.user_id === "0ae7b96f-b15e-4e76-b161-285fe928f37f")).toBe(false);
    expect(tables.admin_activity_logs).toHaveLength(2);
    expect(tables.admin_activity_logs[0].admin_id).toBeNull();
    expect(tables.admin_activity_logs[1].admin_id).toBe("admin_me");
  });

  it("never says 'wiped' when the account is still there", async () => {
    const { call, tables } = await setup(await baseTables(), { blockUsersDelete: true });
    const r = await call("user_1788364031208");
    expect(r.status).toBe(500);
    expect(r.body.code).toBe("WIPE_INCOMPLETE");
    expect(r.body.ok).toBeUndefined();
    expect(tables.users.some((u) => u.user_id === "user_1788364031208")).toBe(true);
  });
});
