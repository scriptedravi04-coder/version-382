import { describe, it, expect } from "vitest";
import { parseEnvBundle, cleanEnvVal } from "./envBundle";
import { makeState, readState } from "./oauth_routes";

// v385 (Ravi 30 Oct 2026): `GOOGLE_CLIENT_SECRET=GOCSPX-… # ── Apple sign-in (iPhone) ──` was loaded together with the comment,
// Google answered 401 invalid_client and every Google sign-in ended on "Sign-in didn't finish".
describe("v385 · YBEX_ENV inline comments", () => {
  it("strips a trailing # comment from an unquoted value", () => {
    const t = "GOOGLE_CLIENT_SECRET=GOCSPX-abc123_-X  # ── Apple sign-in (iPhone) ──\nAPPLE_CLIENT_ID=in.ybexmedia.signin";
    const p = parseEnvBundle(t);
    expect(p.GOOGLE_CLIENT_SECRET).toBe("GOCSPX-abc123_-X");
    expect(p.APPLE_CLIENT_ID).toBe("in.ybexmedia.signin");
  });
  it("works when the secret box saved everything on one line", () => {
    const p = parseEnvBundle("GOOGLE_CLIENT_ID=abc.apps.googleusercontent.com GOOGLE_CLIENT_SECRET=GOCSPX-s3cr3t # ── Apple ── APPLE_CLIENT_ID=in.x");
    expect(p.GOOGLE_CLIENT_SECRET).toBe("GOCSPX-s3cr3t");
    expect(p.GOOGLE_CLIENT_ID).toBe("abc.apps.googleusercontent.com");
  });
  it("keeps a # that is inside a value, and quoted values untouched", () => {
    expect(cleanEnvVal("pa#ss#word")).toBe("pa#ss#word");
    expect(cleanEnvVal('"has # inside"')).toBe("has # inside");
    expect(cleanEnvVal('"quoted"  # note')).toBe("quoted");
    expect(cleanEnvVal("'single'")).toBe("single");
  });
  it("a comment-only value becomes empty; undefined is safe", () => {
    expect(cleanEnvVal("# nothing here")).toBe("");
    expect(cleanEnvVal(undefined)).toBe("");
    expect(parseEnvBundle("KEY=# only a comment").KEY).toBe("");
  });
  it("the signed OAuth state carries the exact redirect URI to the token exchange", () => {
    const uri = "https://ybexmedia.in/api/auth/oauth/google/callback";
    const st = readState(makeState("creator", Date.now(), "s", false, "", uri), Date.now(), "s");
    expect(st?.u).toBe(uri);
    expect(readState(makeState("creator", Date.now(), "s", false, "", "http://evil.example/x"), Date.now(), "s")?.u).toBeUndefined();
    expect(readState(makeState("creator", Date.now(), "s"), Date.now(), "s")?.u).toBeUndefined();
  });
});

import { readOAuthHash, readOAuthHashOnce } from "../src/pages/app/AppOAuthDone";
describe("v385 · the sign-in page survives a second run after the hash was wiped", () => {
  it("returns the first read when the hash is empty the second time", () => {
    const first = readOAuthHashOnce("#token=abc&role=creator");
    expect(first.token).toBe("abc");
    expect(readOAuthHashOnce("").token).toBe("abc"); // StrictMode second run
    expect(readOAuthHash("").token).toBe("");
  });
  it("carries Google's reason for the small code line", () => {
    expect(readOAuthHash("#error=google&reason=invalid_client").reason).toBe("invalid_client");
  });
});
