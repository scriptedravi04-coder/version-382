// White-box tests: chat deal state, review-flag precedence, deal flow detection, UGC stage resolver,
// campaign guards — plus the chat route that feeds them.
// Tests marked it.fails document a real bug in the CURRENT code (see the "BUG:" comment above each).
import { describe, it, expect } from "vitest";
import express from "express";
import { deriveDealState, getDealAmount } from "../src/components/chat/dealState";
import { resolveReviewFlags } from "../src/components/chat/chatFlowState";
import dealFlowDefault, * as dealFlowFe from "../src/utils/dealFlow";
import { isUuid, looksLikeUgcId, looksLikeCampaignId, isUgcThread, isCampaignThread, getDealFlow, getUgcOrderId, getCampaignDealId, safeUuidOrNull } from "./dealFlow";
import { resolveUgcStage, phaseFromMessages } from "./ugcOrderStage";
import {
  upper, flowOf, isClosed, partyRole, forbid, conflict, revisionAllowance, knownAmount, threadHasMessage,
  hasCampaignLiveLinkEvidence, hasCampaignDraftEvidence, isCampaignEscrowFunded, loadCampaignThreadAndDeal,
} from "./campaignGuards";
import { setupChatCoreRoutes } from "./chat_routes";

const UUID = "123e4567-e89b-12d3-a456-426614174000";

describe("dealState.getDealAmount", () => {
  it("first truthy amount wins; nothing → 0", () => {
    expect(getDealAmount({ agreed_amount: 5000, amount_fixed: 1 })).toBe(5000);
    expect(getDealAmount({ campaign: { budget: 700 } })).toBe(700);
    expect(getDealAmount({ ugc_order: { creator_payout: 900 } })).toBe(900);
    expect(getDealAmount(null)).toBe(0);
    expect(getDealAmount({ agreed_amount: 0, amount_fixed: 3000 })).toBe(3000);
  });
});

describe("dealState.deriveDealState", () => {
  it("no thread → nothing signed / funded / completed", () => {
    const s = deriveDealState({ thread: null, messages: null as any });
    expect(s.isAgreementSigned || s.isDealFixed || s.isPaymentFunded || s.isDealCompleted).toBe(false);
    expect(s.amount).toBe(0);
  });

  it("campaign: both signatures needed; my / other side flip with isBrand", () => {
    const t = { id: UUID, status: "AGREED", agreement_signed_brand: true };
    const asBrand = deriveDealState({ thread: t, isBrand: true });
    expect(asBrand.isMySignatureSigned).toBe(true);
    expect(asBrand.isOtherPartySigned).toBe(false);
    expect(asBrand.isAgreementSigned).toBe(false);
    expect(asBrand.isNegotiationLocked).toBe(true);
    expect(deriveDealState({ thread: { ...t, creator_signed: true } }).isAgreementSigned).toBe(true);
  });

  it("status casing: 'negotiating' in any case is not a fixed deal", () => {
    expect(deriveDealState({ thread: { id: UUID, status: "negotiating" } }).isDealFixed).toBe(false);
    expect(deriveDealState({ thread: { id: UUID, status: "Negotiating" } }).isDealFixed).toBe(false);
    expect(deriveDealState({ thread: { id: UUID, flow_state: "AI_AGREEMENT_READY" } }).isDealFixed).toBe(true);
  });

  it("UGC threads are always 'signed' and 'fixed'", () => {
    const s = deriveDealState({ thread: { id: "ugcord_1" } });
    expect(s.isUgcOrder && s.isAgreementSigned && s.isDealFixed).toBe(true);
    // v389 (Ravi's written OK, 30 Oct 2026): a title is never used any more — a campaign called "My UGC order" is still a campaign. Only type / id decide.
    expect(deriveDealState({ thread: { id: "x", title: "My UGC order" } }).isUgcOrder).toBe(false);
    expect(deriveDealState({ thread: { id: "thread_ugc_9" } }).isUgcOrder).toBe(true);
  });

  it("a person TYPING 'payment released' / 'payment secured' never changes the state", () => {
    const msgs = [
      { message_type: "text", content: "payment released kab hoga?" },
      { message_type: "TEXT", text: "payment secured?" },
    ];
    const s = deriveDealState({ thread: { id: UUID, status: "ACTIVE" }, messages: msgs });
    expect(s.isDealCompleted).toBe(false);
    expect(s.isPaymentFunded).toBe(false);
  });

  it("system cards do move the state", () => {
    expect(deriveDealState({ thread: { id: UUID }, messages: [{ message_type: "system", content: "Escrow payment released" }] }).isDealCompleted).toBe(true);
    expect(deriveDealState({ thread: { id: UUID }, messages: [{ message_type: "system", content: "Payment secured into Ybex escrow" }] }).isPaymentFunded).toBe(true);
    expect(deriveDealState({ thread: { id: UUID }, messages: [{ message_type: "x", metadata: { isPayment: true } }] }).isPaymentFunded).toBe(true);
  });

  it("funded by any funding flag / status (case-insensitive)", () => {
    expect(deriveDealState({ thread: { id: UUID, payment_status: "escrow_held" } }).isPaymentFunded).toBe(true);
    expect(deriveDealState({ thread: { id: UUID, deal: { escrow_hold_at: "2026-01-01" } } }).isPaymentFunded).toBe(true);
    expect(deriveDealState({ thread: { id: UUID, payment_status: "PENDING" } }).isPaymentFunded).toBe(false);
    // documented: a UGC thread from a brief is treated as funded unless payment_funded === false (briefs are prepaid)
    expect(deriveDealState({ thread: { id: "ugcord_1", ugc_brief_id: "b" } }).isPaymentFunded).toBe(true);
    expect(deriveDealState({ thread: { id: "ugcord_1", ugc_brief_id: "b", payment_funded: false } }).isPaymentFunded).toBe(false);
  });

  it("completed wins over approved; a UGC raw-video order is complete on draft approval", () => {
    const done = deriveDealState({ thread: { id: UUID, status: "COMPLETED", flow_state: "CONTENT_APPROVED" } });
    expect(done.isDealCompleted).toBe(true);
    expect(done.isContentApproved).toBe(false);
    const raw = deriveDealState({ thread: { id: "ugcord_1", deliverable_type: "ugc_video_raw", ugc_order: { status: "CONTENT_APPROVED" } } });
    expect(raw.isCollabOrder).toBe(false);
    expect(raw.isDealCompleted).toBe(true);
    const collab = deriveDealState({ thread: { id: "ugcord_1", deliverable_type: "collab_reel", ugc_order: { status: "CONTENT_APPROVED" } } });
    expect(collab.isCollabOrder).toBe(true);
    expect(collab.isDealCompleted).toBe(false);
    expect(collab.isContentApproved).toBe(true);
  });

  it("a UTR on the transaction completes the deal", () => {
    expect(deriveDealState({ thread: { id: UUID, transaction: { utr_number: "U1" } } }).isDealCompleted).toBe(true);
  });

  it("live links: a newer resubmit request reopens; a newer submit closes the revision", () => {
    const req = { message_type: "live_links_resubmit_request" };
    const sub = { message_type: "live_links_submitted" };
    const open = deriveDealState({ thread: { id: UUID, status: "ACTIVE" }, messages: [sub, req] });
    expect(open.isLiveLinksRevisionOpen).toBe(true);
    expect(open.isLiveLinksSubmitted).toBe(false);
    const closed = deriveDealState({ thread: { id: UUID, status: "ACTIVE" }, messages: [req, sub] });
    expect(closed.isLiveLinksRevisionOpen).toBe(false);
    expect(closed.isLiveLinksSubmitted).toBe(true);
  });

  it("draft revision: the latest action message decides", () => {
    const s = deriveDealState({ thread: { id: UUID, status: "REVISION_REQUESTED" }, messages: [{ message_type: "revision_requested" }, { message_type: "content_proof_submitted" }] });
    expect(s.isRevisionRequested).toBe(false);
    expect(s.isContentSubmitted).toBe(true);
  });
});

describe("chatFlowState.resolveReviewFlags", () => {
  it("defaults → nothing", () => {
    expect(resolveReviewFlags()).toMatchObject({ isRevisionRequested: false, isRevisionDeclined: false, isContentSubmitted: false });
  });
  it("revision beats a stale SUBMITTED order row", () => {
    const f = resolveReviewFlags({ ugcStatus: "SUBMITTED", flowState: "REVISION_REQUESTED" });
    expect(f.isRevisionRequested).toBe(true);
    expect(f.isContentSubmitted).toBe(false);
  });
  it("a fresh submit message clears revision and decline", () => {
    const f = resolveReviewFlags({ rawStatus: "REVISION_DECLINED", flowState: "CHANGES_REQUESTED", latestActionType: "content_proof_submitted" });
    expect(f.isRevisionRequested || f.isRevisionDeclined).toBe(false);
    expect(f.isContentSubmitted).toBe(true);
  });
  it("completed / approved switch everything off", () => {
    expect(resolveReviewFlags({ isDealCompleted: true, rawStatus: "SUBMITTED", latestActionType: "revision_requested" }))
      .toMatchObject({ isRevisionRequested: false, isContentSubmitted: false });
    expect(resolveReviewFlags({ isContentApproved: true, rawStatus: "REVISION_DECLINED" }).isRevisionDeclined).toBe(false);
  });
  it("status tokens are case-sensitive here (callers upper-case first)", () => {
    expect(resolveReviewFlags({ rawStatus: "submitted" }).isContentSubmitted).toBe(false);
    expect(resolveReviewFlags({ latestActionType: "CHANGES_REQUESTED" }).isRevisionRequested).toBe(true);
  });
});

describe("dealFlow (backend + frontend re-export)", () => {
  it("frontend re-export is the same functions", () => {
    expect(dealFlowFe.isUgcThread).toBe(isUgcThread);
    expect(dealFlowDefault.getDealFlow).toBe(getDealFlow);
  });
  it("ids", () => {
    expect(isUuid(UUID.toUpperCase())).toBe(true);
    expect(isUuid(` ${UUID}`)).toBe(false);
    expect(isUuid(123)).toBe(false);
    expect(looksLikeUgcId("ugc_x")).toBe(true);
    expect(looksLikeUgcId(null)).toBe(false);
    expect(looksLikeCampaignId("thread_camp_anything")).toBe(true);
    expect(safeUuidOrNull("ugcord_1")).toBeNull();
    expect(safeUuidOrNull(UUID)).toBe(UUID);
  });
  it("UGC signal wins over campaign signal; no signal → campaign", () => {
    expect(isCampaignThread({ campaign_id: "c", ugc_order_id: "u" })).toBe(false);
    expect(getDealFlow({ deal_type: "ugc" })).toBe("ugc");
    expect(isCampaignThread({})).toBe(true);
    expect(isCampaignThread({ id: "random" })).toBe(false);
    expect(getDealFlow(null)).toBe("campaign");
    expect(isUgcThread(null)).toBe(false);
  });
  it("getUgcOrderId never returns a campaign uuid; strips thread_ugc_", () => {
    expect(getUgcOrderId({ id: "thread_ugc_abc" })).toBe("abc");
    expect(getUgcOrderId({ id: UUID })).toBeNull();
    expect(getUgcOrderId({ is_ugc: true, ugc_order: { id: "ugcord_9" } })).toBe("ugcord_9");
    expect(getUgcOrderId({ is_ugc: true, ugc_order_id: 55 })).toBeNull(); // non-string ids are skipped
  });
  it("getCampaignDealId is a uuid or null", () => {
    expect(getCampaignDealId({ id: `thread_camp_${UUID}` })).toBe(UUID);
    expect(getCampaignDealId({ campaign_deal_id: "nope", deal_id: UUID })).toBe(UUID);
    expect(getCampaignDealId({ id: "thread_camp_nope" })).toBeNull();
    expect(getCampaignDealId({ id: "ugcord_1" })).toBeNull();
  });
});

describe("ugcOrderStage.resolveUgcStage", () => {
  const at = (s: string) => `2026-10-19T${s}:00Z`;
  it("terminal money states win over any chat history (no going backwards)", () => {
    const r = resolveUgcStage({ order: { status: "COMPLETED" }, messages: [{ metadata: { action: "revision_requested" }, created_at: at("10:00") }], requiresLiveLink: true });
    expect(r.phase).toBe("COMPLETED");
    expect(r.source).toBe("terminal");
    expect(resolveUgcStage({ order: { utr_number: "U" }, requiresLiveLink: true }).phase).toBe("COMPLETED");
    expect(resolveUgcStage({ order: { status: "COMPLETED", payment_status: "refunded" }, requiresLiveLink: true }).phase).toBe("CANCELLED");
  });
  it("latest message wins (a revision can overturn an approval)", () => {
    const msgs = [
      { metadata: { action: "draft_approved" }, created_at: at("10:00") },
      { metadata: { action: "revision_requested" }, created_at: at("11:00") },
    ];
    expect(resolveUgcStage({ order: { status: "SUBMITTED" }, messages: [...msgs].reverse(), requiresLiveLink: true }).phase).toBe("REVISION_REQ");
  });
  it("same timestamp / no timestamp → arrival order", () => {
    expect(phaseFromMessages([{ message_type: "revision_requested" }, { message_type: "content_proof_submitted" }])).toBe("SUBMITTED");
    expect(phaseFromMessages(null)).toBeNull();
    expect(phaseFromMessages([{ message_type: "text" }])).toBeNull();
  });
  it("content_approved without an action: only the draft-approval wording is a pending live-link step", () => {
    expect(phaseFromMessages([{ message_type: "content_approved", text: "Draft approved! Share the live post link" }])).toBe("CONTENT_APPROVED");
    expect(phaseFromMessages([{ message_type: "content_approved", text: "Video approved" }])).toBe("COMPLETED");
  });
  it("no live link needed → an approval is the end", () => {
    const r = resolveUgcStage({ order: { status: "AWAITING_LIVE_LINK" }, requiresLiveLink: false });
    expect(r.phase).toBe("COMPLETED");
    const l = resolveUgcStage({ order: { status: "awaiting_live_link" }, requiresLiveLink: true });
    expect([l.brandStage, l.creatorStage]).toEqual(["AWAITING_LIVE_LINK", "COMPLETED_APPROVAL"]);
  });
  it("order timestamps as last resort; unknown → IN_PROGRESS with the raw status token", () => {
    expect(resolveUgcStage({ order: { video_url: "v" }, requiresLiveLink: true }).phase).toBe("SUBMITTED");
    expect(resolveUgcStage({ order: { draft_approved_at: "x" }, requiresLiveLink: true }).phase).toBe("CONTENT_APPROVED");
    expect(resolveUgcStage({ order: { live_link: "l" }, requiresLiveLink: true }).isLiveLinkSubmitted).toBe(true);
    const p = resolveUgcStage({ order: { status: "PENDING" }, requiresLiveLink: true });
    expect([p.phase, p.status, p.brandStage]).toEqual(["IN_PROGRESS", "PENDING", "PENDING"]);
    const a = resolveUgcStage({ order: { status: "accepted" }, requiresLiveLink: true });
    expect(a.brandStage).toBe("IN_PROGRESS");
    expect(resolveUgcStage(null as any).phase).toBe("IN_PROGRESS");
    expect(resolveUgcStage({ order: { status: 42 }, requiresLiveLink: true }).status).toBe("IN_PROGRESS");
  });
  it("thread flow_state beats a stale order status", () => {
    const r = resolveUgcStage({ order: { status: "SUBMITTED" }, thread: { flow_state: "revision_requested" }, requiresLiveLink: true });
    expect(r.phase).toBe("REVISION_REQ");
    expect(r.source).toBe("thread");
  });
});

describe("campaignGuards helpers", () => {
  it("upper / flowOf / isClosed", () => {
    expect(upper(5)).toBe("");
    expect(flowOf({}, { flow_state: "active" })).toBe("ACTIVE");
    expect(isClosed({ status: "paid" })).toBe(true);
    expect(isClosed({ status: "ACTIVE" }, { status: "cancelled" })).toBe(true);
    expect(isClosed(null)).toBe(false);
  });
  it("partyRole: admin, brand team member, creator, stranger", () => {
    const t = { brand_id: "b1", creator_id: "c1" };
    expect(partyRole({ role: "Admin" }, t)).toBe("admin");
    expect(partyRole({ user_id: "tm", parent_brand_id: "b1" }, t)).toBe("brand");
    expect(partyRole({ id: "c1" }, t)).toBe("creator");
    expect(partyRole({ user_id: "x" }, t)).toBeNull();
    expect(partyRole({ user_id: "b2" }, null, { brand_user_id: "b2" })).toBe("brand");
    expect(partyRole(null, t)).toBeNull();
    expect(partyRole({ user_id: undefined }, {})).toBeNull();
  });
  it("forbid / conflict response shapes", () => {
    const res: any = { status(c: number) { this.code = c; return this; }, json(b: any) { this.body = b; return this; } };
    forbid(res, "creator");
    expect([res.code, res.body.code]).toEqual([403, "NOT_A_PARTY"]);
    conflict(res, "X", "msg", { phase: "P" });
    expect([res.code, res.body.phase, res.body.detail]).toEqual([409, "P", "msg"]);
  });
  it("revisionAllowance keeps a real 0; knownAmount never invents", () => {
    expect(revisionAllowance(0, 3)).toBe(0);
    expect(revisionAllowance("", null, "2")).toBe(2);
    expect(revisionAllowance(-1, "x")).toBe(5);
    expect(knownAmount("0", -5, "abc", "1500")).toBe(1500);
    expect(knownAmount()).toBe(0);
  });
  it("threadHasMessage: local store, then Supabase; lookup failure → no evidence", async () => {
    const db = { chat_messages: [{ thread_id: "t", metadata: { action: "Live_Link_Submitted" } }] };
    expect(await threadHasMessage({ client: null, db, threadId: "t" }, ["x"], ["live_link_submitted"])).toBe(true);
    const client = { from: () => { const q: any = { select: () => q, eq: () => q, in: () => q, limit: async () => ({ data: [{}] }) }; return q; } };
    expect(await threadHasMessage({ client, db: {}, threadId: "t" }, ["x"])).toBe(true);
    const bad = { from: () => { throw new Error("down"); } };
    expect(await threadHasMessage({ client: bad, db: {}, threadId: "t" }, ["x"])).toBe(false);
    expect(await threadHasMessage({ client, db: {}, threadId: "" }, ["x"])).toBe(false);
  });
  it("evidence + funding helpers (local store)", async () => {
    expect(await hasCampaignLiveLinkEvidence({ client: null, db: {}, threadId: "t", dealId: null, deal: { instagram_post_url: "u" } })).toBe(true);
    expect(await hasCampaignLiveLinkEvidence({ client: null, db: { content_submissions: [{ deal_id: "d", submission_type: "live_link" }] }, threadId: "t", dealId: "d" })).toBe(true);
    expect(await hasCampaignLiveLinkEvidence({ client: null, db: {}, threadId: "t", dealId: "d" })).toBe(false);
    expect(await hasCampaignDraftEvidence({ client: null, db: { content_submissions: [{ deal_id: "d", submission_type: "video" }] }, threadId: "t", dealId: "d" })).toBe(true);
    expect(await hasCampaignDraftEvidence({ client: null, db: { content_submissions: [{ deal_id: "d", submission_type: "live_link" }] }, threadId: "t", dealId: "d" })).toBe(false);
    expect(await isCampaignEscrowFunded({ client: null, db: { transactions: [{ campaign_deal_id: "d", status: "SUCCESS" }] }, dealId: "d" })).toBe(true);
    expect(await isCampaignEscrowFunded({ client: null, db: { transactions: [{ deal_id: "d", status: "SUCCESS", refund_amount: 10 }] }, dealId: "d" })).toBe(false);
    expect(await isCampaignEscrowFunded({ client: null, db: {}, dealId: null, thread: { escrow_funded: true } })).toBe(true);
    expect(await isCampaignEscrowFunded({ client: null, db: {}, dealId: null })).toBe(false);
  });
  it("loadCampaignThreadAndDeal resolves thread_camp_ ids from the local store", async () => {
    const db = { chat_threads: [{ id: `thread_camp_${UUID}`, deal_id: UUID }], deals: [{ id: UUID, status: "ACTIVE" }] };
    const r: any = await loadCampaignThreadAndDeal({ client: null, db, rawId: `thread_camp_${UUID}`, getCampaignDealId });
    expect(r?.dealId ?? r?.deal?.id).toBe(UUID);
  });
});

// ---------------------------------------------------------------- chat route that writes message_type
async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = app.listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}`); } finally { srv.close(); }
}
function chatApp(db: any, user: any) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupChatCoreRoutes(app, router, {
    supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => user,
    ensureUGCChatThread: async () => null, populateThreadData: async (t: any[]) => t, insertChatMessageToSupabase: async () => ({}),
  });
  app.use("/api", router);
  return app;
}

describe("POST /chat/v2/threads/:id/messages — message_type from the client", () => {
  const mkDb = () => ({ chat_threads: [{ id: "ugcord_t1", creator_id: "c1", brand_id: "b1" }], chat_messages: [] as any[] });
  const send = (base: string, body: any) => fetch(`${base}/api/chat/v2/threads/ugcord_t1/messages`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });

  it("a user can't post a 'system' card (Session 53 guard holds)", async () => {
    const db = mkDb();
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      expect((await send(base, { text: "Payment secured", message_type: "system" })).status).toBe(200);
    });
    expect(db.chat_messages[0].message_type).toBe("text");
  });

  // BUG (security, money-state): only "system" is filtered. A creator (or brand) can post a normal chat message
  // with message_type "payout_released" / "payment_funded" / "content_approved" / "live_links_submitted" /
  // "order_cancelled". These types are trusted as lifecycle events by dealState.js (deal shown completed /
  // funded), ugcOrderStage.phaseFromMessages (UGC order resolved COMPLETED/CANCELLED → brand gets
  // "This order is already closed" when asking for changes, and the order lists write draft_approved_at to
  // ugc_orders), and campaignGuards.threadHasMessage (counts as live-link / draft "evidence").
  // Fix (chat_routes.ts:523): for non-staff, allow only ["text","attachment","file","image","video"], else "text".
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("a user can't forge a lifecycle message type (payout_released)", async () => {
    const db = mkDb();
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      expect((await send(base, { text: "hi", message_type: "payout_released" })).status).toBe(200);
    });
    expect(db.chat_messages[0].message_type).toBe("text");
  });

  it("documented consequence: such a message resolves the UGC order as COMPLETED", () => {
    const forged = [{ message_type: "payout_released", text: "hi", created_at: "2026-10-19T10:00:00Z" }];
    expect(resolveUgcStage({ order: { status: "SUBMITTED" }, messages: forged, requiresLiveLink: true }).phase).toBe("COMPLETED");
    expect(deriveDealState({ thread: { id: "ugcord_t1" }, messages: forged }).isDealCompleted).toBe(true);
  });
});
