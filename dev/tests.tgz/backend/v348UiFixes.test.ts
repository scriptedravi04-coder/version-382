// v348 (Ravi's iPhone screenshots, brand account): chat composer gap over the keyboard, an unread "1" stuck
// on a completed deal, the Quick action sheet under the bottom nav, and a tall see-through bottom nav.
import { describe, it, expect, beforeEach } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fetchLeanMessageWindows, __resetLearnedColumns } from "./inboxLean";
import { markThreadSeen, effectiveUnread, countUnreadThreads } from "../src/lib/threadSeen.js";

const root = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(root, p), "utf8");

describe("v348 — chat composer docks on the keyboard", () => {
  it("composer drops the home-bar padding while the keyboard is open", () => {
    expect(read("src/components/chat/mobile/ChatBoxMobile.jsx")).toContain('className="chat-composer"');
    expect(read("src/index.css")).toMatch(/html\.kb-open \.chat-shell \.chat-composer \{\s*padding-bottom: 8px !important;/);
  });
});

describe("v348 — unread count clears", () => {
  it("inbox counts only read = false (the rows opening a chat can mark read)", async () => {
    __resetLearnedColumns();
    const rows = [
      { message_id: "m1", thread_id: "t1", created_at: "2026-10-01T00:00:01Z", sender_user_id: "admin", read: null, message_type: "payout_released" },
      { message_id: "m2", thread_id: "t1", created_at: "2026-10-01T00:00:00Z", sender_user_id: "b", read: true, message_type: "text" },
      { message_id: "m3", thread_id: "t2", created_at: "2026-10-01T00:00:02Z", sender_user_id: "b", read: false, message_type: "text" },
      { message_id: "m4", thread_id: "t2", created_at: "2026-10-01T00:00:03Z", sender_user_id: "me", read: false, message_type: "text" },
    ];
    const client = {
      from: () => {
        const filters: any[] = [];
        let cnt = false; let lim = 1e9;
        const b: any = {
          select: (_c: string, o?: any) => { if (o?.count) cnt = true; return b; },
          eq: (c: string, v: any) => { filters.push((r: any) => r[c] === v); return b; },
          in: (c: string, v: any[]) => { filters.push((r: any) => v.includes(r[c])); return b; },
          or: () => { filters.push((r: any) => !r.read); return b; },
          order: () => b,
          limit: (n: number) => { lim = n; return b; },
          then: (res: any, rej: any) => {
            const all = rows.filter((r) => filters.every((f) => f(r)));
            return Promise.resolve({ data: all.slice(0, lim), error: null, count: cnt ? all.length : null }).then(res, rej);
          },
        };
        return b;
      },
    };
    const r: any = await fetchLeanMessageWindows(client, ["t1", "t2"], "me", 60);
    expect(r.unread).toEqual({ t2: 1 }); // the read=null payout card no longer counts; my own message never did
    expect(read("backend/inboxLean.ts")).not.toContain('.or("read.is.null,read.eq.false")');
  });

  describe("opened chat = read on the phone", () => {
    beforeEach(() => {
      const store = new Map<string, string>();
      (globalThis as any).localStorage = {
        getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
        setItem: (k: string, v: string) => { store.set(k, String(v)); },
        removeItem: (k: string) => { store.delete(k); },
      };
    });

    it("nothing new since the chat was opened → 0; new messages → only those", () => {
      const t: any = { id: "th1", unread_count: 100, total_messages_count: 40, last_message: { created_at: "2026-10-18T10:00:00Z" } };
      expect(effectiveUnread(t)).toBe(100);
      markThreadSeen(t, new Date("2026-10-18T11:00:00Z").getTime());
      expect(effectiveUnread(t)).toBe(0);
      expect(countUnreadThreads([t])).toBe(0);
      const later = { ...t, total_messages_count: 42, last_message: { created_at: "2026-10-18T12:00:00Z" } };
      expect(effectiveUnread(later)).toBe(2);
      expect(effectiveUnread({ id: "other", unread_count: 3 })).toBe(3);
    });

    it("inbox and both home screens use it", () => {
      const inbox = read("src/components/inbox/mobile/InboxMobile.jsx");
      expect(inbox).toContain("markThreadSeen(activeThread)");
      expect(inbox).toContain("const unread = effectiveUnread(thread);");
      for (const f of ["src/pages/brand/BrandHomeMobile.jsx", "src/pages/creator/CreatorHomeMobile.jsx"]) {
        const s = read(f);
        expect(s).toContain("countUnreadThreads(");
        expect(s).not.toContain("t.last_message_sender !== user?.user_id && !t.read");
      }
    });
  });
});

describe("v348 — Quick action sheet above the bottom nav", () => {
  it("drawn on <body> with a z-index above the nav", () => {
    const s = read("src/components/quickActions/QuickActionsMobile.jsx");
    expect(s).toContain("createPortal(");
    expect(s).toContain("document.body");
    expect(s).toContain("zIndex: 95");
  });
});

describe("v348 — bottom nav: solid and shorter", () => {
  it("opaque background, no blur, 58px tabs + safe-area + 4px", () => {
    const s = read("src/components/layout/BottomNav.jsx");
    const nav = s.slice(s.indexOf('id="mobile-bottom-navigation"'), s.indexOf("{tabs.map("));
    expect(nav).toContain("bg-white dark:bg-[#0f172a]");
    expect(nav).not.toMatch(/bg-white\/\d+|backdrop-blur/);
    expect(nav).toContain('paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 4px)"');
    expect(nav).toContain('height: "calc(58px + env(safe-area-inset-bottom, 0px) + 4px)"');
    expect(nav).toContain("h-[58px]");
    expect(read("src/index.css")).toContain("padding-bottom: calc(62px + env(safe-area-inset-bottom, 0px) + 16px);");
  });
});
