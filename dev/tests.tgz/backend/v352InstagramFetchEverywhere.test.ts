// v352 (Ravi): "Fetch from Instagram" next to every Instagram username box — apply form, onboarding, settings, admin.
import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { takeSlot, previewFields } from "./instagramConnect";

const root = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(root, p), "utf8");

describe("v352 — preview helpers", () => {
  it("limiter allows N per hour, then blocks, then frees up", () => {
    const m = new Map<string, number[]>();
    expect(takeSlot(m, "a", 2, 0)).toBe(true);
    expect(takeSlot(m, "a", 2, 10)).toBe(true);
    expect(takeSlot(m, "a", 2, 20)).toBe(false);
    expect(takeSlot(m, "b", 2, 20)).toBe(true);
    expect(takeSlot(m, "a", 2, 3600000 + 1)).toBe(true);
  });
  it("preview keeps only form numbers (no picture link)", () => {
    const p = previewFields({ username: "a", followers: 10, avg_views: 5, profile_picture_url: "x" });
    expect(p.followers).toBe(10);
    expect(p).not.toHaveProperty("profile_picture_url");
  });
});

describe("v352 — wiring", () => {
  it("public preview + config routes exist", () => {
    const s = read("backend/instagramConnect.ts");
    expect(s).toContain('router.post("/instagram/preview"');
    expect(s).toContain('router.get("/instagram/config"');
  });
  it("every Instagram username form has the Fetch button", () => {
    for (const f of [
      "src/pages/creator/PublicCreatorApply.jsx", "src/pages/creator/applyMobile/ApplyMobileForm.jsx",
      "src/components/onboarding/Step1_Identity.tsx", "src/components/onboarding/Step3_SocialChannels.tsx",
      "src/pages/onboarding/CreatorOnboardingMobile.jsx", "src/pages/creator/profileScreens/parts/InstagramStatsForm.jsx",
      "src/pages/creator/settingsDesktop/PlatformsPanel.jsx", "src/components/admin/CreatorProfileEditModal.jsx",
      "src/components/admin/WaitlistEditModal.jsx", "src/components/Onboarding/BrandOnboardingFlow.jsx",
    ]) expect(read(f), f).toContain("<InstagramFetchButton");
  });
});
