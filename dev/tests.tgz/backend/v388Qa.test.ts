import { describe, it, expect, beforeEach } from "vitest";
import fs from "fs";
import { waClean } from "../src/pages/app/AppContinue";
import { publicSiteUrl } from "./siteUrl";
import { otpIpAllowed, _resetLoginIpHits, OTP_IP_PER_WINDOW } from "./authSecurity";
import { sanitizeHtml } from "./htmlSanitize";
import { robotsTxt, sitemapXml } from "./blogSeo";
import { loadFeeConfig, __resetFeeConfigCache } from "./brandFee";
import { parseEnvBundle } from "./envBundle";

// v388 — fixes from the Deep QA report of v382 (30 Oct 2026). One test group per fix.
const read = (f: string) => fs.readFileSync(f, "utf8");

describe("v388 · WhatsApp number paste", () => {
  it("'+91 98765 43210' pasted becomes the 10-digit number", () => {
    expect(waClean("+91 98765 43210")).toBe("9876543210");
    expect(waClean("091 98765 43210")).toBe("9876543210");
    expect(waClean("098765 43210")).toBe("9876543210");
    expect(waClean("98765 43210")).toBe("9876543210");
  });
  it("a real number that starts with 91 is not cut while typing", () => {
    expect(waClean("9198765432")).toBe("9198765432");
    expect(waClean("91987")).toBe("91987");
  });
});

describe("v388 · email links never point at the AI Studio / Cloud Run address", () => {
  it("publicSiteUrl", () => {
    expect(publicSiteUrl({ APP_URL: "https://ybexapp.ai.studio" })).toBe("https://ybexmedia.in");
    expect(publicSiteUrl({ APP_URL: "https://ybex-123.asia-southeast1.run.app" })).toBe("https://ybexmedia.in");
    expect(publicSiteUrl({ APP_URL: "http://localhost:3000" })).toBe("https://ybexmedia.in");
    expect(publicSiteUrl({})).toBe("https://ybexmedia.in");
    expect(publicSiteUrl({ APP_URL: "https://ybexmedia.in/" })).toBe("https://ybexmedia.in");
    expect(publicSiteUrl({ SITE_URL: "https://www.ybexmedia.in", APP_URL: "https://ybexapp.ai.studio" })).toBe("https://www.ybexmedia.in");
  });
  it("the mailers use it", () => {
    for (const f of ["backend/helpers.ts", "backend/emailLinks.ts", "backend/notificationService.ts", "backend/creatorApplication.ts", "backend/support_routes.ts", "backend/admin_pitch_leads_routes.ts", "backend/services/ugcDeadlineService.ts"]) {
      expect(read(f), f).toContain("publicSiteUrl");
      expect(read(f), f).not.toMatch(/process\.env\.APP_URL \|\| ["']https:\/\/ybexmedia\.in["']/);
    }
  });
});

describe("v388 · code-request limits per IP", () => {
  beforeEach(() => _resetLoginIpHits());
  it("allows 20 per 5 minutes, then stops, other IPs unaffected, window slides", () => {
    for (let i = 0; i < OTP_IP_PER_WINDOW; i++) expect(otpIpAllowed("1.1.1.1", 1000 + i)).toBe(true);
    expect(otpIpAllowed("1.1.1.1", 2000)).toBe(false);
    expect(otpIpAllowed("2.2.2.2", 2000)).toBe(true);
    expect(otpIpAllowed("1.1.1.1", 1000 + 5 * 60_000 + 50)).toBe(true);
  });
  it("login-otp and forgot-password use it", () => {
    const s = read("backend/auth_routes.ts");
    expect(s).toMatch(/\/auth\/login-otp[\s\S]{0,400}otpIpAllowed\(clientIp\(req\)\)/);
    expect(s).toMatch(/\/auth\/forgot-password[\s\S]{0,500}otpIpAllowed\(clientIp\(req\)\)/);
    expect(s).toMatch(/const email = String\(req\.body\?\.email \|\| ""\)\.trim\(\)\.toLowerCase\(\); \/\/ v388/);
  });
});

describe("v388 · blog HTML sanitizer (QA bypasses)", () => {
  const bad = [
    "<img/src=x/onerror=alert(1)>",
    '<a href="&#106;avascript:alert(1)">x</a>',
    '<a href="jav&#x61;script:alert(1)">x</a>',
    '<a href="  javascript:alert(1)">x</a>',
    "<svg><script>alert(1)</script></svg>",
    "<iframe src=//evil.example></iframe>",
    '<p onclick="x()">hi</p>',
    "<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>",
  ];
  for (const h of bad) it(`removes: ${h.slice(0, 40)}`, () => {
    const out = sanitizeHtml(h).toLowerCase();
    expect(out).not.toMatch(/<[a-z][^>]*\son[a-z]+\s*=/); // no event-handler attribute (text inside a quoted value is harmless)
    expect(out).not.toMatch(/javascript:|<script|<iframe|<svg|<style|<math/);
  });
  it("keeps normal article HTML", () => {
    const out = sanitizeHtml('<h2 id="a">Title</h2><p>Hi <strong>there</strong> <a href="https://ybexmedia.in/offer" target="_blank">link</a></p><img src="https://x.test/a.webp" alt="a"><ul><li>1</li></ul>');
    expect(out).toContain('<h2 id="a">Title</h2>');
    expect(out).toContain('href="https://ybexmedia.in/offer"');
    expect(out).toContain('rel="noopener noreferrer"');
    expect(out).toContain("<img");
    expect(out).toContain("<li>1</li>");
  });
  it("the reader page cleans the copy it injects", () => {
    expect(read("src/pages/blog/BlogPostDetail.jsx")).toContain('parser.parseFromString(sanitizeHtml(post.content), "text/html")');
  });
});

describe("v388 · robots.txt / sitemap", () => {
  it("public creator and brand profile pages are no longer blocked; private screens are", () => {
    const r = robotsTxt("https://ybexmedia.in");
    expect(r).not.toMatch(/Disallow: \/creator\/\n/);
    expect(r).not.toMatch(/Disallow: \/brand\/\n/);
    expect(r).toContain("Disallow: /creator/dashboard");
    expect(r).toContain("Disallow: /brand/payments");
    expect(r).toContain("Disallow: /admin");
  });
  it("sitemap has /offer, /explore, /campaigns and not the old apply form", () => {
    const x = sitemapXml("https://ybexmedia.in", []);
    for (const p of ["/offer", "/explore", "/campaigns", "/terms"]) expect(x).toContain(`https://ybexmedia.in${p}<`);
    expect(x).not.toContain("/apply-creator");
  });
});

describe("v388 · fee config: a failed read never replaces the last good one", () => {
  it("keeps the split 0% / 8% model through a Supabase hiccup", async () => {
    __resetFeeConfigCache();
    const row = { fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8 };
    const chain = (res: any) => ({ select: () => ({ order: () => ({ limit: () => ({ maybeSingle: async () => res }) }) }) });
    let next: any = { data: row, error: null };
    const client = { from: () => chain(next) };
    expect(await loadFeeConfig(client, 0)).toEqual(row);
    next = { data: null, error: { message: "boom" } };
    expect(await loadFeeConfig(client, 0)).toEqual(row); // hiccup → still the good one
    next = { data: null, error: null };
    __resetFeeConfigCache();
    expect(await loadFeeConfig(client, 0)).toBeNull(); // genuinely no config row
  });
});

describe("v388 · YBEX_ENV multi-line and base64 values", () => {
  it("a quoted multi-line key is read whole", () => {
    const p = parseEnvBundle('A=1\nAPNS_KEY="-----BEGIN PRIVATE KEY-----\nMIGT\nQQ==\n-----END PRIVATE KEY-----"\nB=2');
    expect(p.APNS_KEY).toBe("-----BEGIN PRIVATE KEY-----\nMIGT\nQQ==\n-----END PRIVATE KEY-----");
    expect(p.A).toBe("1"); expect(p.B).toBe("2");
  });
  it("KEY_B64 is decoded into KEY", () => {
    const j = '{"private_key":"x\ny"}';
    const p = parseEnvBundle(`FCM_SERVICE_ACCOUNT_JSON_B64=${Buffer.from(j).toString("base64")}`);
    expect(p.FCM_SERVICE_ACCOUNT_JSON).toBe(j);
  });
  it("an unclosed quote does not swallow the rest of the file", () => {
    const p = parseEnvBundle('A="oops\nB=2\nC=3');
    expect(p.B).toBe("2"); expect(p.C).toBe("3");
  });
});

describe("v388 · session lookup: a DB error is not a logout", () => {
  it("server marks the request and /auth/me answers 503 SERVER_DOWN", () => {
    const srv = read("backend/server.ts");
    expect(srv).toContain("AUTH_DB_UNAVAILABLE");
    expect(srv).toContain("req._authDbError = true");
    expect(read("backend/auth_routes.ts")).toMatch(/\(req as any\)\._authDbError\) && \/\^Bearer/);
  });
});

describe("v388 · account codes", () => {
  it("WhatsApp-only accounts are told to add an email; a failed mail is an error, not 'sent'", () => {
    const s = read("backend/account_routes.ts");
    expect(s).toContain("ADD_EMAIL_FIRST");
    expect(s).toContain("OTP_SEND_FAILED");
    expect((s.match(/PLACEHOLDER_EMAIL\.test\(email\)/g) || []).length).toBe(2);
  });
});

describe("v388 · notifications", () => {
  it("push loop continues from (created_at, id) after a full batch", () => {
    const s = read("backend/push_routes.ts");
    expect(s).toContain("lastFull");
    expect(s).toContain("id.gt.${cursorId}");
    expect(s).toMatch(/for \(let pass = 0; pass < 5; pass\+\+\)/);
  });
  it("profile nudges skip unclaimed CSV profiles", () => {
    expect(read("backend/profileNudges.ts")).toContain('u.auth_method !== "unclaimed"');
  });
});

describe("v388 · small UI / infra items", () => {
  it("/offer FAQ says ₹300 now", () => {
    const s = read("src/pages/ChallengePage.jsx");
    expect(s).not.toContain("get ₹50 by UPI");
    expect(s).toContain("What is the ₹300 cash?");
  });
  it("missing /assets files are a 404 and hashed assets are cached for a year", () => {
    const s = read("backend/server.ts");
    expect(s).toContain("app.get(/^\\/assets\\//");
    expect(s).toContain("max-age=31536000, immutable");
  });
  it("Cloudflare worker gives API calls 60 s", () => {
    expect(read("cloudflare/ybex-proxy-worker.js")).toContain("API_TIMEOUT_MS = 60000");
  });
  it("install banner: not in the store apps / admin; popup not on legal pages", () => {
    const s = read("src/components/common/PWAInstallPrompt.jsx");
    expect(s).toContain("onAdmin");
    expect(s).toMatch(/POPUP_PAGES = [^\n]*\)\/;/);
    expect(s).not.toMatch(/const POPUP_PAGES = [^\n]*info\\\//);
  });
  it("Android build script no longer pins 1.0.4 and the OTA zip skips the iPhone splash PNGs", () => {
    expect(read("android-app/scripts/mac-prepare-android.sh")).not.toContain('VERSION_NAME="1.0.4"');
    expect(read("scripts/ota-bundle.mjs")).toContain("/^splash\\//");
  });
});
