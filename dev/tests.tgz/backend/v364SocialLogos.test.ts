// v364 (Ravi: "Social_Logos_offline.html — jahan jahan in apps ke logo lagenge, waha ye laga"): one shared component with
// the real marks, used across the app instead of generic icons / letter boxes.
import { describe, it, expect } from "vitest";
import fs from "fs";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import SocialLogo, { SOCIAL_PLATFORMS, socialPlatformOf, logoIcon, SocialAppIcon } from "../src/components/common/SocialLogo.jsx";

const read = (p: string) => fs.readFileSync(p, "utf8");
const html = (el: any) => renderToStaticMarkup(el);

describe("v364 · SocialLogo", () => {
  it("renders every platform in color, mono and tile, with no external links", () => {
    for (const p of SOCIAL_PLATFORMS) {
      for (const variant of ["color", "mono", "tile"]) {
        const out = html(React.createElement(SocialLogo, { platform: p, size: 24, variant }));
        expect(out, `${p}/${variant}`).toContain("<svg");
        expect(out).not.toMatch(/(src|href)="https?:/);
      }
    }
  });

  it("uses the exact marks from Ravi's file", () => {
    expect(html(React.createElement(SocialLogo, { platform: "facebook" }))).toContain("#0866FF");
    expect(html(React.createElement(SocialLogo, { platform: "whatsapp" }))).toContain("#25D366");
    expect(html(React.createElement(SocialLogo, { platform: "youtube" }))).toContain("#FF0000");
    const ig = html(React.createElement(SocialLogo, { platform: "instagram" }));
    expect(ig).toContain("#FFD600");
    expect(ig).toContain("#7638FA");
    expect(html(React.createElement(SocialLogo, { platform: "meta" }))).toContain("#0064E1");
  });

  it("two Instagram logos on one page don't share gradient ids", () => {
    const out = html(React.createElement("div", null, React.createElement(SocialLogo, { platform: "instagram" }), React.createElement(SocialLogo, { platform: "instagram" })));
    const ids = [...out.matchAll(/id="([^"]+)"/g)].map((m) => m[1]);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("maps what screens store to a platform", () => {
    expect(socialPlatformOf("Instagram")).toBe("instagram");
    expect(socialPlatformOf("https://www.instagram.com/reel/abc")).toBe("instagram");
    expect(socialPlatformOf("YouTube Short")).toBe("youtube");
    expect(socialPlatformOf("youtu.be/x")).toBe("youtube");
    expect(socialPlatformOf("yt")).toBe("youtube");
    expect(socialPlatformOf("X")).toBe("x");
    expect(socialPlatformOf("twitter")).toBe("x");
    expect(socialPlatformOf("LinkedIn")).toBe("linkedin");
    expect(socialPlatformOf("fb")).toBe("facebook");
    expect(socialPlatformOf("Snapchat")).toBe("snapchat");
    expect(socialPlatformOf("WhatsApp")).toBe("whatsapp");
    expect(socialPlatformOf("Threads")).toBe("threads");
    expect(socialPlatformOf("Blog")).toBeNull();
    expect(html(React.createElement(SocialLogo, { platform: "Blog" }))).toBe("");
  });

  it("logoIcon / SocialAppIcon drop-ins render", () => {
    const Ig = logoIcon("instagram");
    expect(logoIcon("instagram")).toBe(Ig); // stable component (no remounts)
    expect(html(React.createElement(Ig, { size: 18 }))).toContain('width="18"');
    expect(html(React.createElement(SocialAppIcon, { platform: "x" }))).toContain("#000000");
    expect(html(React.createElement(SocialAppIcon, { platform: "instagram" }))).toContain('width="100%"');
  });

  it("is used on the main screens (no generic icon left there)", () => {
    for (const f of [
      "src/pages/creator/CreatorMobileProfile.jsx", "src/pages/onboarding/CreatorOnboardingMobile.jsx", "src/pages/onboarding/BrandOnboardingMobile.jsx",
      "src/components/instagram/InstagramConnectCard.jsx", "src/components/instagram/ConnectInstagramSheet.jsx", "src/components/instagram/HubInstagramStrip.jsx",
      "src/pages/creator/CreatorPublicView.jsx", "src/components/ugc/CreatorCard.jsx", "src/pages/dashboard/Refer.jsx", "src/components/help/SupportContactCard.jsx",
    ]) {
      expect(read(f), f).toMatch(/SocialLogo|SocialAppIcon|logoIcon/);
    }
    expect(read("src/pages/onboarding/BrandOnboardingMobile.jsx")).not.toMatch(/<(Instagram|Youtube|Twitter|Linkedin|Facebook)\s/);
    expect(read("src/pages/creator/CreatorMobileProfile.jsx")).not.toMatch(/icon: (Instagram|Youtube|Ghost|Linkedin|Facebook),/);
  });

  it("public/assets logos are the real marks (used by older screens as <img>)", () => {
    expect(read("public/assets/facebook.svg")).toContain("#0866FF");
    expect(read("public/assets/instagram.svg")).toContain("#FFD600");
    expect(read("public/assets/youtube.svg")).toContain("#FF0000");
    expect(read("public/assets/linkedin.svg")).toContain("#0A66C2");
    for (const f of ["facebook", "instagram", "youtube", "linkedin", "snapchat", "x", "threads"]) {
      expect(read(`public/assets/${f}.svg`)).not.toContain("c2pa");
    }
  });
});
