// v343 (Ravi's screenshots, 19 Oct 2026): popups under the bottom bar / page text, wrong footer copy for brands,
// big gap on the creator profile, promo ✕ over the poster, landing hand / corners / scroll, admin-picked creators
// on the landing page, and no limit on how many creators the admin puts on the home screen.
import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { landingCreatorCards, HOME_PICKS_LIST } from "./creatorHomePicks";
import { landingWallCards } from "../src/components/landing/v2/landingContent.js";

const root = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(root, p), "utf8");

describe("v343 — popups always on top", () => {
  it("the page wrapper no longer uses framer-motion (it trapped every popup under the footer / bottom nav)", () => {
    const app = read("src/App.jsx");
    const page = app.slice(app.indexOf("function Page("), app.indexOf("function KycRedirect"));
    expect(page).not.toContain("motion.div");
    expect(page).toContain("yb-page-in");
    const css = read("src/index.css");
    expect(css).toMatch(/\.yb-page-in \{[^}]*animation-fill-mode: backwards/);
  });

  it("Schedule Call sheet is drawn on <body> and its date box stays inside the screen", () => {
    const s = read("src/pages/brand/brandHome/ScheduleCallModal.jsx");
    expect(s).toContain("createPortal(");
    expect(s).toContain("document.body");
    expect(s).toContain('minWidth: 0');
    expect(read("src/index.css")).toContain('input[type="date"], input[type="time"]');
  });

  it("footer headline has no z-index of its own", () => {
    expect(read("src/components/layout/PremiumFooter.jsx")).not.toContain("opacity-15 leading-[1.1] relative z-10");
  });
});

describe("v343 — footer copy matches who is looking", () => {
  const layout = read("src/components/layout/Layout.jsx");
  it("brand on /dashboard gets the brand line, not 'Built For Creators.'", () => {
    expect(layout).toContain('if (path === "/dashboard" && isBrandUser) return config["/brand/dashboard"];');
  });
  it("brand looking at a creator profile never reads 'This is how brands see you.'", () => {
    expect(layout).toMatch(/isBrandUser && \/\^\\\/creator\\\/\[\^\/\]\+\$\/\.test\(path\)/);
  });
  it("/creators (brand search) no longer talks to creators", () => {
    expect(layout).not.toContain('"/creators": { headline: ["Discover Brands That", "Match Your Voice."]');
  });
});

describe("v343 — promo poster", () => {
  const s = read("src/components/promo/PromoPopup.jsx");
  it("only for signed-in people", () => { expect(s).toContain("if (!user) return;"); });
  it("centre card ✕ sits above the card, not on the poster", () => {
    expect(s).toContain('L === "card" ? -52');
  });
});

describe("v343 — creator home picks", () => {
  it("no cap on how many the admin ticks", () => {
    const s = read("backend/creatorHomePicks.ts");
    expect(s).not.toContain("Untick one first");
    expect(s).not.toContain("HOME_PICKS_FULL");
    expect(HOME_PICKS_LIST).toBeGreaterThanOrEqual(12);
  });

  it("landing cards: approved creators with a photo, card fields only", () => {
    const rows = [
      { user_id: "a", name: "Ankit Tomar", picture: "https://x/a.jpg", category: "Lifestyle", city: "Delhi", email: "a@x.com", phone: "999" },
      { user_id: "b", name: "No Photo", picture: "" },
      { user_id: "c", name: "Test user", picture: "https://x/c.jpg" },
      { user_id: "d", name: "Pending", picture: "https://x/d.jpg", profile_status: "pending" },
    ];
    const out = landingCreatorCards(rows);
    expect(out).toEqual([{ id: "a", name: "Ankit Tomar", picture: "https://x/a.jpg", category: "Lifestyle", city: "Delhi" }]);
  });

  it("public GET /landing-creators exists and the landing page reads it", () => {
    expect(read("backend/creatorHomePicks.ts")).toContain('router.get("/landing-creators"');
    expect(read("src/components/landing/v2/landingContent.js")).toContain('api.get("/landing-creators")');
  });

  it("wall: 9 real tiles, never a grey placeholder; falls back to the design photos", () => {
    const two = [["A", "x", "/a.png"], ["B", "y", "/b.png"]];
    const w = landingWallCards(two, []);
    expect(w).toHaveLength(9);
    expect(w.every((c: any) => c.real && !c.slot)).toBe(true);
    const ORDER = [[0, 5, 6], [3, 1, 7], [4, 8, 2]];
    for (let n = 2; n <= 12; n++) {
      const list = Array.from({ length: n }, (_, i) => [`C${i}`, "", `/c${i}.png`]);
      const all = landingWallCards(list, []);
      const at = (c: number, r: number) => all[ORDER[c][r]].name;
      for (let c = 0; c < 3; c++) for (let r = 0; r < 3; r++) {
        if (c < 2) expect(at(c, r)).not.toBe(at(c + 1, r)); // side by side
        if (r < 2) expect(at(c, r)).not.toBe(at(c, r + 1)); // one above the other
      }
      if (n >= 9) expect(new Set(all.map((x: any) => x.name)).size).toBe(9);
    }
    expect(landingWallCards([], [["F", "z", "/f.png"]])[0].name).toBe("F");
    for (const f of ["src/components/landing/v2/LandingMobileView.jsx", "src/components/landing/v2/LandingDesktopView.jsx"]) {
      const s = read(f);
      expect(s).toContain("landingWallCards(");
      expect(s).not.toContain("['Creator', 'Fashion · Mumbai']");
    }
  });
});

describe("v343 — landing page", () => {
  const m = read("src/components/landing/v2/LandingMobileView.jsx");
  it("broken right-hand cut-out is gone; the fixed photo is used on phone and desktop", () => {
    expect(m).not.toContain("57832b0e.png");
    // v350 (requirement change — Ravi sent new design files): the designer's new photo np-reader-v350.webp replaces v343's.
    expect(m).toContain("/landing/np-reader-v350.webp");
    expect(read("src/components/landing/v2/LandingDesktopView.jsx")).toContain("/landing/np-reader-v350.webp");
    expect(fs.existsSync(path.join(root, "public/landing/np-reader-v350.webp"))).toBe(true);
  });
  it("payment card glows are clipped to the rounded corners", () => {
    expect(m).toContain('clipPath: "inset(0 round 30px)"');
  });
  it("scroll: the box keeps its scroll, the browser page never scrolls, timers wait during a swipe", () => {
    expect(m).toContain("overscrollBehavior: 'contain'");
    expect(m).toContain("this.lastScrollAt = Date.now()");
    expect(m).toContain("this.idle() && this.setState");
    expect(read("src/index.css")).toContain('html:has([data-testid="landing-v2"])');
  });
});
