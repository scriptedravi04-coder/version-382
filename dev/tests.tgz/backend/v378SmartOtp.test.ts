// v378: Fast2SMS Smart OTP (WhatsApp / DLT SMS template) — provider pick, channel wording, request shape.
import { describe, it, expect, vi, afterEach } from "vitest";
import axios from "axios";
import { smsProvider, otpChannel, sendSmsOtp } from "./smsOtp";

afterEach(() => vi.restoreAllMocks());

describe("v378 Fast2SMS Smart OTP", () => {
  it("picks Smart OTP only when the template id is set", () => {
    expect(smsProvider({ FAST2SMS_API_KEY: "k" })).toBe("fast2sms");
    expect(smsProvider({ FAST2SMS_API_KEY: "k", FAST2SMS_OTP_ID: "123" })).toBe("fast2sms_smart");
    expect(smsProvider({ FAST2SMS_OTP_ID: "123" })).toBe(null);
  });
  it("channel: WhatsApp by default for Smart OTP, SMS otherwise", () => {
    expect(otpChannel({ FAST2SMS_API_KEY: "k", FAST2SMS_OTP_ID: "1" })).toBe("whatsapp");
    expect(otpChannel({ FAST2SMS_API_KEY: "k", FAST2SMS_OTP_ID: "1", FAST2SMS_OTP_CHANNEL: "SMS" })).toBe("sms");
    expect(otpChannel({ FAST2SMS_API_KEY: "k" })).toBe("sms");
    expect(otpChannel({})).toBe("sms");
  });
  it("sends our own code to /dev/otp/send with the template id", async () => {
    const post = vi.spyOn(axios, "post").mockResolvedValue({ data: { return: true } } as any);
    const r = await sendSmsOtp("9876543210", "123456", { FAST2SMS_API_KEY: " key ", FAST2SMS_OTP_ID: " 77 " });
    expect(r.ok).toBe(true);
    const [url, body, cfg] = post.mock.calls[0] as any;
    expect(url).toBe("https://www.fast2sms.com/dev/otp/send");
    expect(body).toMatchObject({ mobile: "9876543210", otp_id: "77", otp: "123456", otp_length: 6 });
    expect(cfg.headers.authorization).toBe("key");
  });
  it("reports a refusal without throwing", async () => {
    vi.spyOn(axios, "post").mockResolvedValue({ data: { return: false, message: "Invalid OTP template" } } as any);
    const r = await sendSmsOtp("9876543210", "123456", { FAST2SMS_API_KEY: "k", FAST2SMS_OTP_ID: "1" });
    expect(r).toEqual({ ok: false, error: "Invalid OTP template" });
  });
});
