import { describe, it, expect, beforeEach, afterEach } from "vitest";
import fs from "node:fs";
import { _resetEphemeral, configureEphemeralStore } from "./ephemeralStore";
import {
  dailyLimit, inLowWindow, lowPriorityBudget, addSent, sentToday, queueLowEmail, queuedLowEmails, flushLowEmails, markQuotaFull, isQuotaError,
} from "./emailBudget";

// v399 (Ravi 4 Nov: Resend free plan, 100 mails a day, quota ran out): login / OTP mails always go now; everything else
// waits and goes in the night before the daily reset, only as many as today still allows — the rest keeps waiting.
const DAY = (h: number, m = 0) => new Date(Date.UTC(2026, 10, 4, h, m));
const read = (p: string) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v399 email budget", () => {
  const env = { ...process.env };
  beforeEach(() => { configureEphemeralStore(null); _resetEphemeral(); delete process.env.RESEND_DAILY_LIMIT; delete process.env.EMAIL_LOW_WINDOW_UTC; });
  afterEach(() => { process.env = { ...env }; });

  it("free plan = 100 a day; 0 means a paid plan with no daily limit", () => {
    expect(dailyLimit()).toBe(100);
    process.env.RESEND_DAILY_LIMIT = "0";
    expect(dailyLimit()).toBe(0);
  });

  it("low-priority mails get no budget in the day, and in the night only what is left", async () => {
    expect(inLowWindow(DAY(10))).toBe(false);          // 3:30 pm IST
    expect(inLowWindow(DAY(22, 30))).toBe(true);       // 4:00 am IST
    expect(await lowPriorityBudget(DAY(10))).toBe(0);
    await addSent(60, DAY(9));
    expect(await sentToday(DAY(9))).toBe(60);
    expect(await lowPriorityBudget(DAY(22, 30))).toBe(37); // 100 - 3 safety - 60 used
    await markQuotaFull(DAY(23));
    expect(await lowPriorityBudget(DAY(23))).toBe(0);
  });

  it("queued mails go at night up to the budget; the rest keep waiting for the next night", async () => {
    await addSent(92, DAY(8)); // 5 left after the safety margin
    for (let i = 0; i < 8; i++) await queueLowEmail({ to: [`c${i}@mail.com`], subject: `hi ${i}`, html: "x", priority: "low" }, new Date(DAY(9).getTime() + i));
    expect((await queuedLowEmails()).length).toBe(8);
    const sent: string[] = [];
    const daytime = await flushLowEmails(async (o) => { sent.push(o.to[0]); return { data: { id: "x" } }; }, DAY(12));
    expect(daytime.sent).toBe(0);
    const night = await flushLowEmails(async (o) => { sent.push(o.to[0]); return { data: { id: "x" } }; }, DAY(23));
    expect(night.sent).toBe(5);
    expect(sent).toEqual(["c0@mail.com", "c1@mail.com", "c2@mail.com", "c3@mail.com", "c4@mail.com"]); // oldest first
    expect(night.left_waiting).toBe(3);
    expect(sent.every((t) => !t.includes("priority"))).toBe(true);
  });

  it("stops the night run as soon as Resend says the quota is used up", async () => {
    for (let i = 0; i < 3; i++) await queueLowEmail({ to: [`d${i}@mail.com`], subject: "s", html: "x" }, new Date(DAY(9).getTime() + i));
    let calls = 0;
    const r = await flushLowEmails(async () => { calls++; return { error: { name: "daily_quota_exceeded", message: "You have reached your daily email sending quota" } }; }, DAY(23));
    expect(calls).toBe(1);
    expect(r.left_waiting).toBe(3);
    expect(isQuotaError({ statusCode: 429 })).toBe(true);
  });

  it("only non-urgent senders are low priority; codes and payments are never tagged", () => {
    for (const f of ["./onboardingReminders.ts", "./notificationService.ts", "./services/ugcDeadlineService.ts"]) {
      expect(read(f)).toMatch(/priority: "low"/);
    }
    const auth = read("./auth_routes.ts");
    expect((auth.match(/priority: "low"/g) || []).length).toBe(1); // only the welcome note
    expect(auth).toMatch(/resendWelcome\.emails\.send\(\{ priority: "low"/);
    expect(read("./account_routes.ts")).not.toMatch(/priority: "low"/);
    expect(read("./session_routes.ts")).not.toMatch(/priority: "low"/);
    expect(read("./ugc_routes.ts")).not.toMatch(/priority: "low"/);
    expect(read("./creators_routes.ts")).not.toMatch(/priority: "low"/); // locked invite flow, untouched
    expect(read("./creatorApplication.ts")).not.toMatch(/priority: "low"/); // waitlist approval mail goes now
    expect(read("./emailBroadcasts.ts")).toMatch(/lowPriorityBudget\(\)/);
    expect(read("./helpers.ts")).toMatch(/queueLowEmail\(options\)/);
  });
});

describe("v400 no e-mail for admin bell notices and profile nudges", () => {
  it("user_registered / kyc_submitted / profile nudges stay bell + push only; staff @admin.ybex logins get no e-mail", async () => {
    const { NO_EMAIL_TYPES } = await import("./notificationService");
    expect([...NO_EMAIL_TYPES].sort()).toEqual(["KYC_SUBMITTED", "PHOTO_NUDGE", "PROFILE_NUDGE", "USER_REGISTERED"]); // v402: + photo nudge
    const src = read("./notificationService.ts");
    expect(src).toMatch(/if \(NO_EMAIL_TYPES\.has\(normType\)\) return;/);
    expect(src).toContain("@admin\\.ybex$/i.test");
  });
});

describe("v400 activity e-mails: deal / campaign / payment right away", () => {
  it("campaign, application, deal, UGC, payout and refund notices are high; KYC and new-work digests wait", async () => {
    const { activityEmailPriority } = await import("./notificationService");
    for (const t of ["CAMPAIGN_LIVE", "APPLICATION_ACCEPTED", "NEW_APPLICATION", "DEAL_OFFER", "DEAL_ACCEPTED", "UGC_ORDER_CLAIMED", "UGC_DRAFT_SUBMITTED", "PAYOUT_SENT", "REFUND_PROCESSED", "CAMPAIGN_INVITE", "REVISION_REQUESTED"]) {
      expect(activityEmailPriority(t)).toBe("high");
    }
    for (const t of ["KYC_APPROVED", "kyc_update", "ASSIST_NEW_CREATORS", "ADMIN_MESSAGE", "system"]) {
      expect(activityEmailPriority(t)).toBe("low");
    }
    expect(read("./notificationService.ts")).toMatch(/priority: activityEmailPriority\(type\)/);
  });
});
