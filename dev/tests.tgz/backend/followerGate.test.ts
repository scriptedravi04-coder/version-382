// v397 (Ravi, 2 Nov 2026): new creators need 500+ Instagram followers; below that they can share one work link.
import { describe, it, expect } from "vitest";
import fs from "fs";
import { belowMinFollowers, profileFollowers, cleanWorkLink, setupFollowerGate, MIN_FOLLOWERS, LOW_FOLLOWERS_SOURCE } from "./followerGate";
import { validateApplication } from "./creatorApplication";
import { cleanMinFollowers, getMinFollowers, _resetMinFollowersCache } from "./followerMin";

function fakeDb(seed: Record<string, any[]> = {}) {
  const t: Record<string, any[]> = { waitlist: [], creator_profiles: [], ...seed };
  const from = (name: string) => {
    const filters: Array<(r: any) => boolean> = [];
    const q: any = {
      select() { return q; },
      eq(c: string, v: any) { filters.push((r) => String(r[c]) === String(v)); return q; },
      ilike(c: string, v: string) { filters.push((r) => String(r[c] || "").toLowerCase() === String(v).replace(/\\/g, "").toLowerCase()); return q; },
      limit() { return Promise.resolve({ data: t[name].filter((r) => filters.every((f) => f(r))), error: null }); },
      maybeSingle() { return Promise.resolve({ data: t[name].find((r) => filters.every((f) => f(r))) || null, error: null }); },
      insert(rows: any[]) { t[name].push(...rows); return Promise.resolve({ error: null }); },
      update(patch: any) { return { eq(c: string, v: any) { t[name].filter((r) => String(r[c]) === String(v)).forEach((r) => Object.assign(r, patch)); return Promise.resolve({ error: null }); } }; },
    };
    return q;
  };
  return { t, from };
}

function mount(db: any, user: any) {
  const routes: Record<string, any> = {};
  const router: any = { get: (p: string, h: any) => { routes["GET " + p] = h; }, post: (p: string, h: any) => { routes["POST " + p] = h; } };
  setupFollowerGate(router, { supabase: db, privilegedSupabase: db, parseAuthUser: async () => user });
  const call = async (key: string, body: any = {}) => {
    let status = 200; let json: any; let nexted = false;
    const res: any = { status(s: number) { status = s; return res; }, json(j: any) { json = j; return res; } };
    await routes[key]({ body }, res, () => { nexted = true; });
    return { status, json, nexted };
  };
  return call;
}

const creator = { user_id: "u1", role: "creator", email: "riya@example.in", name: "Riya" };

describe("v397 follower gate — numbers", () => {
  it("only a known number under 500 is blocked", () => {
    expect(MIN_FOLLOWERS).toBe(500);
    expect(belowMinFollowers(499)).toBe(true);
    expect(belowMinFollowers(500)).toBe(false);
    expect(belowMinFollowers(null)).toBe(false);
    expect(belowMinFollowers("")).toBe(false);
    expect(belowMinFollowers(0)).toBe(false); // empty profile column
    expect(belowMinFollowers(0, true)).toBe(true); // Meta said 0
  });
  it("profile followers = the highest column", () => {
    expect(profileFollowers({ follower_count: 120, followers_instagram: 0 })).toBe(120);
    expect(profileFollowers({ ig_followers: 900, follower_count: 300 })).toBe(900);
    expect(profileFollowers({})).toBe(null);
  });
  it("work links", () => {
    expect(cleanWorkLink("drive.google.com/x")).toBe("https://drive.google.com/x");
    expect(cleanWorkLink("javascript:alert(1)")).toBe(null);
    expect(cleanWorkLink("hello")).toBe(null);
  });
});

describe("v397 follower gate — finishing sign-up", () => {
  it("a new creator with 312 followers cannot submit the profile", async () => {
    const db = fakeDb({ creator_profiles: [{ user_id: "u1", follower_count: 312 }] });
    const r = await mount(db, creator)("POST /creators/profile", { onboarding_complete: true, profile_status: "under_review" });
    expect(r.status).toBe(403);
    expect(r.json.code).toBe("LOW_FOLLOWERS");
    expect(r.nexted).toBe(false);
  });
  it("600 followers, an existing creator, an ordinary profile save and a team-approved creator all pass", async () => {
    const ok = async (rows: any[], body: any = { onboarding_complete: true }, wl: any[] = []) =>
      (await mount(fakeDb({ creator_profiles: rows, waitlist: wl }), creator)("POST /creators/profile", body)).nexted;
    expect(await ok([{ user_id: "u1", follower_count: 600 }])).toBe(true);
    expect(await ok([{ user_id: "u1", follower_count: 120, onboarding_complete: true }])).toBe(true);
    expect(await ok([{ user_id: "u1", follower_count: 120 }], { bio: "hi" })).toBe(true);
    expect(await ok([{ user_id: "u1", follower_count: 120 }], { onboarding_complete: true },
      [{ id: "w1", linked_user_id: "u1", source: LOW_FOLLOWERS_SOURCE, status: "Approved" }])).toBe(true);
    expect(await ok([{ user_id: "u1", follower_count: 120, reviewed_at: "2026-11-01", profile_status: "approved" }])).toBe(true);
  });
});

describe("v397 follower gate — work link", () => {
  it("saves one waitlist row for the team, then adds links to the same row", async () => {
    const db = fakeDb();
    const call = mount(db, creator);
    expect((await call("POST /creator/follower-gate/work", { link: "bad" })).status).toBe(400);
    const r = await call("POST /creator/follower-gate/work", { link: "instagram.com/reel/abc", handle: "@riya", followers: 312 });
    expect(r.json.ok).toBe(true);
    expect(db.t.waitlist).toHaveLength(1);
    expect(db.t.waitlist[0]).toMatchObject({ source: LOW_FOLLOWERS_SOURCE, status: "Pending", linked_user_id: "u1", followers: 312, social_handle: "riya", sample_links: ["https://instagram.com/reel/abc"] });
    await call("POST /creator/follower-gate/work", { link: "https://drive.google.com/x" });
    expect(db.t.waitlist).toHaveLength(1);
    expect(db.t.waitlist[0].sample_links).toEqual(["https://instagram.com/reel/abc", "https://drive.google.com/x"]);
    const g = await call("GET /creator/follower-gate");
    expect(g.json).toMatchObject({ min: 500, exempt: false, submitted: true, link: "https://drive.google.com/x" });
  });
  it("brands and logged-out people can't use it", async () => {
    const r = await mount(fakeDb(), { user_id: "b1", role: "brand" })("POST /creator/follower-gate/work", { link: "https://x.com/a" });
    expect(r.status).toBe(403);
  });
});

describe("v397 apply form + screens", () => {
  const base = { photo: "data:image/png;base64,x", name: "Asha", gender: "Female", email: "a@b.in", mobile: "9876543210", social_handle: "@asha", city: "Jaipur", avg_reach: "200", charges: "500", niche: "Beauty" };
  it("the apply form accepts small accounts (saved as work shares by the handler)", () => {
    expect(validateApplication({ ...base, followers: "250" }).errors.followers).toBeUndefined();
    const src = fs.readFileSync("backend/creatorApplication.ts", "utf8");
    expect(src).toContain('source: minFollowers > 0 && value.followers < minFollowers ? LOW_FOLLOWERS_SOURCE : "creator_apply_form"');
  });
  it("the gate is mounted before the profile save, and the screens carry Ravi's lines", () => {
    const server = fs.readFileSync("backend/server.ts", "utf8");
    expect(server.indexOf("setupFollowerGate(router")).toBeGreaterThan(0);
    expect(server.indexOf("setupFollowerGate(router")).toBeLessThan(server.indexOf("setupCreatorsRoutes(app, router"));
    const copy = fs.readFileSync("src/lib/followerGate.js", "utf8");
    for (const line of ["Every big creator started small.", "Brands on Ybex look for", "You're closer than you think.", "Drop your best work link below.",
      "If it matches brand standards, someone from the Ybex team will personally message you."]) expect(copy).toContain(line);
    expect(copy).not.toMatch(/no bots|waiting list/i);
  });
});

describe("v397 admin-set minimum (Admin → Waitlist)", () => {
  it("only admins read / change it; 0 turns the lock off; the guard follows the new number", async () => {
    _resetMinFollowersCache();
    expect(cleanMinFollowers("1,000")).toBe(1000);
    expect(cleanMinFollowers("-5")).toBe(null);
    expect(cleanMinFollowers("abc")).toBe(null);
    expect(cleanMinFollowers("200000")).toBe(null);
    const admin = { user_id: "a1", role: "admin", email: "admin@ybex.in" };
    expect((await mount(fakeDb(), creator)("POST /admin/follower-gate", { min: 300 })).status).toBe(403);
    expect((await mount(fakeDb(), admin)("POST /admin/follower-gate", { min: "x" })).status).toBe(400);
    const r = await mount(fakeDb(), admin)("POST /admin/follower-gate", { min: "300" });
    expect(r.json).toMatchObject({ ok: true, min: 300 });
    expect(await getMinFollowers()).toBe(300);
    expect((await mount(fakeDb(), admin)("GET /admin/follower-gate")).json.min).toBe(300);
    expect((await mount(fakeDb(), null)("GET /public/follower-gate")).json.min).toBe(300);
    // 312 followers now passes, 250 doesn't
    const pass = async (n: number) => (await mount(fakeDb({ creator_profiles: [{ user_id: "u1", follower_count: n }] }), creator)("POST /creators/profile", { onboarding_complete: true })).nexted;
    expect(await pass(312)).toBe(true);
    expect(await pass(250)).toBe(false);
    await mount(fakeDb(), admin)("POST /admin/follower-gate", { min: 0 });
    expect(await pass(5)).toBe(true); // 0 = no limit
    await mount(fakeDb(), admin)("POST /admin/follower-gate", { min: 500 });
    expect(belowMinFollowers(312, false, 0)).toBe(false);
  });
});

describe("v397 sub-admin permission for the follower setting", () => {
  it("/admin/follower-gate needs settings_signup (or all settings)", async () => {
    const { requiredAdminPermission, acceptedPermissions } = await import("./adminPermissions");
    expect(requiredAdminPermission("POST", "/admin/follower-gate")).toBe("settings_signup");
    expect(acceptedPermissions("settings_signup")).toEqual(["settings_signup", "manage_settings"]);
  });
});

describe("v397 Instagram never read → can't finish sign-up (Ravi, 3 Nov)", () => {
  it("no follower number at all → 403 IG_NOT_VERIFIED; team-approved still passes; note says why", async () => {
    _resetMinFollowersCache();
    const r = await mount(fakeDb({ creator_profiles: [{ user_id: "u1" }] }), creator)("POST /creators/profile", { onboarding_complete: true });
    expect(r.status).toBe(403); expect(r.json.code).toBe("IG_NOT_VERIFIED");
    const ok = await mount(fakeDb({ creator_profiles: [{ user_id: "u1" }], waitlist: [{ id: "w1", linked_user_id: "u1", source: LOW_FOLLOWERS_SOURCE, status: "Approved" }] }), creator)("POST /creators/profile", { onboarding_complete: true });
    expect(ok.nexted).toBe(true);
    const db = fakeDb();
    await mount(db, creator)("POST /creator/follower-gate/work", { link: "https://instagram.com/reel/a", handle: "riya", reason: "unverified" });
    expect(db.t.waitlist[0].notes).toContain("Instagram couldn't be read");
    expect(db.t.waitlist[0].followers).toBe(null);
  });
});

describe("v397 new sign-ups aren't asked to accept the Terms again (Ravi, 3 Nov)", () => {
  it("an account made in the last 7 days counts as just signed up", async () => {
    const { isNewSignup } = await import("./consents");
    const now = Date.parse("2026-11-03T08:00:00Z");
    expect(isNewSignup("2026-11-03T07:59:00Z", now)).toBe(true);
    expect(isNewSignup("2026-10-28T08:00:00Z", now)).toBe(true);
    expect(isNewSignup("2026-10-20T08:00:00Z", now)).toBe(false);
    expect(isNewSignup(null, now)).toBe(false);
    const src = fs.readFileSync("backend/consents.ts", "utf8");
    expect(src).toContain('source: "signup_screen"');
    expect(src).toContain("!consents?.terms && isNewSignup(");
  });
  it("'One last step' shows rotating creator photos + Trusted by 3,000+ creators", () => {
    const s = fs.readFileSync("src/pages/app/AppQuickDetails.jsx", "utf8");
    expect(s).toContain('export const TRUSTED_BY = "3,000+"');
    expect(s).toContain("<TrustAvatars size={34} fromExplore max={4} />"); // text left, rotating photos right (Ravi, 3 Nov)
    expect(fs.readFileSync("src/components/onboarding/mobile/TrustAvatars.jsx", "utf8")).toContain('api.get("creators/explore"');
  });
});
