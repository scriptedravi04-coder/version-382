// v354: preview / lookup / bulk end to end with a fake database, fake storage and a fake Meta.
import { describe, it, expect, beforeEach } from "vitest";
import express from "express";
import { setupInstagramRoutes } from "./instagramConnect";

function fakeDb(tables: Record<string, any[]>) {
  const updates: any[] = [];
  const uploads: string[] = [];
  const q = (table: string) => {
    let rows = [...(tables[table] || [])];
    let patch: any = null;
    const api: any = {
      select: () => api, limit: () => api, not: () => api, neq: () => api, ilike: () => { rows = []; return api; }, or: () => api,
      in: (_c: string, ids: string[]) => { rows = rows.filter((r) => ids.includes(r.user_id)); return api; },
      eq: (c: string, v: any) => { rows = rows.filter((r) => String(r[c]) === String(v)); if (patch) { rows.forEach((r) => Object.assign(r, patch)); updates.push({ table, c, v, patch }); } return api; },
      update: (p: any) => { patch = p; return api; },
      delete: () => api,
      maybeSingle: async () => ({ data: rows[0] || null, error: null }),
      then: (ok: any) => ok({ data: rows, error: null }),
    };
    return api;
  };
  return {
    from: q, updates, uploads,
    storage: { from: () => ({ upload: async (p: string) => { uploads.push(p); return { error: null }; }, getPublicUrl: (p: string) => ({ data: { publicUrl: `https://sb/storage/v1/object/public/avatars/${p}` } }) }) },
  };
}

const meta = (username: string) => ({
  ok: true, json: async () => ({ business_discovery: { username, name: "Riya", biography: "📩 riya@mail.com", profile_picture_url: "https://cdn.ig/p.jpg", followers_count: 12000,
    media: { data: [{ id: "9", permalink: "https://instagram.com/reel/x", caption: "#ad @nykaa", media_product_type: "REELS", media_type: "VIDEO", like_count: 500, comments_count: 20, view_count: 9000 }] } } }),
});
const fakeFetch: any = async (url: string) => {
  if (url.startsWith("https://cdn.ig/")) return { ok: true, headers: { get: () => "image/png" }, arrayBuffer: async () => new Uint8Array([137, 80, 78, 71]).buffer };
  const m = /username\(([^)]+)\)/.exec(decodeURIComponent(url));
  return meta(m ? m[1] : "x");
};

async function call(app: any, method: string, path: string, body?: any) {
  const server = app.listen(0); const port = server.address().port;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api${path}`, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, data: await r.json() };
  } finally { server.close(); }
}

describe("v354 — routes", () => {
  beforeEach(() => { process.env.IG_GRAPH_TOKEN = "t"; process.env.IG_BUSINESS_ID = "1"; });
  const make = (user: any, tables: any) => {
    const db = fakeDb(tables);
    const app = express(); app.use(express.json());
    const router = express.Router();
    setupInstagramRoutes(router, { supabase: db, privilegedSupabase: db, getDb: () => ({}), parseAuthUser: async () => user, fetchImpl: fakeFetch, logAdminAction: async () => {} } as any);
    app.use("/api", router);
    return { app, db };
  };

  it("preview: numbers + our photo copy + bio e-mail, media only when logged in", async () => {
    const { app, db } = make(null, {});
    const r = await call(app, "POST", "/instagram/preview", { username: "@Riya.K" });
    expect(r.status).toBe(200);
    expect(r.data.stats.followers).toBe(12000);
    expect(r.data.stats.bio_email).toBe("riya@mail.com");
    expect(r.data.stats.photo_url).toContain("/avatars/ig/riya.k.");
    expect(r.data.media).toBeUndefined();
    expect(db.uploads[0]).toMatch(/^ig\/riya\.k\./);
  });

  it("lookup: photo set when none / Google, never over an uploaded one", async () => {
    const tables: any = { creator_profiles: [{ user_id: "u1", photo: "https://lh3.googleusercontent.com/a/x", instagram_handle: "" }, { user_id: "u2", photo: "/api/files/abc" }], users: [{ user_id: "u1", picture: "" }, { user_id: "u2", picture: "/api/files/abc" }] };
    const a = make({ user_id: "u1", role: "creator" }, tables);
    const r1 = await call(a.app, "POST", "/creator/instagram/lookup", { username: "riya" });
    expect(r1.status).toBe(200);
    expect(r1.data.photo_url).toContain("/avatars/ig/riya.");
    expect(tables.creator_profiles[0].photo).toContain("/avatars/ig/");
    expect(tables.users[0].picture).toContain("/avatars/ig/");
    expect(r1.data.media[0].collab).toBe(true);
    const b = make({ user_id: "u2", role: "creator" }, tables);
    const r2 = await call(b.app, "POST", "/creator/instagram/lookup", { username: "riya2" });
    expect(r2.status).toBe(200);
    expect(r2.data.photo_url).toBeNull();
    expect(tables.creator_profiles[1].photo).toBe("/api/files/abc");
    expect(tables.creator_profiles[1].followers_instagram).toBe(12000);
  });

  it("bulk: creators + pending waitlist, keeps uploaded photos", async () => {
    const tables: any = {
      creator_profiles: [{ user_id: "c1", instagram_handle: "aa", photo: "" }, { user_id: "c2", instagram_handle: "bb", photo: "/api/files/up" }],
      waitlist: [{ id: "w1", social_handle: "@cc", status: "Pending", profile_photo_url: "" }, { id: "w2", social_handle: "@dd", status: "Approved", profile_photo_url: "" }],
      users: [],
    };
    const { app } = make({ user_id: "a", role: "admin" }, tables);
    // v363 requirement change (Ravi: "waitlist mai fetch hi nahi kar raha"): the background job stalled on Cloud Run,
    // so the admin screen now drives the run with POST /admin/creators/instagram-bulk/step until nothing is left.
    // Waitlist results go to ig_followers / instagram_stats (the form's own followers / avg_reach stay as typed).
    let st: any = null; const skip: string[] = [];
    for (let i = 0; i < 10; i++) {
      st = (await call(app, "POST", "/admin/creators/instagram-bulk/step", { skip })).data;
      for (const f of st.failed || []) skip.push(f.key);
      if (!st.remaining) break;
    }
    expect(st.total).toBe(3);
    expect(skip.length).toBe(0);
    expect(tables.creator_profiles[0].photo).toContain("/avatars/ig/aa.");
    expect(tables.creator_profiles[1].photo).toBe("/api/files/up");
    expect(tables.waitlist[0].ig_followers).toBe(12000);
    expect(tables.waitlist[0].instagram_stats.followers).toBe(12000);
    expect(tables.waitlist[0].instagram_synced_at).toBeTruthy();
    expect(tables.waitlist[0].instagram_fetch_error).toBeNull();
    expect(tables.waitlist[0].profile_photo_url).toContain("/avatars/ig/cc.");
    expect(tables.waitlist[1].ig_followers).toBeUndefined();
    // a second run straight after has nothing left (all fresh)
    const again = (await call(app, "POST", "/admin/creators/instagram-bulk/step", {})).data;
    expect(again.remaining).toBe(0);
    expect(again.fresh).toBe(3);
  }, 20000);
});
