// v376 (Ravi: "111 log signup page pe aaye, sirf 3 ne account banaya — signup easy karo"):
// mobile + SMS code sign-up (real auth router over HTTP, in-memory store, fake SMS provider), passwordless email
// sign-up, test-only switches off on the live server, and the screens' routing / Pixel helpers.
import { describe, it, expect, vi, beforeAll, afterAll, beforeEach } from "vitest";
import express from "express";
import fs from "fs";
import path from "path";
import type { AddressInfo } from "net";

const sms = vi.hoisted(() => ({ sent: [] as any[], fail: false }));
vi.mock("axios", async (orig) => {
  const real: any = await orig();
  const post = vi.fn(async (url: string, body: any, cfg: any) => {
    if (String(url).includes("fast2sms")) {
      sms.sent.push({ to: body.numbers, code: body.variables_values, key: cfg?.headers?.authorization });
      return { data: sms.fail ? { return: false, message: ["Website verification pending"] } : { return: true } };
    }
    return real.default.post(url, body, cfg);
  });
  return { ...real, default: { ...real.default, post }, post };
});

import { setupAuthRoutes } from "./auth_routes";
import { indianMobile, smsProvider } from "./smsOtp";
import { isLiveServer } from "./liveServer";
import { demoLoginEnabled } from "./admin_system_maintenance_routes";
import { resolveOtpEcho } from "./otpEcho";
import { siteUrlFor } from "./blogSeo";

const ROOT = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.resolve(ROOT, p), "utf8");

let db: any;
let base = "";
let server: any;
const keepEnv = { ...process.env };

beforeAll(async () => {
  db = { users: [], user_sessions: [] };
  const app = express();
  app.use(express.json());
  const router = express.Router();
  setupAuthRoutes(app, router, {
    supabase: null, privilegedSupabase: null,
    getDb: () => db, saveDb: (d: any) => { db = d; },
    parseAuthUser: async () => null, logAdminAuth: async () => null, getPermissionsForUser: async () => ({}),
    broadcastAdminNotification: async () => null, checkForgotPasswordRateLimit: () => true, recordUserPassword: () => {},
    sendSuperAdminAlertEmail: async () => null, processBase64Image: async () => null, syncEntityTags: async () => null,
  } as any);
  app.use("/api", router);
  server = app.listen(0);
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
});
afterAll(() => { server?.close(); process.env = { ...keepEnv }; });
beforeEach(() => {
  sms.sent = []; sms.fail = false;
  process.env.FAST2SMS_API_KEY = "test-key";
  delete process.env.MSG91_AUTH_KEY; delete process.env.APP_URL; delete process.env.RAZORPAY_KEY_ID; delete process.env.YBEX_LIVE;
  process.env.NODE_ENV = "test";
});

const post = async (p: string, body: any) => {
  const r = await fetch(base + p, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": `10.0.0.${Math.floor(Math.random() * 200)}` }, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json() };
};

describe("v376 · mobile + SMS code sign-up (real router over HTTP)", () => {
  it("config says on only when an SMS key is set", async () => {
    expect((await (await fetch(base + "/auth/phone/config")).json()).enabled).toBe(true);
    delete process.env.FAST2SMS_API_KEY;
    expect((await (await fetch(base + "/auth/phone/config")).json()).enabled).toBe(false);
    const r = await post("/auth/phone/send", { phone: "9876543210" });
    expect([r.status, r.body.code]).toEqual([503, "SMS_OFF"]);
  });

  it("new creator: number + Instagram → SMS code → account made (no email, no password) → same number logs in", async () => {
    const bad = await post("/auth/phone/send", { phone: "12345" });
    expect(bad.status).toBe(400);
    const s1 = await post("/auth/phone/send", { phone: "+91 98765 43210" });
    expect(s1.status).toBe(200);
    expect(sms.sent).toHaveLength(1);
    expect(sms.sent[0].to).toBe("9876543210");
    const code = sms.sent[0].code;
    expect(code).toMatch(/^\d{6}$/);

    const wrong = await post("/auth/phone/verify", { phone: "9876543210", otp: code === "111111" ? "222222" : "111111", role: "creator" });
    expect([wrong.status, wrong.body.code]).toEqual([401, "INVALID_OTP"]);

    const v = await post("/auth/phone/verify", { phone: "9876543210", otp: code, role: "creator", instagram: "@Riya.Creates" });
    expect(v.status).toBe(200);
    expect(v.body.is_new).toBe(true);
    expect(v.body.token).toBeTruthy();
    expect(v.body.user).toMatchObject({ role: "creator", phone: "+919876543210", email: "phone-919876543210@ybex.io", name: "@riya.creates", auth_method: "phone", verified: true, onboarded: false });
    expect(v.body.user.password_hash).toBeUndefined();
    expect(db.users.filter((u: any) => u.phone === "+919876543210")).toHaveLength(1);
    expect(db.user_sessions.some((x: any) => x.session_token === v.body.token)).toBe(true);

    // the code is used up
    const again = await post("/auth/phone/verify", { phone: "9876543210", otp: code, role: "creator" });
    expect(again.status).toBe(401);

    // log in later with the same number → same account, no duplicate
    await post("/auth/phone/send", { phone: "9876543210" });
    const v2 = await post("/auth/phone/verify", { phone: "9876543210", otp: sms.sent[1].code, role: "creator" });
    expect([v2.status, v2.body.is_new, v2.body.user.user_id]).toEqual([200, false, v.body.user.user_id]);
    expect(db.users.filter((u: any) => u.phone === "+919876543210")).toHaveLength(1);
  });

  it("the other side, admins and banned accounts are refused", async () => {
    db.users.push({ user_id: "B1", email: "b@x.com", name: "B", role: "brand", phone: "+919811111111", auth_method: "email", verified: true, created_at: "2026-10-01" });
    db.users.push({ user_id: "A1", email: "a@x.com", name: "A", role: "admin", phone: "+919822222222", auth_method: "email", verified: true, created_at: "2026-10-01" });
    db.users.push({ user_id: "X1", email: "x@x.com", name: "X", role: "creator", phone: "+919833333333", auth_method: "email", verified: true, banned: true, created_at: "2026-10-01" });
    for (const [phone, code, status] of [["9811111111", "ROLE_MISMATCH", 409], ["9822222222", "ADMIN_ACCOUNT", 403], ["9833333333", "ACCOUNT_BANNED", 401]] as const) {
      await post("/auth/phone/send", { phone });
      const otp = sms.sent[sms.sent.length - 1].code;
      const r = await post("/auth/phone/verify", { phone, otp, role: "creator" });
      expect([r.status, r.body.code]).toEqual([status, code]);
    }
  });

  it("a waitlist (unclaimed) profile with the same number is claimed, not duplicated", async () => {
    db.users.push({ user_id: "W1", email: "riya@mail.com", name: "Riya", role: "creator", phone: "+919844444444", auth_method: "unclaimed", verified: false, created_at: "2026-10-01" });
    await post("/auth/phone/send", { phone: "9844444444" });
    const r = await post("/auth/phone/verify", { phone: "9844444444", otp: sms.sent[sms.sent.length - 1].code, role: "creator" });
    expect(r.status).toBe(200);
    expect(r.body.user.user_id).toBe("W1");
    expect(db.users.filter((u: any) => String(u.phone).endsWith("9844444444"))).toHaveLength(1);
  });

  it("SMS provider refusing → clear error, no account", async () => {
    sms.fail = true;
    const r = await post("/auth/phone/send", { phone: "9855555555" });
    expect([r.status, r.body.code]).toEqual([502, "SMS_FAILED"]);
  });

  it("email sign-up without a password (passwordless): no hash, name from the email, password still required otherwise", () => {
    const a = read("backend/auth_routes.ts");
    expect(a).toContain('const passwordless = req.body?.passwordless === true && !req.body?.password;');
    expect(a).toContain("const hashedPassword = passwordless ? null : await bcrypt.hash(password, salt);");
    expect(a).toContain("if (!name || !email || (!password && !passwordless))");
    expect(a).toContain("if (!passwordless) recordUserPassword(");
  });
});

describe("v376 · creators' one-screen join: email → code → Instagram + WhatsApp (account only after the email is proved)", () => {
  const sendAndProve = async (email: string, fresh = true) => {
    const s1 = await post("/auth/join/send-code", { email });
    expect(s1.status).toBe(200);
    expect(s1.body.otp).toMatch(/^\d{6}$/); // test server echoes the code; the live server never does (v376 liveServer)
    if (fresh) expect(db.users.some((u: any) => u.email === email.toLowerCase())).toBe(false); // no account yet
    const v = await post("/auth/join/verify-code", { email, otp: s1.body.otp });
    expect(v.status).toBe(200);
    return v.body.proof as string;
  };
  beforeEach(() => { process.env.EMAIL_LINK_SECRET = "test-secret-123"; process.env.RESEND_ALLOW_FALLBACK = "1"; });

  it("no proof → refused; wrong code → refused; right code → account, verified, logged in", async () => {
    const noProof = await post("/auth/quick-join", { email: "riya.new@mail.com", instagram: "riya.reels", whatsapp: "9876511111" });
    expect([noProof.status, noProof.body.code]).toEqual([401, "EMAIL_NOT_VERIFIED"]);
    const forged = await post("/auth/quick-join", { email: "riya.new@mail.com", instagram: "riya.reels", whatsapp: "9876511111", proof: `${Date.now() + 60000}.abc` });
    expect(forged.status).toBe(401);
    const s1 = await post("/auth/join/send-code", { email: "riya.new@mail.com" });
    const bad = await post("/auth/join/verify-code", { email: "riya.new@mail.com", otp: s1.body.otp === "111111" ? "222222" : "111111" });
    expect([bad.status, bad.body.code]).toEqual([401, "INVALID_OTP"]);
    const proof = await sendAndProve("Riya.New@Mail.com");
    // a proof is for ONE email
    const other = await post("/auth/quick-join", { email: "someone@mail.com", instagram: "x", whatsapp: "9876511111", proof });
    expect(other.status).toBe(401);
    const r = await post("/auth/quick-join", { email: "Riya.New@Mail.com", instagram: "https://instagram.com/riya.reels/", whatsapp: "98765 11111", proof });
    expect(r.status).toBe(200);
    expect(r.body.token).toBeTruthy();
    expect(r.body.user).toMatchObject({ email: "riya.new@mail.com", name: "@riya.reels", phone: "+919876511111", role: "creator", verified: true, onboarded: false });
    expect(r.body.user.password_hash).toBeUndefined();
  });
  it("an email that already has an account goes to login (never joins); admins refused", async () => {
    db.users.push({ user_id: "E1", email: "old@mail.com", name: "Old", role: "creator", auth_method: "email", verified: true, password_hash: "x", created_at: "2026-10-01" });
    db.users.push({ user_id: "E3", email: "boss@mail.com", name: "B", role: "admin", auth_method: "email", verified: true, created_at: "2026-10-01" });
    const a = await post("/auth/join/send-code", { email: "old@mail.com" });
    expect([a.status, a.body.code, a.body.has_password, a.body.role]).toEqual([409, "ACCOUNT_EXISTS", true, "creator"]);
    const c = await post("/auth/join/send-code", { email: "boss@mail.com" });
    expect([c.status, c.body.code]).toEqual([403, "ADMIN_ACCOUNT"]);
  });
  it("a waitlist (unclaimed) email is claimed after the code — same account, now verified", async () => {
    db.users.push({ user_id: "WL1", email: "wait@mail.com", name: "Wait", role: "creator", auth_method: "unclaimed", verified: false, phone: "", created_at: "2026-10-01" });
    const proof = await sendAndProve("wait@mail.com", false);
    const r = await post("/auth/quick-join", { email: "wait@mail.com", instagram: "wait.ig", whatsapp: "9876533333", proof });
    expect(r.status).toBe(200);
    expect(r.body.user).toMatchObject({ user_id: "WL1", verified: true, auth_method: "email", phone: "+919876533333" });
    expect(db.users.filter((u: any) => u.email === "wait@mail.com")).toHaveLength(1);
  });
  it("checks each field", async () => {
    const proof = await sendAndProve("fields@mail.com");
    expect((await post("/auth/quick-join", { email: "fields@mail.com", instagram: "bad name!", whatsapp: "9876500000", proof })).body.field).toBe("instagram");
    expect((await post("/auth/quick-join", { email: "fields@mail.com", instagram: "ok", whatsapp: "12345", proof })).body.field).toBe("whatsapp");
    expect((await post("/auth/join/send-code", { email: "x@ybex.io" })).body.code).toBe("BAD_EMAIL");
  });
  it("screens: email → code opens under it → Instagram + WhatsApp; Google sign-ups must give both", () => {
    const c = read("src/pages/app/AppContinue.jsx");
    expect(c).toContain('const joinMode = role === "creator" && !showLogin && !pwOpen;');
    expect(c).toContain('api.post("auth/join/send-code"');
    expect(c).toContain('api.post("auth/join/verify-code"');
    expect(c).toContain('api.post("auth/quick-join", { email: cleanEmail, instagram: igClean, whatsapp: wa10, proof');
    expect(c.indexOf('data-testid="app-join-email"')).toBeLessThan(c.indexOf('data-testid="app-join-code-box"'));
    // v408 (Ravi 5 Nov): the checked Instagram shows as a card with "Change" (was a free text box) — same place
    expect(c.indexOf('data-testid="app-join-code-box"')).toBeLessThan(c.indexOf('{IgCard}'));
    expect(c).toContain('trackRegistration(data.user, method, true)');
    expect(c).toContain('api.post("creator/instagram/lookup"');
    expect(read("src/pages/app/AppOAuthDone.jsx")).toContain("/app/details");
    const d = read("src/pages/app/AppQuickDetails.jsx");
    expect(d).toContain('api.post("auth/quick-profile"');
    expect(d).not.toContain("Skip for now");
    expect(read(".env.example")).toMatch(/^YBEX_ENV=""$/m);
    expect(read(".env.example")).not.toMatch(/^RAZORPAY_KEY_ID=/m);
    expect(read("vite.config.js")).toContain("applyYbexEnvForBuild");
  });
});

describe("v376 · offer page: no Reel ideas, scripts without a brand, own-reel line", () => {
  it("scripts saved without a name / logo are kept and shown", async () => {
    const { cleanConfig } = await import("./challenge_routes");
    const { scriptsFrom } = await import("../src/lib/diwaliChallenge");
    const c = cleanConfig({ sponsors: [{ name: "", scripts: ["x"] }], scripts: [" Script one ", "", "Script two"] });
    expect(c.sponsors).toEqual([]);
    expect(c.scripts).toEqual(["Script one", "Script two"]);
    expect(scriptsFrom(c)).toEqual(["Script one", "Script two"]);
    const page = read("src/pages/ChallengePage.jsx");
    expect(page).not.toContain(">Reel ideas<");
    expect(page).toContain('data-testid="loose-scripts"');
    expect(page.indexOf('data-testid="own-reel-line"')).toBeLessThan(page.indexOf('data-testid="loose-scripts"'));
    const admin = read("src/components/admin/AdminChallengeEntries.jsx");
    expect(admin).not.toContain("Every sponsor needs a name.");
    expect(admin).toContain("scripts: sponsors.filter((x) => !x.name.trim())");
  });
});

describe("v376 · helpers", () => {
  it("indianMobile / smsProvider", () => {
    expect(indianMobile("+91 98765-43210")).toBe("9876543210");
    expect(indianMobile("09876543210")).toBe("9876543210");
    expect(indianMobile("919876543210")).toBe("9876543210");
    expect(indianMobile("5876543210")).toBe("");
    expect(smsProvider({ FAST2SMS_API_KEY: "k" })).toBe("fast2sms");
    expect(smsProvider({ MSG91_AUTH_KEY: "k", MSG91_OTP_TEMPLATE_ID: "t" })).toBe("msg91");
    expect(smsProvider({ MSG91_AUTH_KEY: "k" })).toBe(null);
  });

  it("demo logins and OTP echo are off on the live server, whatever the secrets say", () => {
    const live = { DEMO_LOGIN: "true", NODE_ENV: "development", APP_URL: "https://ybexapp.ai.studio" };
    expect(isLiveServer(live)).toBe(true);
    expect(demoLoginEnabled(live)).toBe(false);
    expect(resolveOtpEcho(live)).toBe(false);
    expect(demoLoginEnabled({ DEMO_LOGIN: "true", SITE_URL: "https://ybexmedia.in" })).toBe(false);
    expect(demoLoginEnabled({ DEMO_LOGIN: "true", RAZORPAY_KEY_ID: "rzp_live_abc" })).toBe(false);
    expect(demoLoginEnabled({ DEMO_LOGIN: "true", YBEX_LIVE: "true" })).toBe(false);
    // a test server keeps them
    expect(demoLoginEnabled({ DEMO_LOGIN: "true", APP_URL: "https://ybex-test-123.asia-southeast1.run.app" })).toBe(true);
    expect(isLiveServer({ APP_URL: "https://notybexmedia.in.example.com" })).toBe(false);
    expect(read("backend/server.ts")).toMatch(/isDemoLoginEnabled = \(\): boolean => \{\n\s+if \(isLiveServer\(process\.env\)\) return false;/);
  });

  it("SEO address never the hosting address (kept from v376 part 1)", () => {
    process.env.SITE_URL = ""; process.env.APP_URL = "https://ybexapp.ai.studio";
    expect(siteUrlFor()).toBe("https://ybexmedia.in");
  });
});

describe("v376 · screens", () => {
  const c = read("src/pages/app/AppContinue.jsx");
  it("Google first and big; mobile + Instagram below; email as the fallback; no password at sign-up", () => {
    expect(c.indexOf('data-testid="app-oauth-google"')).toBeLessThan(c.indexOf('data-testid="app-phone-block"'));
    expect(c.indexOf('data-testid="app-phone-block"')).toBeLessThan(c.indexOf('data-testid="app-email"'));
    expect(c).toContain('role === "creator" && !showLogin && IgCard'); // v408: Instagram card (Change) instead of a text box
    expect(c).toContain('api.post("auth/phone/verify"');
    expect(c).toContain("passwordless: true");
    expect(c).not.toContain('data-testid="app-signup-password"');
  });
  it("after sign-up: creators skip onboarding, offer visitors go back to /challenge, Pixel fires", () => {
    const a = read("src/lib/afterSignup.js");
    expect(a).toContain("target = DIWALI_ADD_PATH;"); // v377: straight to "Add your Diwali reel" (v402: after the photo + name step)
    expect(a).toContain('"/creator/settings?section=portfolio&add=1&diwali=1"');
    expect(a).toContain("markFinishLater(");
    expect(c).toContain('trackRegistration(data.user, "phone", true)');
    expect(c).toContain('trackRegistration(data.user, "email", true)');
    expect(read("src/pages/app/AppOAuthDone.jsx")).toContain('trackRegistration(u, "google")');
    expect(read("src/lib/signupSource.js")).toContain('trackFunnel("CompleteRegistration"');
    const ch = read("src/pages/ChallengePage.jsx");
    expect(ch).toContain("noteOfferVisit()");
    expect(ch).toContain('data-testid="challenge-add-reel"');
  });
});
