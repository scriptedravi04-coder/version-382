// v363 (Ravi's design "Onboarding: one username, everything fetched from Meta"): the username box fetches by itself
// (600 ms after typing / on blur), spinner + "Fetching your profile from Meta…", green tick + numbers card on success,
// "Make the account public or check the spelling" + Retry on failure, one call per username.
import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, act, cleanup } from "@testing-library/react";
import fs from "fs";

const post = vi.fn();
vi.mock("../src/lib/api", () => ({
  api: {
    get: vi.fn(async () => ({ data: { lookup: true } })),
    post: (...a: any[]) => post(...a),
  },
}));

import IgHandleField, { igFetchErrorText } from "../src/components/instagram/IgHandleField";

const read = (p: string) => fs.readFileSync(p, "utf8");

function Harness(props: any) {
  const [v, setV] = React.useState(props.start || "");
  return React.createElement(IgHandleField, { value: v, onChange: setV, ...props });
}

describe("v363 · IgHandleField", () => {
  beforeEach(() => { cleanup(); post.mockReset(); vi.useRealTimers(); });

  it("error text: personal / missing account → the design's line; others stay calm", () => {
    expect(igFetchErrorText(404, { code: "NOT_PROFESSIONAL" })).toBe("Make the account public or check the spelling");
    expect(igFetchErrorText(429, { code: "RATE_LIMIT", error: "Too many tries." })).toBe("Too many tries.");
    expect(igFetchErrorText(undefined, undefined)).toMatch(/Couldn't reach Instagram/);
  });

  it("fetches once after typing stops, shows spinner then the numbers card", async () => {
    let resolve: any;
    post.mockImplementation(() => new Promise((ok) => { resolve = ok; }));
    const onFetched = vi.fn();
    const onBusy = vi.fn();
    render(React.createElement(Harness, { onFetched, onBusyChange: onBusy }));
    await act(async () => { await new Promise((r) => setTimeout(r, 0)); }); // config loaded
    fireEvent.change(screen.getByLabelText("Instagram handle"), { target: { value: "sonam.bajva" } });
    await act(async () => { await new Promise((r) => setTimeout(r, 700)); });
    expect(post).toHaveBeenCalledTimes(1);
    expect(post.mock.calls[0]).toEqual(["instagram/preview", { username: "sonam.bajva" }]);
    expect(screen.getByText("Fetching your profile from Meta…")).toBeTruthy();
    expect(onBusy).toHaveBeenLastCalledWith(true);
    await act(async () => { resolve({ data: { stats: { username: "sonam.bajva", followers: 83900, avg_views: 8500, engagement_rate: 4.2, photo_url: "https://x/avatars/ig/sonam.bajva.webp" } } }); });
    expect(screen.getByTestId("ig-field-tick")).toBeTruthy();
    expect(screen.getByText("83.9K")).toBeTruthy();
    expect(screen.getByText("8.5K")).toBeTruthy();
    expect(screen.getByText("4.2%")).toBeTruthy();
    expect(screen.getByText(/no need to enter numbers/)).toBeTruthy();
    expect(onFetched).toHaveBeenCalledWith(expect.objectContaining({ followers: 83900, photo_url: "https://x/avatars/ig/sonam.bajva.webp" }));
    // blur on the same username → no second call
    fireEvent.blur(screen.getByLabelText("Instagram handle"));
    await act(async () => { await new Promise((r) => setTimeout(r, 50)); });
    expect(post).toHaveBeenCalledTimes(1);
  });

  it("failure → design error + Retry, no number boxes", async () => {
    post.mockRejectedValue({ response: { status: 404, data: { code: "NOT_PROFESSIONAL" } } });
    render(React.createElement(Harness, {}));
    await act(async () => { await new Promise((r) => setTimeout(r, 0)); });
    fireEvent.change(screen.getByLabelText("Instagram handle"), { target: { value: "private.one" } });
    await act(async () => { await new Promise((r) => setTimeout(r, 700)); });
    expect(screen.getByText("Make the account public or check the spelling")).toBeTruthy();
    expect(screen.getByText("Retry")).toBeTruthy();
    expect(screen.queryByText("Followers")).toBeNull();
  });
});

describe("v363 · onboarding wiring", () => {
  const creator = read("src/pages/onboarding/CreatorOnboardingMobile.jsx");
  const brand = read("src/pages/onboarding/BrandOnboardingMobile.jsx");
  it("creator step 1 uses the auto-fetch box; Next waits while it runs; photo says where it came from", () => {
    expect(creator).toContain("<IgHandleField");
    expect(creator).toContain("|| saving || igFetching} onClick={submitBasics}");
    expect(creator).toContain("Photo pulled from Instagram");
  });
  it("channels step after a fetch: Instagram's done + optional others + both skips", () => {
    expect(creator).toContain("Instagram's done. Add others?");
    expect(creator).toContain('saveLabel="Skip"');
    expect(creator).toContain("Skip it for now");
    expect(creator).toContain("fetched from Meta");
  });
  it("brand step 1 starts with the brand Instagram and shows the creators' preview", () => {
    expect(brand).toContain("<IgHandleField");
    expect(brand).toContain("Start with your Instagram. We'll fill in the rest.");
    expect(brand).toContain('data-testid="brand-ig-preview"');
    expect(brand).toContain("Looks right, next");
    // logo upload stays as the alternative
    expect(brand).toContain('data-testid="brand-logo-upload-box"');
  });
});
