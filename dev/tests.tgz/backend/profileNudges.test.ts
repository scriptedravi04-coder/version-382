import { describe, it, expect } from "vitest";
import { dueStep, quietHoursOk, missingParts, nudgeFor, PROFILE_NUDGES_ON, NUDGE_FINISH_SIGNUP } from "./profileNudges";
import { profileOfferState } from "../src/components/challenge/ProfileCompleteCongrats";

const H = 3600_000;
describe("v378 profile nudges", () => {
  it("is on — Ravi approved the texts (28 Oct)", () => expect(PROFILE_NUDGES_ON).toBe(true));
  it("sends at most 3, spaced 2 and 4 days", () => {
    const t0 = Date.parse("2026-11-01T06:00:00Z");
    expect(dueStep([], t0)).toBe(1);
    expect(dueStep([{ ref: "1", sent_at: new Date(t0).toISOString() }], t0 + 47 * H)).toBe(0);
    expect(dueStep([{ ref: "1", sent_at: new Date(t0).toISOString() }], t0 + 48 * H)).toBe(2);
    const two = [{ ref: "1", sent_at: new Date(t0).toISOString() }, { ref: "2", sent_at: new Date(t0 + 48 * H).toISOString() }];
    expect(dueStep(two, t0 + 140 * H)).toBe(0);
    expect(dueStep(two, t0 + 144 * H)).toBe(3);
    // requirement changed (Ravi, 3 Nov: "baar baar bhejo"): after the 3rd come more — 8 in all, then none
    expect(dueStep([...two, { ref: "3", sent_at: new Date(t0).toISOString() }], t0 + 999 * H)).toBe(4);
    const eight = [1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({ ref: String(n), sent_at: new Date(t0).toISOString() }));
    expect(dueStep(eight, t0 + 9999 * H)).toBe(0);
  });
  it("stays quiet at night (India time)", () => {
    expect(quietHoursOk(Date.parse("2026-11-01T04:00:00Z"))).toBe(true); // 9:30 am IST
    expect(quietHoursOk(Date.parse("2026-11-01T17:00:00Z"))).toBe(false); // 10:30 pm IST
  });
  it("names the first missing part and opens that screen", () => {
    const n = nudgeFor(missingParts({ photo: "x" }, "NONE"));
    expect(n?.part).toBe("Niche & bio");
    expect(n?.link).toBe("/creator/settings?section=profile");
    const full = { photo: "x", bio: "hi", primary_niche: "Food", ig_followers: 5000, story_rate: 500, portfolio: [{}] };
    expect(nudgeFor(missingParts(full, "NONE"))?.part).toBe("KYC");
    expect(nudgeFor(missingParts(full, "NONE"))?.title).toContain("payout details");
    expect(nudgeFor(missingParts(full, "PENDING"))).toBeNull();
  });
  it("congrats popup: 100% only with KYC submitted", () => {
    const full = { photo: "x", bio: "hi", primary_niche: "Food", ig_followers: 5000, story_rate: 500, portfolio: [{}] };
    expect(profileOfferState(full, null).complete).toBe(false);
    expect(profileOfferState(full, { status: "PENDING" }).complete).toBe(true);
    expect(profileOfferState({ photo: "x" }, { status: "APPROVED" }).percent).toBe(33);
  });
});

describe("v397 reminders keep going (Ravi, 3 Nov)", () => {
  it("offer closed → same reminder without the cash line; unfinished sign-up → opens the sign-up form", () => {
    const n = nudgeFor(missingParts({}, "NONE"), false);
    expect(n?.part).toBe("Photo");
    expect(n?.message).not.toMatch(/cash|₹/);
    expect(NUDGE_FINISH_SIGNUP.link).toBe("/onboarding");
  });
});
