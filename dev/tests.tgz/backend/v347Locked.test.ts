// v347 (Ravi approved) — fixes in LOCKED money / deal files:
// 1 chat message_type allow-list · 2 invite budget parsing / display · 3 escrow payable_net + no payout after a
// refund ate the net · 4 unknown amount → unconfirmed (not ₹1) · 5 UGC pay callback ignores refunded rows and
// never invents ₹5,000 · 6 offer / flat-coupon fee guards · 7 UGC agreement discloses the fee · 8 no second
// invite for a creator already in the campaign · 9 campaign pitch contact details masked on the server.
import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import fs from "fs";

const rzp = vi.hoisted(() => ({ fetch: vi.fn(), fetchPayments: vi.fn() }));
vi.mock("./helpers", async (importOriginal) => {
  const orig: any = await importOriginal();
  return { ...orig, getRazorpay: () => ({ orders: { fetch: rzp.fetch, fetchPayments: rzp.fetchPayments } }) };
});

import { setupChatCoreRoutes, USER_CHAT_MESSAGE_TYPES } from "./chat_routes";
import { parseInviteBudget, campaignInviteConflict } from "./directInvites";
import { formatBudget } from "../src/utils/invitationUtils";
import { setupPaymentRoutes } from "./payment_routes";
import { setupDealsChatRoutes } from "./deals_chat_routes";
import { calculateFee } from "../src/utils/feeCalculator";
import { ugcAgreement, campaignAgreement, agreementPlainText } from "../src/lib/agreementTerms";
import { setupCreatorsRoutes } from "./creators_routes";
import { setupCampaignsRoutes } from "./campaigns_routes";
import { maskContactDetails, checkComprehensiveDisallowedContent } from "./contactSecurityFilter";

// ------------------------------------------------------------------ helpers
async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = app.listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}`); } finally { srv.close(); }
}
const post = (base: string, path: string, body: any) =>
  fetch(`${base}/api${path}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
const get = (base: string, path: string) => fetch(`${base}/api${path}`);

/** Chainable Supabase stand-in: every query on `table` resolves to tables[table]; writes are recorded. */
function fakeSupabase(tables: Record<string, any[]>) {
  const writes: { table: string; op: string; payload: any }[] = [];
  const from = (table: string) => {
    let op = "select";
    const rows = () => tables[table] || [];
    const q: any = {};
    for (const m of ["select", "eq", "neq", "or", "in", "is", "order", "limit", "ilike", "gte", "lte", "range", "not", "match", "filter"]) q[m] = () => q;
    q.update = (payload: any) => { op = "update"; writes.push({ table, op, payload }); return q; };
    q.insert = (payload: any) => { op = "insert"; writes.push({ table, op, payload }); return q; };
    q.upsert = (payload: any) => { op = "upsert"; writes.push({ table, op, payload }); return q; };
    q.delete = () => { op = "delete"; writes.push({ table, op, payload: null }); return q; };
    q.maybeSingle = async () => ({ data: rows()[0] || null, error: null });
    q.single = q.maybeSingle;
    q.then = (ok: any, bad: any) => Promise.resolve({ data: op === "select" ? rows() : rows().map((r) => ({ id: r.id })), error: null }).then(ok, bad);
    return q;
  };
  return { client: { from, rpc: async () => ({ data: null, error: null }) }, writes };
}

// ------------------------------------------------------------------ 1. chat message_type
describe("1 · POST /chat/v2/threads/:id/messages — message_type allow-list", () => {
  function chatApp(db: any, user: any) {
    const app = express(); app.use(express.json());
    const router = express.Router();
    setupChatCoreRoutes(app, router, {
      supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => user,
      ensureUGCChatThread: async () => null, populateThreadData: async (t: any[]) => t, insertChatMessageToSupabase: async () => ({}),
    } as any);
    app.use("/api", router);
    return app;
  }
  const mkDb = () => ({ chat_threads: [{ id: "ugcord_t1", creator_id: "c1", brand_id: "b1" }], chat_messages: [] as any[] });
  const sendAs = async (user: any, message_type: any) => {
    const db = mkDb();
    let status = 0;
    await serve(chatApp(db, user), async (base) => {
      status = (await post(base, "/chat/v2/threads/ugcord_t1/messages", { text: "hi", message_type })).status;
    });
    return { status, type: db.chat_messages[0]?.message_type };
  };

  it("the allowed list is exactly what the app sends", () => {
    expect([...USER_CHAT_MESSAGE_TYPES].sort()).toEqual(["attachment", "file", "image", "text", "video"]);
  });
  for (const forged of ["payout_released", "payment_funded", "content_approved", "live_links_submitted", "order_cancelled", "system", "brand_invitation_offer"]) {
    it(`creator/brand "${forged}" is saved as plain text`, async () => {
      expect(await sendAs({ user_id: "c1", role: "creator" }, forged)).toEqual({ status: 200, type: "text" });
      expect((await sendAs({ user_id: "b1", role: "brand" }, forged)).type).toBe("text");
    });
  }
  it("legit user types still go through unchanged (text, attachment, file, image, video, none)", async () => {
    for (const t of ["text", "attachment", "file", "image", "video"]) {
      expect((await sendAs({ user_id: "c1", role: "creator" }, t)).type).toBe(t);
    }
    expect((await sendAs({ user_id: "c1", role: "creator" }, undefined)).type).toBe("text");
  });
  it("staff keep whatever type they send", async () => {
    expect((await sendAs({ user_id: "a1", role: "admin" }, "payout_released")).type).toBe("payout_released");
    expect((await sendAs({ user_id: "a2", role: "sub_admin" }, "system")).type).toBe("system");
  });
});

// ------------------------------------------------------------------ 2. budgets
describe("2 · invite budget — first number only; ranges stay readable", () => {
  it("parseInviteBudget", () => {
    expect(parseInviteBudget("15000 + 18% GST")).toBe(15000);
    expect(parseInviteBudget("10,000-15,000")).toBe(10000);
    expect(parseInviteBudget("₹10,000 – ₹15,000")).toBe(10000);
    expect(parseInviteBudget("₹45,000")).toBe(45000);
    expect(parseInviteBudget("Rs. 5,000")).toBe(5000);
    expect(parseInviteBudget("4500.6")).toBe(4501);
    expect(parseInviteBudget("Negotiable")).toBe(0);
    expect(parseInviteBudget(12000)).toBe(12000);
  });
  it("formatBudget", () => {
    expect(formatBudget("10000-15000")).toBe("₹10,000 – ₹15,000");
    expect(formatBudget("10,000 - 15,000")).toBe("₹10,000 – ₹15,000");
    expect(formatBudget("₹10,000 to ₹15,000")).toBe("₹10,000 – ₹15,000");
    expect(formatBudget("15000 + 18% GST")).toBe("₹15,000");
    expect(formatBudget("15000")).toBe("₹15,000");
    expect(formatBudget("Barter")).toBe("Barter");
    expect(formatBudget(null)).toBe("Negotiable");
  });
});

// ------------------------------------------------------------------ 3 + 4. payment_routes
function paymentApp(sb: any, user: any) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupPaymentRoutes(app, router, {
    supabase: sb, privilegedSupabase: sb, getDb: () => ({ transactions: [] }), saveDb: () => {}, parseAuthUser: async () => user,
    logAdminAction: vi.fn(async () => ({})), sendNotification: vi.fn(async () => ({})), fetchUserScopedTransactions: vi.fn(async () => []),
    serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: vi.fn(async () => ({})), parseThreadState: () => ({}), getIsTestMode: () => false,
  } as any);
  app.use("/api", router);
  return app;
}
const admin = { user_id: "adm1", role: "admin" };

describe("3 · escrow overview payable_net / payout after a part refund", () => {
  it("source: overview rows carry payable_net = netAfterPartialRefund(tx, creator_net_amount)", () => {
    expect(fs.readFileSync("backend/payment_routes.ts", "utf8")).toContain("payable_net: netAfterPartialRefund(tx, Number(tx.creator_net_amount) || 0),");
  });

  it("a part refund that leaves nothing → 400 'Nothing left to pay', nothing marked PAID", async () => {
    const tx = { id: "11111111-1111-4111-8111-111111111111", deal_id: "22222222-2222-4222-8222-222222222222", creator_id: "c1", brand_id: "b1", status: "SUCCESS", gross_amount: 10000, creator_net_amount: 8500, refund_status: "PROCESSED", refund_amount: 9000 };
    const { client, writes } = fakeSupabase({
      transactions: [tx], creator_kyc: [{ status: "APPROVED" }], verifications: [], deals: [{ id: tx.deal_id, agreed_amount: 10000, creator_id: "c1" }], ugc_orders: [], platform_fee_config: [],
    });
    await serve(paymentApp(client, admin), async (base) => {
      const r = await post(base, `/admin/escrow/${tx.deal_id}/release-payout`, { utr_number: "UTR123", transaction_id: tx.id });
      expect(r.status).toBe(400);
      const j = await r.json();
      expect(j.error).toBe("Nothing left to pay after the refund.");
      expect(j.code).toBe("NOTHING_LEFT_AFTER_REFUND");
    });
    expect(writes.filter((w) => w.table === "transactions" && w.op === "update")).toHaveLength(0);
  });
});

describe("4 · amount unknown + Razorpay can't tell → unconfirmed, never a ₹1 'funded' hold", () => {
  beforeEach(() => { rzp.fetch.mockReset(); rzp.fetchPayments.mockReset(); });
  it("check-status: no deal/order/thread amount and the Razorpay re-fetch fails → mismatch, no transaction written", async () => {
    rzp.fetch.mockResolvedValueOnce({ status: "paid" }).mockRejectedValue(new Error("razorpay down"));
    rzp.fetchPayments.mockResolvedValue({ items: [{ id: "pay_1" }] });
    const { client, writes } = fakeSupabase({ transactions: [], deals: [], ugc_orders: [], chat_threads: [] });
    await serve(paymentApp(client, { user_id: "b1", role: "brand" }), async (base) => {
      const r = await post(base, "/payments/razorpay/check-status", { order_id: "order_ABC123", deal_id: "33333333-3333-4333-8333-333333333333" });
      expect(r.status).toBe(400);
      const j = await r.json();
      expect(j.paid).toBe(false);
      expect(j.code).toBe("ESCROW_AMOUNT_MISMATCH");
      expect(j.error).toMatch(/could not be confirmed/i);
    });
    expect(writes.filter((w) => w.table === "transactions" && w.op === "insert")).toHaveLength(0);
    expect(writes.filter((w) => w.table === "deals")).toHaveLength(0);
  });
  it("source: the ₹1 floor is no longer reachable outside test mode (guard sits before safeGross)", () => {
    const s = fs.readFileSync("backend/payment_routes.ts", "utf8");
    const guard = s.indexOf("payment hold NOT recorded (amount unknown)");
    expect(guard).toBeGreaterThan(0);
    expect(guard).toBeLessThan(s.indexOf("const safeGross = Math.max(1, Math.round(grossAmount || 0));"));
  });
});

// ------------------------------------------------------------------ 5. UGC pay callback
describe("5 · UGC pay callback", () => {
  function dealsApp(sb: any, user: any, extra: any = {}) {
    const app = express(); app.use(express.json());
    const router = express.Router();
    const updateThreadState = vi.fn(async () => ({}));
    setupDealsChatRoutes(app, router, {
      supabase: sb, privilegedSupabase: sb, getDb: () => ({}), saveDb: () => {}, parseAuthUser: async () => user,
      sendNotification: vi.fn(async () => ({})), serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: vi.fn(async () => ({})),
      parseThreadState: (t: any) => ({ is_ugc: true, ugc_order_id: t.id, amount_fixed: extra.amount_fixed }), updateThreadState, enrichThread: async (t: any) => t,
      handleThreadApproveLiveLinks: vi.fn(), handleThreadApproveContent: vi.fn(), handleThreadSubmitLiveLink: vi.fn(),
      handleThreadRejectLiveLinks: vi.fn(), handleThreadDeclineLiveLinksResubmission: vi.fn(), getIsTestMode: () => false,
    } as any);
    app.use("/api", router);
    return { app, updateThreadState };
  }
  const brand = { user_id: "b1", role: "brand" };
  const thread = { id: "ugcord_9", is_ugc: true, brand_id: "b1", creator_id: "c1", flow_state: "AWAITING_PAYMENT" };

  it("a refunded (or refund-in-progress) row is not proof of payment", async () => {
    for (const refunded of [
      { status: "SUCCESS", gross_amount: 5000, refund_status: "PROCESSED", refund_amount: 5000 },
      { status: "SUCCESS", gross_amount: 5000, refund_status: "PENDING" },
      { status: "PENDING", payout_status: "PENDING", gross_amount: 5000 },
    ]) {
      const { client } = fakeSupabase({ chat_threads: [thread], transactions: [refunded] });
      const { app, updateThreadState } = dealsApp(client, brand);
      await serve(app, async (base) => {
        expect((await post(base, "/chat/v2/threads/ugcord_9/pay", {})).status).toBe(400);
      });
      expect(updateThreadState).not.toHaveBeenCalled();
    }
  });
  it("no amount anywhere → 409 AMOUNT_UNCONFIRMED (no invented ₹5,000), nothing marked funded", async () => {
    const { client, writes } = fakeSupabase({ chat_threads: [thread], transactions: [{ status: "SUCCESS", escrow_hold: true }] });
    const { app, updateThreadState } = dealsApp(client, brand);
    await serve(app, async (base) => {
      const r = await post(base, "/chat/v2/threads/ugcord_9/pay", {});
      expect(r.status).toBe(409);
      expect((await r.json()).code).toBe("AMOUNT_UNCONFIRMED");
    });
    expect(updateThreadState).not.toHaveBeenCalled();
    expect(writes.some((w) => JSON.stringify(w.payload || {}).includes("5000"))).toBe(false);
  });
  it("a real deposit with its amount still funds the order", async () => {
    const { client } = fakeSupabase({ chat_threads: [thread], transactions: [{ status: "SUCCESS", gross_amount: 4200 }], chat_messages: [] });
    const { app, updateThreadState } = dealsApp(client, brand);
    await serve(app, async (base) => {
      expect((await post(base, "/chat/v2/threads/ugcord_9/pay", {})).status).toBe(200);
    });
    expect(updateThreadState).toHaveBeenCalled();
  });
});

// ------------------------------------------------------------------ 6. fees
describe("6 · fee calculator guards", () => {
  const cfg = (config: any) => ({ from: () => { const q: any = { select: () => q, order: () => q, limit: () => q, maybeSingle: async () => ({ data: config, error: null }) }; return q; } });
  it("offer mode never charges more than the normal fee; a lower offer still applies", async () => {
    const high = await calculateFee(50000, cfg({ offer_mode: true, offer_fee_pct: 10 }) as any);
    expect(high.platformFee).toBe(2500);
    expect(high.feePercent).toBe(5);
    expect(high.discountApplied).toBe(0);
    const low = await calculateFee(10000, cfg({ offer_mode: true, offer_fee_pct: 2 }) as any);
    expect(low.platformFee).toBe(200);
    expect(low.feePercent).toBe(2);
    expect(low.discountApplied).toBe(1300);
  });
  it("flat discount: negative / non-numeric → 0; fee never below 0", async () => {
    for (const d of [-100, "abc", null]) {
      const r = await calculateFee(1000, { type: "flat_discount", discount_amount: d as any });
      expect(r.platformFee).toBe(150);
      expect(r.discountApplied).toBe(0);
      expect(r.creatorNet).toBe(850);
    }
    const big = await calculateFee(1000, { type: "flat_discount", discount_amount: 99999 });
    expect(big.platformFee).toBe(0);
    expect((await calculateFee(1000, { type: "flat_discount", discount_amount: 100 })).platformFee).toBe(50);
  });
});

// ------------------------------------------------------------------ 7. agreement
describe("7 · UGC agreement discloses the fee and TDS", () => {
  it("same wording as the campaign clause", () => {
    const u = agreementPlainText(ugcAgreement({ payout: 10000 } as any));
    expect(u).toMatch(/Convenience fee \(platform fee \+ GST\) & TDS \(as required by law\) are deducted from this payout as shown on the platform/);
    expect(agreementPlainText(campaignAgreement({ amount: 10000 } as any))).toMatch(/Convenience fee & TDS \(as required by law\) are deducted as shown/);
  });
});

// ------------------------------------------------------------------ 8. invite when already in the campaign
describe("8 · Invite to campaign when the creator is already in it", () => {
  it("campaignInviteConflict", () => {
    expect(campaignInviteConflict([], [])).toBeNull();
    expect(campaignInviteConflict([{ status: "REJECTED" }], [])).toBeNull();
    expect(campaignInviteConflict([{ status: "PENDING" }], [])).toEqual({ reason: "applied", thread_id: null });
    expect(campaignInviteConflict([{ status: "ACCEPTED" }], [{ id: "thread_camp_d1", flow_state: "ACTIVE" }])).toEqual({ reason: "in_deal", thread_id: "thread_camp_d1" });
    expect(campaignInviteConflict([], [{ id: "thread_camp_d2", status: "NEGOTIATING" }])).toEqual({ reason: "in_deal", thread_id: "thread_camp_d2" });
    // finished / cancelled deal = history: a new invite is fine
    expect(campaignInviteConflict([{ status: "ACCEPTED" }], [{ id: "t", status: "COMPLETED" }])).toBeNull();
    expect(campaignInviteConflict([], [{ id: "t", flow_state: "CANCELLED" }])).toBeNull();
  });

  function creatorsCtx(db: any) {
    const app = express(); app.use(express.json());
    const router = express.Router();
    setupCreatorsRoutes(app, router, {
      supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => ({ user_id: "b1", role: "brand", name: "Acme" }),
      syncEntityTags: vi.fn(), processBase64Image: vi.fn(), getSettings: () => ({}), markupForRole: () => 0, getActingBrandId: (u: any) => u.user_id,
      logTeamActivity: vi.fn(), sanitizeCreatorProfile: (p: any) => p, fetchCreatorReviews: vi.fn(), broadcastAdminNotification: vi.fn(), insertChatMessageToSupabase: vi.fn(),
    } as any);
    app.use("/api", router);
    return app;
  }
  const baseDb = (over: any = {}) => ({
    users: [{ user_id: "c1", name: "Pooja", role: "creator" }], creator_profiles: [{ user_id: "c1", name: "Pooja", is_claimed: true }],
    brand_profiles: [], brief_requests: [] as any[], chat_threads: [] as any[], chat_messages: [], notifications: [],
    campaigns: [{ campaign_id: "camp1", title: "Winter Launch", brand_user_id: "b1", applicants: [] as any[] }],
    ...over,
  });
  const invite = { message: "Join us", budget_range: "5000" };

  it("open deal chat for the picked campaign → 409 ALREADY_IN_CAMPAIGN with that thread, no invite stored", async () => {
    const db = baseDb({ chat_threads: [{ id: "thread_camp_d1", campaign_id: "camp1", creator_id: "c1", brand_id: "b1", flow_state: "ACTIVE" }] });
    await serve(creatorsCtx(db), async (base) => {
      const r = await post(base, "/creators/c1/send-brief", { ...invite, campaign_id: "camp1" });
      expect(r.status).toBe(409);
      expect(await r.json()).toMatchObject({ code: "ALREADY_IN_CAMPAIGN", reason: "in_deal", thread_id: "thread_camp_d1" });
    });
    expect(db.brief_requests).toHaveLength(0);
  });
  it("live application, matched by the campaign title (desktop sends no id) → 409 'applied'", async () => {
    const db = baseDb();
    db.campaigns[0].applicants.push({ creator_user_id: "c1", status: "applied" });
    await serve(creatorsCtx(db), async (base) => {
      const r = await post(base, "/creators/c1/send-brief", { ...invite, campaign_title: "  winter launch " });
      expect(r.status).toBe(409);
      expect(await r.json()).toMatchObject({ code: "ALREADY_IN_CAMPAIGN", reason: "applied", thread_id: null, campaign_id: "camp1" });
    });
  });
  it("other campaign / rejected application → the invite goes out as before", async () => {
    const db = baseDb();
    db.campaigns[0].applicants.push({ creator_user_id: "c1", status: "REJECTED" });
    await serve(creatorsCtx(db), async (base) => {
      expect((await post(base, "/creators/c1/send-brief", { ...invite, campaign_id: "camp1" })).status).toBe(200);
      expect((await post(base, "/creators/c1/send-brief", { ...invite, campaign_title: "Something else" })).status).toBe(200);
    });
    expect(db.brief_requests).toHaveLength(2);
  });
  it("the invite modal sends the picked campaign and shows 'Open chat' for ALREADY_IN_CAMPAIGN", () => {
    const s = fs.readFileSync("src/components/campaigns/InviteToCampaignModal.jsx", "utf8");
    expect(s).toContain("campaign_id: pickedId || undefined");
    expect(s).toContain('d?.code === "ALREADY_IN_CAMPAIGN"');
    expect(s).toContain('"Open chat"');
  });
});

// ------------------------------------------------------------------ 9. pitch masking
describe("9 · campaign application pitch: contact details masked on the server", () => {
  it("maskContactDetails", () => {
    const m = maskContactDetails("Love this! Mail me at pooja.s@gmail.com or call 98765 43210, ig: pooja.creates");
    expect(m).not.toMatch(/gmail|98765|43210|pooja\.creates/);
    expect(m).toContain("[hidden]");
    expect(m).toContain("Love this!");
    expect(checkComprehensiveDisallowedContent(m).blocked).toBe(false);
    // ordinary pitches are untouched
    const plain = "I have 890000 followers and avg reach 2300000. Rate ₹15,000 for 2 reels.";
    expect(maskContactDetails(plain)).toBe(plain);
    expect(maskContactDetails("")).toBe("");
  });

  it("POST /campaigns/apply saves the masked pitch (and still accepts the application)", async () => {
    const db: any = { campaigns: [{ campaign_id: "camp1", brand_user_id: "b1", title: "Winter" }] };
    const app = express(); app.use(express.json());
    const router = express.Router();
    setupCampaignsRoutes(app, router, {
      supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => ({ user_id: "c1", role: "creator", name: "Pooja" }),
      sendNotification: vi.fn(), serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: vi.fn(), syncEntityTags: vi.fn(),
      getActingBrandId: (u: any) => u.user_id, createEscrowTransaction: vi.fn(), isCreatorKycVerified: async () => true,
    } as any);
    app.use("/api", router);
    await serve(app, async (base) => {
      const r = await post(base, "/campaigns/apply", { campaign_id: "camp1", pitch: "WhatsApp me on 9876543210 or a.b@yahoo.in" });
      expect(r.status).toBe(200);
    });
    const saved = db.campaigns[0].applicants[0].pitch;
    expect(saved).not.toMatch(/9876543210|yahoo/);
    expect(saved).toContain("[hidden]");
  });
  it("source: the Supabase insert uses the masked pitch too", () => {
    expect(fs.readFileSync("backend/campaigns_routes.ts", "utf8")).toContain("pitch: applyPitch, // v347");
  });
});
