// v375: Razorpay header shows the Ybex logo (no name text); the Android app no longer refuses an action just because the
// WebView's online flag says offline; the payment total asks again when it failed.
import { describe, it, expect } from "vitest";
import fs from "fs";
const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v375 · payment screen fixes", () => {
  it("Razorpay: Ybex logo by absolute address, no name text (Ravi's written OK, logged)", () => {
    const r = read("src/lib/razorpay.js");
    expect(r).toContain('image: `${serverOrigin()}/pwa-512x512.png`');
    expect(r).toContain('name: "",');
    expect(fs.existsSync("public/pwa-512x512.png")).toBe(true);
    expect(read("docs/code/PROTECTED_CHANGES.md")).toContain("v375 Razorpay header");
  });
  it("Android app: an action is sent even when navigator.onLine is false; a real failure is still the calm offline error", () => {
    const a = read("src/lib/api.js");
    expect(a).toContain("if (isWrite && isOffline() && nativeAndroid()) config._offlineFlag = true;");
    expect(a).toContain("if (originalRequest?._offlineFlag && !error.response && isOffline()) return Promise.reject(makeOfflineError(originalRequest));");
  });
  it("payment total: Retry link and an automatic second try", () => {
    const f = read("src/components/payments/BrandFeeSummary.jsx");
    expect(f).toContain('data-testid="fee-quote-retry"');
    expect(f).toContain('window.addEventListener("online", again);');
  });
  it("Android app: Razorpay shows UPI apps inside the WebView (webview_intent, Ravi's written OK, logged)", () => {
    expect(read("src/lib/razorpay.js")).toContain("webview_intent: true,");
    expect(read("docs/code/PROTECTED_CHANGES.md")).toContain("v375 Razorpay webview_intent");
  });
  it("Earnings: payout-ready deals are read without the campaigns(title) embed (no FK → database 400 → retry card)", () => {
    const r = read("backend/payment_routes.ts");
    const block = r.slice(r.indexOf("const loadCreatorDeals"), r.indexOf('router.get("/creator/payout-eligible-deals"'));
    expect(block).toContain(".select('*, transactions(*)')");
    expect(block).not.toContain("campaigns(title)', ");
    expect(block).not.toMatch(/select\('[^']*campaigns\(title\)/);
    expect(block).toContain(".from('campaigns').select('campaign_id, title').in('campaign_id', campaignIds)");
    expect(read("docs/code/PROTECTED_CHANGES.md")).toContain("v375 Earnings");
  });
});
