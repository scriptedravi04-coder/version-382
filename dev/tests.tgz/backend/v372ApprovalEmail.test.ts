// v372 (Ravi's screenshot: "null value in column email of relation creator_profiles violates not-null constraint"):
// the live creator_profiles.email is NOT NULL. A handle-only approval retries with the placeholder login e-mail.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { approveCreatorApplication, sendApplicationDecisionEmail } from "./creatorApplication";
import { graphError } from "./instagramConnect";

/** Like the live database: creator_profiles.email and users.email are NOT NULL. */
function liveLikeClient() {
  const t: Record<string, any[]> = { waitlist: [], users: [], creator_profiles: [] };
  const from = (name: string) => {
    const filters: Array<(r: any) => boolean> = [];
    const q: any = {
      select() { return q; },
      ilike(c: string, v: string) { filters.push((r) => String(r[c] || "").toLowerCase() === String(v).replace(/\\([\\%_])/g, "$1").toLowerCase()); return q; },
      eq(c: string, v: any) { filters.push((r) => String(r[c]) === String(v)); return q; },
      limit() { return Promise.resolve({ data: t[name].filter((r) => filters.every((f) => f(r))), error: null }); },
      upsert(rows: any[]) {
        if ((name === "users" || name === "creator_profiles") && rows.some((r) => !r.email)) {
          return Promise.resolve({ error: { message: `null value in column "email" of relation "${name}" violates not-null constraint` } });
        }
        for (const r of rows) { const i = t[name].findIndex((x) => x.user_id === r.user_id); if (i >= 0) t[name][i] = { ...t[name][i], ...r }; else t[name].push(r); }
        return Promise.resolve({ error: null });
      },
      update(patch: any) { return { eq(c: string, v: any) { t[name].filter((r) => String(r[c]) === String(v)).forEach((r) => Object.assign(r, patch)); return Promise.resolve({ error: null }); } }; },
    };
    return q;
  };
  return { t, from };
}

describe("v372 · creator profile e-mail never null on the live table", () => {
  it("a handle-only approval works when the database refuses a null profile e-mail (placeholder, never mailed)", async () => {
    const c = liveLikeClient();
    c.t.waitlist.push({ id: "w1", name: "Riya", email: null, social_handle: "riya_k", followers: 12000, status: "Pending", source: "csv_import" });
    const r: any = await approveCreatorApplication(c.t.waitlist[0], { client: c, getDb: () => ({}), saveDb: () => {} } as any);
    expect(r.ok).toBe(true);
    expect(c.t.creator_profiles).toHaveLength(1);
    expect(c.t.creator_profiles[0].email).toBe(c.t.users[0].email);
    expect(c.t.creator_profiles[0].email).toMatch(/^unclaimed_.+@ybex\.io$/);
    expect(await sendApplicationDecisionEmail({ ...c.t.waitlist[0], email: c.t.creator_profiles[0].email, source: "app" }, "approved")).toBe(false);
  });
  it("admin creator edit gives an e-mail-less account a never-mailed placeholder", () => {
    expect(fs.readFileSync(path.join(__dirname, "admin_logs_creators_routes.ts"), "utf8")).toMatch(/noemail_\$\{targetId\}@ybex\.io/);
  });
});

describe("v372 · Meta refused Ybex's own token", () => {
  it("'Cannot call API for app … on behalf of user …' is TOKEN (admin must renew), not a creator problem", () => {
    const g = graphError({ error: { code: 200, message: "Cannot call API for app 913426198373843 on behalf of user 1822139072123996" } });
    expect(g.code).toBe("TOKEN");
    expect(g.error).toMatch(/Ybex's side/);
    expect(graphError({ error: { code: 190, message: "Error validating access token" } }).code).toBe("TOKEN");
    expect(graphError({ error: { code: 4 } }).code).toBe("RATE_LIMIT");
  });
});
