import { describe, it, expect, vi, beforeEach } from "vitest";

// v399: the Resend wrapper itself — a login code always goes now; a low-priority mail in the day is queued, not sent.
const sends: any[] = [];
vi.mock("resend", () => ({
  Resend: class { emails = { send: async (o: any) => { sends.push(o); return { data: { id: "real" }, error: null }; } }; constructor(_k?: string) {} },
}));

describe("v399 Resend wrapper with the email budget", () => {
  beforeEach(async () => {
    sends.length = 0;
    const eph = await import("./ephemeralStore");
    eph.configureEphemeralStore(null); eph._resetEphemeral();
    vi.useFakeTimers(); vi.setSystemTime(new Date(Date.UTC(2026, 10, 4, 10, 0))); // 3:30 pm IST
  });

  it("sends a login code at once and counts it; queues a low-priority mail in the day", async () => {
    const { Resend } = await import("./helpers");
    const { sentToday, queuedLowEmails } = await import("./emailBudget");
    const r = new Resend("re_test_key_123456789012345678901234567890");
    const otp: any = await r.emails.send({ from: "Ybex <noreply@ybexmedia.in>", to: "a@gmail.com", subject: "123456 is your Ybex code", html: "x" });
    expect(otp.data.id).toBe("real");
    const low: any = await r.emails.send({ priority: "low", from: "Ybex <noreply@ybexmedia.in>", to: "b@gmail.com", subject: "Welcome", html: "x" });
    expect(low.queued).toBe(true);
    expect(sends.map((s) => s.to[0])).toEqual(["a@gmail.com"]);
    expect(sends[0].priority).toBeUndefined();
    expect(await sentToday()).toBe(1);
    const q = await queuedLowEmails();
    expect(q).toHaveLength(1);
    expect(q[0].value.options.to).toEqual(["b@gmail.com"]);
    expect(q[0].value.options.priority).toBeUndefined();
    vi.useRealTimers();
  });

  it("in the night window a low-priority mail goes straight out when there is budget", async () => {
    vi.setSystemTime(new Date(Date.UTC(2026, 10, 4, 23, 0))); // 4:30 am IST
    const { Resend } = await import("./helpers");
    const r = new Resend("re_test_key_123456789012345678901234567890");
    const low: any = await r.emails.send({ priority: "low", from: "Ybex <noreply@ybexmedia.in>", to: "c@gmail.com", subject: "Reminder", html: "x" });
    expect(low.data.id).toBe("real");
    expect(sends.map((s) => s.to[0])).toEqual(["c@gmail.com"]);
    vi.useRealTimers();
  });
});
