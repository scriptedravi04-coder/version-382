import { describe, it, expect } from "vitest";
import { isLiveServer } from "./liveServer";
import { demoLoginEnabled } from "./admin_system_maintenance_routes";
import { isPublicClient } from "../src/lib/useDemoLogin";

// v383 (Ravi 30 Oct 2026: "Demo access (test server)" was still on the admin / app login screen).
// The live secrets carried DEMO_LOGIN=true but no live Razorpay key and no APP_URL, so the v376
// guard never fired. Cloud Run always sets K_SERVICE → treat that as live, and never show the link
// on ybexmedia.in or inside the installed app whatever the server answers.
describe("v383 · demo login can't show on the live server or public clients", () => {
  it("K_SERVICE (Cloud Run) alone makes the server live", () => {
    expect(isLiveServer({ K_SERVICE: "ybex" })).toBe(true);
    expect(isLiveServer({ K_SERVICE: "" })).toBe(false);
    expect(isLiveServer({})).toBe(false);
  });
  it("DEMO_LOGIN=true is ignored on Cloud Run", () => {
    expect(demoLoginEnabled({ DEMO_LOGIN: "true", K_SERVICE: "ybex" })).toBe(false);
    expect(demoLoginEnabled({ DEMO_LOGIN: "true" })).toBe(true); // Mac / local test server only
  });
  it("public site and the native app never ask for the demo link", () => {
    expect(isPublicClient({ hostname: "ybexmedia.in" } as any, null)).toBe(true);
    expect(isPublicClient({ hostname: "www.ybexmedia.in" } as any, null)).toBe(true);
    expect(isPublicClient({ hostname: "ybexapp.ai.studio" } as any, null)).toBe(true);
    expect(isPublicClient({ hostname: "localhost" } as any, { isNativePlatform: () => true })).toBe(true);
    expect(isPublicClient({ hostname: "localhost" } as any, null)).toBe(false);
    expect(isPublicClient({ hostname: "ybex-xyz.run.app" } as any, null)).toBe(false);
  });
});
