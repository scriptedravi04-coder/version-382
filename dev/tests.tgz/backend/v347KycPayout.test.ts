// v347: (A) the UPI given in creator KYC counts as the payout account; (B) brand KYC form keeps
// typed text across a refresh (per-user draft).
import { describe, it, expect, vi, beforeEach } from "vitest";
import fs from "fs";
import path from "path";
import React from "react";
import { render, screen, cleanup, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { kycPayoutFromRows, toPublicKycPayoutMethod, maskUpi, readKycPayoutAccount, setupKycPayoutMethodRoutes, hasKycPayoutAccount } from "./kycPayoutMethod";
import { setupCreatorPayoutRequestRoutes } from "./creatorPayoutRequests";

const apiMock = vi.hoisted(() => ({ get: vi.fn(), post: vi.fn() }));
vi.mock("../src/lib/api", () => ({ api: apiMock }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
vi.mock("../src/contexts/AuthContext", () => ({
  useAuth: () => ({ user: { user_id: "B1", name: "Acme Foods", email: "ops@acme.in", phone: "9999999999" }, refreshUser: vi.fn() }),
}));

import { mergePayoutMethods, fetchPayoutMethods, payoutMethodLabel } from "../src/lib/payoutMethods";
import {
  saveBrandKycDraft, loadBrandKycDraft, clearBrandKycDraft, shouldRestoreBrandKycDraft, applyBrandKycDraft,
  pickBrandKycDraftFields, BRAND_KYC_DRAFT,
} from "../src/lib/brandKycDraft";
import BrandKycMobile from "../src/pages/brand/BrandKycMobile";

const ROOT = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(ROOT, p), "utf8");

/** Minimal Supabase stand-in: rows per table, filters by eq / in, records updates. */
function fakeClient(tables: Record<string, any[]>, opts: { failTables?: string[] } = {}) {
  const updates: any[] = [];
  const from = (table: string) => {
    let rows = [...(tables[table] || [])];
    let patch: any = null;
    const fail = (opts.failTables || []).includes(table);
    const b: any = {
      select: () => b, order: () => b, limit: () => b, range: () => b, or: () => b,
      eq: (k: string, v: any) => { rows = rows.filter((r) => String(r[k]) === String(v)); return b; },
      in: (k: string, vs: any[]) => { rows = rows.filter((r) => vs.map(String).includes(String(r[k]))); return b; },
      update: (p: any) => { patch = p; return b; },
      maybeSingle: () => Promise.resolve(fail ? { data: null, error: { message: "boom" } } : { data: rows[0] || null, error: null }),
      then: (res: any, rej: any) => {
        if (patch) updates.push({ table, patch, rows });
        return Promise.resolve(fail ? { data: null, error: { message: "boom" } } : { data: rows, error: null }).then(res, rej);
      },
    };
    return b;
  };
  return { from, updates };
}

function fakeRouter() {
  const routes: Record<string, any> = {};
  const add = (m: string) => (p: string, h: any) => { routes[`${m} ${p}`] = h; };
  return { routes, get: add("GET"), post: add("POST") };
}
function fakeRes() {
  const r: any = { statusCode: 200, body: null };
  r.status = (c: number) => { r.statusCode = c; return r; };
  r.json = (b: any) => { r.body = b; return r; };
  return r;
}

describe("v347 A · KYC UPI is the creator's payout account", () => {
  it("reads the UPI from creator_kyc, else the verifications documents, else the profile mirror", () => {
    expect(kycPayoutFromRows({ upi_id: "ravi@okhdfc", full_name: "Ravi K", status: "PENDING" })?.upi_id).toBe("ravi@okhdfc");
    const v = [{ status: "pending", note: "", documents: { upi_id: "neha@ybl", creator_name: "Neha" }, created_at: "2026-10-01" }];
    expect(kycPayoutFromRows(null, v)).toMatchObject({ method_type: "UPI", upi_id: "neha@ybl", account_holder_name: "Neha" });
    expect(kycPayoutFromRows(null, [], { upi_id: "x1@paytm" })?.upi_id).toBe("x1@paytm");
    // onboarding auto-rows are not KYC
    expect(kycPayoutFromRows(null, [{ note: "Auto-submitted during onboarding", documents: { upi_id: "a@b" } }])).toBeNull();
  });
  it("invalid UPI falls back to a valid KYC bank; rejected KYC does not count", () => {
    const bank = kycPayoutFromRows({ upi_id: "nope", bank_account_no: "123456789012", bank_ifsc: "hdfc0001234", bank_holder_name: "Ravi K" });
    expect(bank).toMatchObject({ method_type: "BANK", bank_ifsc: "HDFC0001234" });
    expect(kycPayoutFromRows({ upi_id: "ravi@okhdfc", status: "REJECTED" })).toBeNull();
    expect(kycPayoutFromRows(null, [{ status: "rejected", documents: { upi_id: "ravi@okhdfc" } }])).toBeNull();
    expect(kycPayoutFromRows({ status: "APPROVED" })).toBeNull();
  });
  it("what the browser gets: source kyc, default, UPI masked like refund accounts, never a full account number", () => {
    expect(maskUpi("ravi@okhdfc")).toBe("ra***@okhdfc");
    const pub = toPublicKycPayoutMethod(kycPayoutFromRows({ upi_id: "ravi@okhdfc", full_name: "Ravi K" }));
    expect(pub).toMatchObject({ id: "kyc", method_type: "UPI", upi_id: "ra***@okhdfc", source: "kyc", is_default: true });
    expect(JSON.stringify(pub)).not.toContain("ravi@okhdfc");
    const bankPub = toPublicKycPayoutMethod(kycPayoutFromRows({ bank_account_no: "123456789012", bank_ifsc: "HDFC0001234", bank_holder_name: "Ravi K", pan_number: "ABCDE1234F" }));
    expect(bankPub).toMatchObject({ method_type: "BANK", account_last4: "9012", upi_id: null });
    expect(JSON.stringify(bankPub)).not.toContain("123456789012");
    expect(JSON.stringify(bankPub)).not.toContain("ABCDE1234F");
  });
  it("lookup: Supabase rows, local db, and a failed lookup is reported (not 'no account')", async () => {
    const c = fakeClient({ creator_kyc: [{ creator_id: "c1", upi_id: "ravi@okhdfc", pan_number: "ABCDE1234F" }] });
    expect((await readKycPayoutAccount(c, null, "c1")).account?.upi_id).toBe("ravi@okhdfc");
    expect((await readKycPayoutAccount(c, null, "c2")).account).toBeNull();
    const local = { creator_kyc: [], verifications: [{ user_id: "c3", status: "pending", documents: { upi_id: "z9@ybl" }, created_at: "2026-10-01" }] };
    expect((await readKycPayoutAccount(null, local, "c3")).account?.upi_id).toBe("z9@ybl");
    const bad = fakeClient({}, { failTables: ["creator_kyc"] });
    expect((await readKycPayoutAccount(bad, null, "c1")).error).toBeTruthy();
    expect(await hasKycPayoutAccount(bad, "c1")).toBeNull();
  });
  it("GET /creator/payment-methods/kyc: creators only, masked default method, [] when none, 503 on failure", async () => {
    const run = async (client: any, user: any) => {
      const r = fakeRouter();
      setupKycPayoutMethodRoutes(r, { supabase: client, privilegedSupabase: client, getDb: () => ({}), parseAuthUser: async () => user });
      const res = fakeRes();
      await r.routes["GET /creator/payment-methods/kyc"]({}, res);
      return res;
    };
    const c = fakeClient({ creator_kyc: [{ creator_id: "c1", upi_id: "ravi@okhdfc" }] });
    const ok = await run(c, { user_id: "c1", role: "creator" });
    expect(ok.body).toEqual([expect.objectContaining({ upi_id: "ra***@okhdfc", source: "kyc", is_default: true })]);
    expect((await run(c, { user_id: "c2", role: "creator" })).body).toEqual([]);
    expect((await run(c, { user_id: "b1", role: "brand" })).statusCode).toBe(403);
    expect((await run(fakeClient({}, { failTables: ["creator_kyc"] }), { user_id: "c1", role: "creator" })).statusCode).toBe(503);
  });
  it("payout-request-ready accepts the KYC UPI when no method is saved (nobody is asked twice)", async () => {
    const tables = {
      creator_payment_methods: [],
      creator_kyc: [{ creator_id: "c1", upi_id: "ravi@okhdfc", status: "APPROVED" }],
      verifications: [],
      transactions: [{ id: "t1", creator_id: "c1", deal_id: "d1", status: "SUCCESS", payout_status: "RELEASED", creator_net_amount: 900 }],
      deals: [], ugc_orders: [], users: [], platform_fee_config: [],
    };
    const call = async (t: any) => {
      const r = fakeRouter();
      setupCreatorPayoutRequestRoutes(r, { supabase: null, privilegedSupabase: fakeClient(t), parseAuthUser: async () => ({ user_id: "c1", role: "creator" }), sendNotification: vi.fn() });
      const res = fakeRes();
      await r.routes["POST /creator/payout-request-ready"]({ body: {} }, res);
      return res;
    };
    const ok = await call(tables);
    expect(ok.body).toMatchObject({ ok: true, count: 1 });
    const none = await call({ ...tables, creator_kyc: [{ creator_id: "c1", status: "APPROVED" }] });
    expect(none.body?.code).toBe("NO_PAYOUT_METHOD");
  });
  it("is wired: server route, payout-ready fallback, Earnings / mobile / assistant read through the shared helper", () => {
    const server = read("backend/server.ts");
    expect(server).toContain('import { setupKycPayoutMethodRoutes } from "./kycPayoutMethod";');
    expect(server).toContain("setupKycPayoutMethodRoutes(router, { supabase, privilegedSupabase, getDb, parseAuthUser });");
    expect(read("backend/creatorPayoutRequests.ts")).toContain("await hasKycPayoutAccount(client, uid)");
    const e = read("src/pages/dashboard/Earnings.jsx");
    expect(e).toContain("await fetchPayoutMethods({ bypassCache: true })");
    expect(e).not.toContain("api.get('creator/payment-methods'");
    expect(read("src/components/payments/CreatorEarningsMobile.jsx")).toContain("payoutMethodLabel(primaryMethod)");
    expect(read("src/components/assist/creator/tools.js")).toContain("fetchPayoutMethods({})");
    expect(read("src/components/payments/mobile/PayoutMethodSheet.jsx")).toContain('upi: fromKyc ? "" :');
    // admin payout already falls back to creator_kyc (same source)
    expect(read("backend/payment_routes.ts")).toContain("pickPayoutAccount(payoutMethodsMap.get(cid), creatorProfilesMap.get(cid), creatorKycMap.get(cid))");
  });
});

describe("v347 A · browser helper", () => {
  beforeEach(() => { apiMock.get.mockReset(); });
  it("a saved method wins over KYC; KYC fills in when nothing is saved", async () => {
    const kyc = [{ id: "kyc", upi_id: "ra***@okhdfc", source: "kyc", is_default: true }];
    expect(mergePayoutMethods([{ id: "pm1", upi_id: "new@ybl" }], kyc)).toEqual([{ id: "pm1", upi_id: "new@ybl" }]);
    expect(mergePayoutMethods([], kyc)).toEqual(kyc);
    expect(mergePayoutMethods([], { error: "x" })).toEqual([]);
    apiMock.get.mockImplementation((url: string) => Promise.resolve({ data: url === "creator/payment-methods" ? [] : kyc }));
    expect(await fetchPayoutMethods()).toEqual(kyc);
    apiMock.get.mockImplementation((url: string) => (url === "creator/payment-methods" ? Promise.resolve({ data: [] }) : Promise.reject(new Error("x"))));
    expect(await fetchPayoutMethods()).toEqual([]);
    apiMock.get.mockReset();
    apiMock.get.mockImplementation((url: string) => Promise.resolve({ data: url === "creator/payment-methods" ? [{ id: "pm1", upi_id: "new@ybl" }] : kyc }));
    expect(await fetchPayoutMethods()).toEqual([{ id: "pm1", upi_id: "new@ybl" }]);
    expect(apiMock.get).not.toHaveBeenCalledWith("creator/payment-methods/kyc", expect.anything());
    apiMock.get.mockRejectedValue(new Error("down"));
    await expect(fetchPayoutMethods()).rejects.toThrow("down");
    expect(payoutMethodLabel(kyc[0])).toBe("UPI · ra***@okhdfc (from KYC)");
    expect(payoutMethodLabel({ account_last4: "9012" })).toBe("Bank ••9012");
  });
});

describe("v347 B · brand KYC draft", () => {
  beforeEach(() => {
    cleanup();
    apiMock.get.mockReset(); apiMock.post.mockReset();
    window.localStorage.clear();
    window.localStorage.setItem("ybex_user", JSON.stringify({ user_id: "B1" }));
  });

  it("keeps only text fields, per user; cleared on demand", () => {
    expect(pickBrandKycDraftFields({ companyName: "Acme", proofUrl: "kyc/x.pdf", otp: "123456", businessType: "hack" })).toEqual({ companyName: "Acme" });
    saveBrandKycDraft({ companyName: "Acme", gst: "07AAAAA0000A1Z5", proofUrl: "kyc/x.pdf" }, "business");
    expect(window.localStorage.getItem(`${BRAND_KYC_DRAFT}::B1`)).toBeTruthy();
    expect(window.localStorage.getItem(`${BRAND_KYC_DRAFT}::B1`)).not.toContain("kyc/x.pdf");
    expect(loadBrandKycDraft()?.fields).toEqual({ companyName: "Acme", gst: "07AAAAA0000A1Z5" });
    window.localStorage.setItem("ybex_user", JSON.stringify({ user_id: "B2" }));
    expect(loadBrandKycDraft()).toBeNull(); // another account on the same browser
    window.localStorage.setItem("ybex_user", JSON.stringify({ user_id: "B1" }));
    clearBrandKycDraft();
    expect(loadBrandKycDraft()).toBeNull();
  });

  it("restores only when the server has no KYC (or a rejected one, with a newer draft)", () => {
    const draft = { saved_at: "2026-10-19T10:00:00Z", fields: { companyName: "Acme" } };
    expect(shouldRestoreBrandKycDraft(null, draft)).toBe(true);
    expect(shouldRestoreBrandKycDraft({ status: "PENDING" }, draft)).toBe(false);
    expect(shouldRestoreBrandKycDraft({ status: "APPROVED" }, draft)).toBe(false);
    expect(shouldRestoreBrandKycDraft({ status: "REJECTED", updated_at: "2026-10-18T10:00:00Z" }, draft)).toBe(true);
    expect(shouldRestoreBrandKycDraft({ status: "REJECTED", updated_at: "2026-10-20T10:00:00Z" }, draft)).toBe(false);
    expect(shouldRestoreBrandKycDraft(null, null)).toBe(false);
    expect(applyBrandKycDraft({ companyName: "X", pocEmail: "a@b.c", proofUrl: "p" }, { fields: { companyName: "Acme", pocEmail: "" } }))
      .toEqual({ companyName: "Acme", pocEmail: "a@b.c", proofUrl: "p" });
  });

  it("mobile: typed text survives a remount (refresh) with a 'Draft restored' note; cleared after submit", async () => {
    apiMock.get.mockImplementation((url: string) => Promise.resolve(String(url).startsWith("brands/me") ? { data: { representative_name: "Priya Shah" } } : { data: { status: "NOT_SUBMITTED" } }));
    apiMock.post.mockResolvedValue({ data: { ok: true } });
    const first = render(React.createElement(MemoryRouter, null, React.createElement(BrandKycMobile)));
    fireEvent.click(await screen.findByText("Start verification"));
    fireEvent.change(screen.getByPlaceholderText("ABCDE1234F"), { target: { value: "abcde1234f" } });
    fireEvent.change(screen.getByPlaceholderText("www.yourbrand.com or instagram.com/brand"), { target: { value: "acme.in" } });
    await waitFor(() => expect(loadBrandKycDraft()?.fields).toMatchObject({ pan: "ABCDE1234F", siteUrl: "acme.in" }));
    first.unmount();

    render(React.createElement(MemoryRouter, null, React.createElement(BrandKycMobile)));
    expect(await screen.findByTestId("kyc-draft-restored")).toBeTruthy();
    expect((screen.getByPlaceholderText("ABCDE1234F") as HTMLInputElement).value).toBe("ABCDE1234F");
    expect((screen.getByPlaceholderText("www.yourbrand.com or instagram.com/brand") as HTMLInputElement).value).toBe("acme.in");
    fireEvent.click(screen.getByText("Continue"));
    fireEvent.click(await screen.findByText("Submit verification"));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("brand/kyc/submit", expect.objectContaining({ panNumber: "ABCDE1234F", websiteUrl: "acme.in" })));
    await screen.findByText("Verification submitted");
    expect(loadBrandKycDraft()).toBeNull();
  });

  it("mobile: a pending KYC loads from the server, not the draft", async () => {
    saveBrandKycDraft({ companyName: "Draft Name", pan: "ZZZZZ9999Z" }, "business");
    apiMock.get.mockImplementation((url: string) => Promise.resolve(String(url).startsWith("brands/me") ? { data: {} } : { data: { status: "PENDING", documents: { company_name: "Server Co" } } }));
    render(React.createElement(MemoryRouter, null, React.createElement(BrandKycMobile)));
    await waitFor(() => expect(apiMock.get).toHaveBeenCalled());
    await new Promise((r) => setTimeout(r, 20));
    expect(screen.queryByTestId("kyc-draft-restored")).toBeNull();
    expect(screen.queryByText("Start verification")).toBeNull();
  });

  it("desktop page uses the same draft helper and clears it after submit", () => {
    const d = read("src/pages/brand/BrandKyc.jsx");
    expect(d).toContain("restoreDraft(null); // v347");
    expect(d).toContain("clearBrandKycDraft(); // v347");
    expect(d).toContain('data-testid="kyc-draft-restored"');
    expect(d).toContain("gst: gstCert, pan: brandPan");
    expect(d).not.toMatch(/saveBrandKycDraft\(\{[^}]*businessProofUrl/);
  });
});
