// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach } from "vitest";
import fs from "node:fs";

// v398 (Ravi 3 Nov): /admin and /ybx-admin showed "Failed to fetch dynamically imported module" after a deploy and
// Reload did not help — the service worker kept giving the old saved page. Now the page moves to the new version.
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");
const flush = () => new Promise((r) => setTimeout(r, 30));

function setup({ waiting = false, controller = true } = {}) {
  const reload = vi.fn();
  Object.defineProperty(window, "location", { configurable: true, value: { ...window.location, reload } });
  const listeners = {};
  const postMessage = vi.fn(() => { setTimeout(() => listeners.controllerchange && listeners.controllerchange(), 5); });
  const reg = { update: vi.fn(() => Promise.resolve()), unregister: vi.fn(() => Promise.resolve(true)), installing: null, waiting: waiting ? { postMessage } : null };
  Object.defineProperty(navigator, "serviceWorker", {
    configurable: true,
    value: { controller: controller ? {} : null, getRegistrations: () => Promise.resolve([reg]), addEventListener: (n, fn) => { listeners[n] = fn; } },
  });
  return { reload, reg, postMessage };
}

describe("v398 old page after a deploy", () => {
  beforeEach(() => { sessionStorage.clear(); vi.resetModules(); });

  it("knows a missing screen file when it sees one", async () => {
    const { isChunkLoadError } = await import("./lib/staleBuild");
    expect(isChunkLoadError(new TypeError("Failed to fetch dynamically imported module: https://ybexmedia.in/assets/Admin-DLnuBfma.js"))).toBe(true);
    expect(isChunkLoadError(new Error("Cannot read properties of undefined (reading 'name')"))).toBe(false);
  });

  it("lets the waiting new version take over, then reloads", async () => {
    const { reload, postMessage, reg } = setup({ waiting: true });
    const { recoverFromStaleBuild } = await import("./lib/staleBuild");
    expect(recoverFromStaleBuild()).toBe(true);
    await flush(); await flush();
    expect(postMessage).toHaveBeenCalledWith({ type: "SKIP_WAITING" });
    expect(reg.unregister).not.toHaveBeenCalled();
    expect(reload).toHaveBeenCalledTimes(1);
  });

  it("with no new version waiting, drops the old service worker so the reload comes from the server", async () => {
    const { reload, reg } = setup({ waiting: false });
    const { recoverFromStaleBuild } = await import("./lib/staleBuild");
    recoverFromStaleBuild();
    await flush();
    expect(reg.unregister).toHaveBeenCalled();
    expect(reload).toHaveBeenCalledTimes(1);
  });

  it("never loops: a second failure right after shows the screen, the button still forces it", async () => {
    const { reload } = setup();
    const { recoverFromStaleBuild } = await import("./lib/staleBuild");
    expect(recoverFromStaleBuild()).toBe(true);
    expect(recoverFromStaleBuild()).toBe(false);
    expect(recoverFromStaleBuild({ force: true })).toBe(true);
    await flush();
    expect(reload).toHaveBeenCalledTimes(2);
  });

  it("every lazy screen and both error screens use it; the app page is never cached", () => {
    expect(read("./App.jsx")).toMatch(/recoverFromStaleBuild\(\)/);
    expect(read("./index.jsx")).toMatch(/isChunkLoadError\(errMessage\) && recoverFromStaleBuild\(\)/);
    for (const f of ["./pages/dashboard/Dashboard.jsx", "./components/feedback/DesktopEva.jsx", "./pages/dashboard/Landing.jsx"]) expect(read(f)).toMatch(/lazyRetry/);
    expect(read("./pages/dashboard/Dashboard.jsx")).not.toMatch(/= lazy\(/);
    expect(read("./components/PageErrorBoundary.jsx")).toMatch(/Getting the latest Ybex/);
    expect(read("./components/ErrorBoundary.jsx")).toMatch(/recoverFromStaleBuild/);
    const server = read("../backend/server.ts");
    expect(server).toMatch(/res\.setHeader\("Cache-Control", "no-cache"\); \/\/ v398/);
    expect(server).toMatch(/\\\.html\$\/i\.test\(filePath\)/);
  });
});
