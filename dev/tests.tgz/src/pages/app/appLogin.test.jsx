import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import fs from "fs";
import path from "path";
import { render, screen, cleanup, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter, Routes, Route } from "react-router-dom";

const apiMock = vi.hoisted(() => ({ get: vi.fn(), post: vi.fn() }));
const auth = vi.hoisted(() => ({ login: vi.fn(), signup: vi.fn(), setUser: vi.fn() }));
vi.mock("../../lib/api", () => ({ api: apiMock }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
vi.mock("../../contexts/AuthContext", () => ({ useAuth: () => ({ user: null, loading: false, ...auth }) }));

import AppContinue from "./AppContinue";
import AppWelcome from "./AppWelcome";
import { detectPlatform, installSteps } from "../../lib/installGuide";

const read = (p) => fs.readFileSync(path.resolve(__dirname, "../../..", p), "utf8");

function renderAt(url) {
  return render(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/app" element={<AppWelcome />} />
        <Route path="/app/continue/:role" element={<AppContinue />} />
        <Route path="/dashboard" element={<div>DASHBOARD</div>} />
        <Route path="/app/photo" element={<div>PHOTO STEP</div>} />
        <Route path="/onboarding" element={<div>ONBOARDING</div>} />
      </Routes>
    </MemoryRouter>
  );
}

const typeEmail = (v) => fireEvent.change(screen.getByTestId("app-email"), { target: { value: v } });

describe("Session 42 — app login (email first, OTP first, password second)", () => {
  beforeEach(() => { cleanup(); apiMock.get.mockReset(); apiMock.post.mockReset(); Object.values(auth).forEach((f) => f.mockReset()); localStorage.clear(); });

  it("welcome shows only two cards: Creator and Brand / Agency", () => {
    renderAt("/app");
    expect(screen.getByTestId("app-role-creator")).toBeTruthy();
    expect(screen.getByTestId("app-role-brand")).toBeTruthy();
    expect(screen.getByText(/Or an agency/)).toBeTruthy();
    expect(screen.queryByText(/Agency$/)).toBeNull();
  });

  // Session 48 (Ravi): an account WITH a password opens on the password box ("Log in with password"
  // big) and "Log in with OTP instead" small below it. The OTP path still works from that link.
  it("existing account with a password → password first, OTP as the small link → code logs in", async () => {
    apiMock.post.mockImplementation((url, body) => {
      if (url === "auth/check-email") return Promise.resolve({ data: { exists: true, role: "creator", has_password: true } });
      if (url === "auth/login-otp") return Promise.resolve({ data: { success: true } });
      if (url === "auth/login") return Promise.resolve({ data: { token: "T", user: { user_id: "U1", role: "creator", onboarded: true } } });
      return Promise.reject(new Error("unexpected " + url));
    });
    renderAt("/app/continue/creator");
    fireEvent.click(screen.getByTestId("app-have-account")); // v376: creators see the one-screen join first; login is one tap away
    typeEmail("Riya@Mail.com ");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    expect(await screen.findByTestId("app-password")).toBeTruthy();
    expect(screen.getByTestId("app-password-login").textContent).toMatch(/Log in with password/);
    expect(screen.queryByTestId("app-continue-otp")).toBeNull();
    fireEvent.click(screen.getByTestId("app-use-otp"));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("auth/login-otp", { email: "riya@mail.com", app_role: "creator" }));
    fireEvent.change(await screen.findByTestId("app-login-code"), { target: { value: "123456" } });
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("auth/login", { email: "riya@mail.com", otp: "123456", app_role: "creator" }));
    expect(await screen.findByText("DASHBOARD")).toBeTruthy();
    expect(localStorage.getItem("ybex_token")).toBe("T");
  });

  it("existing account with a password → password logs in", async () => {
    apiMock.post.mockResolvedValue({ data: { exists: true, role: "creator", has_password: true } });
    auth.login.mockResolvedValue({ user_id: "U1", role: "creator", onboarded: true });
    renderAt("/app/continue/creator");
    fireEvent.click(screen.getByTestId("app-have-account")); // v376: creators see the one-screen join first; login is one tap away
    typeEmail("riya@mail.com");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    fireEvent.change(await screen.findByTestId("app-password"), { target: { value: "secret123" } });
    fireEvent.click(screen.getByTestId("app-password-login"));
    await waitFor(() => expect(auth.login).toHaveBeenCalledWith("riya@mail.com", "secret123", "creator"));
  });

  it("no password on the account → no password link", async () => {
    apiMock.post.mockResolvedValue({ data: { exists: true, role: "brand", has_password: false } });
    renderAt("/app/continue/brand");
    typeEmail("ops@acme.in");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    expect(await screen.findByTestId("app-continue-otp")).toBeTruthy();
    expect(screen.queryByTestId("app-use-password")).toBeNull();
  });

  it("email belongs to the other role → offer that role", async () => {
    apiMock.post.mockResolvedValue({ data: { exists: true, role: "brand", has_password: true } });
    renderAt("/app/continue/creator");
    fireEvent.click(screen.getByTestId("app-have-account")); // v376: creators see the one-screen join first; login is one tap away
    typeEmail("ops@acme.in");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    // v408 (Ravi 5 Nov): the Log in screen is for creators AND brands — a brand's email logs in as a brand straight away
    expect(await screen.findByTestId("app-password")).toBeTruthy(); // Session 48: has a password → password first
    expect(screen.queryByText("This email is a Brand / Agency account")).toBeNull();
  });

  // v376 (Ravi: "signup bahut lamba hai — password hatao, city / niche / KYC baad me"): a new email gets the code at
  // once (no name / mobile / password form), and a new creator lands on Home, not in onboarding.
  it("new email on Log in → no account made, sent to the Instagram step (v408)", async () => {
    apiMock.post.mockImplementation((url, body) => {
      if (url === "auth/check-email") return Promise.resolve({ data: { exists: false } });
      if (url === "auth/signup") return Promise.resolve({ data: { requiresVerification: true } });
      if (url === "auth/verify-email") return Promise.resolve({ data: { success: true, token: "N", user: { user_id: "U2", role: "creator", onboarded: false, created_at: new Date().toISOString() } } });
      return Promise.reject(new Error("unexpected " + url));
    });
    renderAt("/app/continue/creator");
    fireEvent.click(screen.getByTestId("app-have-account")); // v376: creators see the one-screen join first; login is one tap away
    typeEmail("new@mail.com");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    // v408 (Ravi 5 Nov): a NEW email on the creator Log in screen no longer makes an account without the Instagram check —
    // "Join with my Instagram" takes them to the Instagram screen; no sign-up call is made.
    expect(await screen.findByTestId("app-noaccount-join")).toBeTruthy();
    expect(apiMock.post.mock.calls.find(([u]) => u === "auth/signup")).toBeUndefined();
    fireEvent.click(screen.getByTestId("app-noaccount-join"));
    expect(await screen.findByTestId("ig-first-input")).toBeTruthy();
  });

  it("v376: a new brand still goes to brand onboarding (company details)", async () => {
    apiMock.post.mockImplementation((url) => {
      if (url === "auth/check-email") return Promise.resolve({ data: { exists: false } });
      if (url === "auth/signup") return Promise.resolve({ data: { requiresVerification: true } });
      if (url === "auth/verify-email") return Promise.resolve({ data: { success: true, token: "N", user: { user_id: "B2", role: "brand", onboarded: false } } });
      return Promise.reject(new Error("unexpected " + url));
    });
    renderAt("/app/continue/brand");
    typeEmail("brand@mail.com");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    fireEvent.change(await screen.findByTestId("app-verify-code"), { target: { value: "654321" } });
    expect(await screen.findByText("ONBOARDING")).toBeTruthy();
  });

  it("the installed app starts at /app and the website pages send it there", () => {
    expect(JSON.parse(read("public/manifest.json")).start_url).toBe("/app");
    const app = read("src/App.jsx");
    expect(app).toContain('<Route path="/app" ');
    expect(app).toMatch(/path="\/" element=\{<InstalledAppGoesToApp>/);
    // v370: /login and /signup send the website to the same app sign-in (WebAuthToApp)
    expect(app).toMatch(/path="\/login" element=\{<WebAuthToApp login>/); // v408: /login opens the Log in screen
    expect(app).toMatch(/path="\/signup" element=\{<WebAuthToApp>/);
  });
});

describe("Session 42 — install steps per browser", () => {
  const IPHONE_CHROME = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0 Mobile/15E148 Safari/604.1";
  const IPHONE_SAFARI = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1";
  const OLD_CHROME = IPHONE_CHROME.replace("17_4", "15_2");
  const INSTA = IPHONE_SAFARI + " Instagram 300.0";

  it("iPhone Chrome gets Chrome's own steps, not 'open Safari'", () => {
    const g = installSteps(detectPlatform(IPHONE_CHROME));
    expect(g.kind).toBe("steps");
    expect(g.title).toMatch(/Chrome/);
    expect(g.steps.join(" ")).toMatch(/address bar/);
  });
  it("iPhone Safari gets Safari steps", () => {
    expect(installSteps(detectPlatform(IPHONE_SAFARI)).steps[0]).toMatch(/Safari/);
  });
  it("old iOS in Chrome, or Instagram's browser → open in a real browser first", () => {
    expect(installSteps(detectPlatform(OLD_CHROME)).kind).toBe("switch");
    expect(installSteps(detectPlatform(INSTA)).kind).toBe("switch");
  });
  it("desktop gets a QR code", () => {
    expect(installSteps(detectPlatform("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124")).kind).toBe("qr");
  });
});
