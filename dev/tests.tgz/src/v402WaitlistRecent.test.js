import { describe, it, expect } from "vitest";
import { waitlistNewestOrder, waitlistSourceKind, waitlistChipMatch, WAITLIST_CHIPS, WAITLIST_SORTS } from "./components/admin/WaitlistManager";

// v402 (Ravi 4 Nov): the 720 CSV leads sat on top (most followers first); today's ad sign-ups were buried.
describe("v402 waitlist: newest first, app sign-ups vs CSV", () => {
  const rows = [
    { id: "csv1", status: "Pending", source: "csv_import", ig_followers: 900000, created_at: "2026-10-14T10:00:00Z" },
    { id: "ad1", status: "Pending", ig_followers: 1200, created_at: "2026-11-04T09:00:00Z" },
    { id: "ad2", status: "Pending", ig_followers: 3000, created_at: "2026-11-04T11:00:00Z" },
    { id: "old", status: "Approved", ig_followers: 5000, created_at: "2026-11-04T12:00:00Z" },
    { id: "work", status: "Pending", source: "low_followers_work", ig_followers: 120, created_at: "2026-11-03T08:00:00Z" },
  ];
  it("waiting rows newest first; approved after", () => {
    expect([...rows].sort(waitlistNewestOrder).map((r) => r.id)).toEqual(["ad2", "ad1", "work", "csv1", "old"]);
  });
  it("chips split app sign-ups (ads) from the CSV import", () => {
    expect(rows.map(waitlistSourceKind)).toEqual(["csv", "app", "app", "app", "work"]);
    expect(rows.filter((r) => waitlistChipMatch(r, "app")).map((r) => r.id)).toEqual(["ad1", "ad2", "old"]);
    expect(rows.filter((r) => waitlistChipMatch(r, "csv")).map((r) => r.id)).toEqual(["csv1"]);
    expect(WAITLIST_CHIPS.map(([k]) => k)).toEqual(expect.arrayContaining(["app", "csv"]));
    expect(WAITLIST_SORTS[0][0]).toBe("newest");
  });
});
