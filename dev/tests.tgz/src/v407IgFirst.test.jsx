import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { render, screen, fireEvent, act, cleanup } from "@testing-library/react";

// v407 (Ravi 5 Nov): Join screen fetches the username by itself (spinner in the box, "name · 10.2K followers" under it),
// and an Instagram username that already has an account → Log in, not a second sign-up.
const { api } = vi.hoisted(() => ({ api: { post: vi.fn() } }));
vi.mock("./lib/api", () => ({ api }));
api.get = vi.fn(() => Promise.resolve({ data: { faces: [], lines: [] } }));
vi.mock("./lib/followerGate", () => ({ loadFollowerMin: async () => 500, belowMinFollowers: (f, m) => f < m }));
import { MemoryRouter } from "react-router-dom";
import CreatorIgFirstRaw from "./components/signup/CreatorIgFirst";
const CreatorIgFirst = (props) => <MemoryRouter><CreatorIgFirstRaw {...props} /></MemoryRouter>;
import { shortCount } from "./lib/signupPrecheck";

const reply = (preview, account) => (url) => Promise.resolve({ data: url === "instagram/preview" ? preview : url === "public/ig-account" ? account : { ok: true } });

describe("v407 Instagram-first Join screen", () => {
  beforeEach(() => { cleanup(); api.post.mockReset(); vi.useFakeTimers({ shouldAdvanceTime: true }); });

  it("shortCount", () => {
    expect(shortCount(10234)).toBe("10.2K");
    expect(shortCount(1250000)).toBe("1.3M");
    expect(shortCount(812)).toBe("812");
  });

  it("fetches after typing stops and shows name + followers; Continue passes that result", async () => {
    api.post.mockImplementation(reply({ stats: { followers: 10234, name: "Elite Ravi" } }, { exists: false }));
    const onPass = vi.fn();
    render(<CreatorIgFirst onPass={onPass} onLogin={() => {}} />);
    fireEvent.change(screen.getByTestId("ig-first-input"), { target: { value: "elite.ravi" } });
    await act(async () => { vi.advanceTimersByTime(1000); });
    await act(async () => {});
    expect(screen.getByTestId("ig-first-found").textContent).toMatch(/YOU QUALIFY.*Elite Ravi.*@elite\.ravi · 10\.2K followers/);
    fireEvent.click(screen.getByTestId("ig-first-continue"));
    await act(async () => {});
    expect(onPass).toHaveBeenCalledWith(expect.objectContaining({ username: "elite.ravi", followers: 10234, state: "ok" }));
    expect(api.post.mock.calls.filter((c) => c[0] === "instagram/preview").length).toBe(1); // no second fetch
  });

  it("username already on Ybex → Log in (no sign-up)", async () => {
    api.post.mockImplementation(reply({ stats: { followers: 9000 } }, { exists: true, email_hint: "r•••@gmail.com" }));
    const onPass = vi.fn(), onLogin = vi.fn();
    render(<CreatorIgFirst onPass={onPass} onLogin={onLogin} />);
    fireEvent.change(screen.getByTestId("ig-first-input"), { target: { value: "ravi" } });
    await act(async () => { vi.advanceTimersByTime(1000); });
    await act(async () => {});
    expect(screen.getByTestId("ig-first-exists").textContent).toMatch(/ALREADY ON YBEX.*r•••@gmail\.com/);
    expect(screen.getByTestId("ig-first-continue").textContent).toMatch(/Log in/);
    fireEvent.click(screen.getByTestId("ig-first-continue"));
    await act(async () => {});
    expect(onLogin).toHaveBeenCalled();
    expect(onPass).not.toHaveBeenCalled();
  });
});

describe("v408 Join screen", () => {
  beforeEach(() => { cleanup(); api.post.mockReset(); vi.useFakeTimers({ shouldAdvanceTime: true }); });

  it("eligible creator is saved as a lead once; under-minimum is not", async () => {
    api.post.mockImplementation(reply({ stats: { followers: 10234, name: "Elite Ravi" } }, { exists: false }));
    render(<CreatorIgFirst onPass={() => {}} onLogin={() => {}} />);
    fireEvent.change(screen.getByTestId("ig-first-input"), { target: { value: "elite.ravi" } });
    await act(async () => { vi.advanceTimersByTime(1000); });
    await act(async () => {});
    expect(api.post.mock.calls.filter((c) => c[0] === "public/ig-lead").length).toBe(1);
    cleanup(); api.post.mockReset();
    api.post.mockImplementation(reply({ stats: { followers: 40 } }, { exists: false }));
    render(<CreatorIgFirst onPass={() => {}} onLogin={() => {}} />);
    fireEvent.change(screen.getByTestId("ig-first-input"), { target: { value: "tiny.one" } });
    await act(async () => { vi.advanceTimersByTime(1000); });
    await act(async () => {});
    expect(screen.getByTestId("ig-first-continue").textContent).toMatch(/Share my best work/);
    expect(api.post.mock.calls.filter((c) => c[0] === "public/ig-lead").length).toBe(0);
  });

  it("new Google account kept: red note, then the account is made with it after the check", async () => {
    api.post.mockImplementation((url) => url === "auth/oauth/pending/complete" ? Promise.resolve({ data: { token: "T1", role: "creator" } }) : reply({ stats: { followers: 9000, name: "Neha" } }, { exists: false })(url));
    render(<CreatorIgFirst onPass={() => {}} onLogin={() => {}} onGoogle={() => {}} googlePending={{ id: "a".repeat(32), email: "neha@gmail.com" }} />);
    expect(screen.getByTestId("ig-first-google-note").textContent).toMatch(/NO ACCOUNT YET.*neha@gmail\.com/);
    expect(screen.queryByTestId("ig-first-google")).toBeNull();
    fireEvent.change(screen.getByTestId("ig-first-input"), { target: { value: "neha.cooks" } });
    await act(async () => { vi.advanceTimersByTime(1000); });
    await act(async () => {});
    fireEvent.click(screen.getByTestId("ig-first-continue"));
    await act(async () => {});
    expect(api.post).toHaveBeenCalledWith("auth/oauth/pending/complete", { pending: "a".repeat(32), instagram: "neha.cooks" });
  });

  it("Why? opens the sheet; Continue with Google is under Continue", () => {
    render(<CreatorIgFirst onPass={() => {}} onLogin={() => {}} onGoogle={() => {}} />);
    expect(screen.getByTestId("ig-first-google").textContent).toMatch(/Continue with Google/);
    fireEvent.click(screen.getByTestId("ig-first-why"));
    expect(screen.getByTestId("ig-first-why-sheet").textContent).toMatch(/never.*password/i);
  });
});
