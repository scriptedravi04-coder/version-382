import { describe, it, expect } from "vitest";
import { getInboxChip, getChatStage } from "./chatStageMap";
import { deriveDealState, isThreadCancelled } from "../dealState";

const ugc = (status, extra = {}) => ({ id: "thread_ugc_1", is_ugc: true, deal_type: "ugc", ugc_order: { id: "ugcord_1", status }, ...extra });

describe("v359 · locked chat chips (Ravi OK)", () => {
  it("brand: creator declined UGC changes / link change → needs action, 'your call'", () => {
    for (const st of ["REVISION_DECLINED", "REVISION_DECLINED_LINKS"]) {
      const t = ugc(st, { flow_state: st });
      const brand = getInboxChip(t, true);
      expect(brand.needsAction).toBe(true);
      expect(brand.label).toBe("Creator declined · your call");
      expect(getInboxChip(t, false).label).toBe("You declined");
    }
  });
  it("campaign: creator declined the changes → brand's turn", () => {
    const t = { id: "t1", status: "REVISION_DECLINED", flow_state: "CHANGES_DECLINED", agreement_signed_brand: true, agreement_signed_creator: true, payment_funded: true };
    const chip = getInboxChip(t, true);
    expect(chip.key).toBe("changes_declined");
    expect(chip.needsAction).toBe(true);
  });
  it("cancelled / expired / refunded orders: grey chip, never 'In production', never needs action", () => {
    const c = getInboxChip(ugc("CANCELLED"), true);
    expect(c.label).toBe("Cancelled");
    expect(c.needsAction).toBe(false);
    expect(getInboxChip(ugc("REFUNDED"), true).label).toBe("Refunded");
    expect(getInboxChip(ugc("EXPIRED"), false).label).toBe("Expired");
    expect(getInboxChip({ id: "t2", status: "CANCELLED", flow_state: "ESCROW_HELD" }, true).label).toBe("Cancelled");
    const stage = getChatStage({ thread: ugc("CANCELLED"), isBrand: true, isUgcOrder: true });
    expect(stage.key).toBe("cancelled");
    expect(stage.action).toBeNull();
  });
  it("deriveDealState flags cancelled, but never a completed deal", () => {
    expect(deriveDealState({ thread: ugc("CANCELLED"), messages: [], isBrand: true }).isCancelled).toBe(true);
    expect(deriveDealState({ thread: ugc("IN_PROGRESS"), messages: [], isBrand: true }).isCancelled).toBe(false);
    expect(deriveDealState({ thread: { id: "t", status: "COMPLETED", deal: { status: "CANCELLED" } }, messages: [], isBrand: true }).isCancelled).toBe(false);
    expect(isThreadCancelled({ status: "ACTIVE" })).toBe(false);
  });
});
