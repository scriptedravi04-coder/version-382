// v377 (Ravi, "Diwali Challenge v2: Easy Entry"): "Add your Diwali reel" — any reel, no brand question, toggle ON.
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import React from "react";
import { render, screen, fireEvent, act, cleanup, waitFor } from "@testing-library/react";

const state = vi.hoisted(() => ({ stampCalls: [], me: null }));
vi.mock("../../lib/challengeApi", () => ({
  getMyChallenge: vi.fn(async () => state.me),
  stampEntries: vi.fn(async (items, handle) => { state.stampCalls.push({ items, handle }); return Object.fromEntries(items.map((i) => [i.id, { challenge: "diwali2026", challenge_at: "t", challenge_sig: "s" }])); }),
}));
vi.mock("./portfolioApi", () => ({
  previewLink: vi.fn(async () => ({ id: "777", cover: "https://img/c.jpg", views: 900, likes: 40, caption: "dance", brand: "" })),
  copyCovers: vi.fn(async () => ({})), uploadFile: vi.fn(), videoCoverBlob: vi.fn(), fetchIgMedia: vi.fn(async () => []),
}));
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn() }) }));

import AddCollabsScreen from "./AddCollabsScreen";
import { STARTS_AT } from "../../lib/diwaliChallenge";

beforeEach(() => { vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(STARTS_AT + 86400_000)); state.stampCalls = []; state.me = { phase: "open", is_creator: true, eligible: true, left: 3, need_handle: false }; });
afterEach(() => { cleanup(); vi.useRealTimers(); });

describe("v377 · Add your Diwali reel", () => {
  it("any reel: paste link → Submit entry → stamped and saved without the brand sheet", async () => {
    const onSave = vi.fn(async () => true);
    render(<AddCollabsScreen diwali handle="" existing={[]} renderPicker={() => null} onClose={() => {}} onSave={onSave} />);
    await act(async () => {});
    expect(screen.getByText("Add your Diwali reel")).toBeTruthy();
    expect(screen.getByTestId("diwali-rule").textContent).toMatch(/Any reel of your own works.*@ybex\.in \+ #Ybex #YbexDiwaliChallenge/);
    expect(screen.getByTestId("diwali-toggle").querySelector('input[type="checkbox"]').checked).toBe(true);
    expect(screen.queryByText("Upload")).toBeNull(); // an entry must be an Instagram link
    fireEvent.change(screen.getByLabelText("Reel link"), { target: { value: "https://www.instagram.com/reel/DANCE01/" } });
    await waitFor(() => expect(screen.getByText("Add this reel").closest("button").disabled).toBe(false), { timeout: 3000 });
    fireEvent.click(screen.getByText("Add this reel"));
    fireEvent.click(screen.getByText("Submit entry"));
    await waitFor(() => expect(onSave).toHaveBeenCalled());
    expect(screen.queryByTestId("tag-brand-sheet")).toBeNull();
    expect(state.stampCalls).toHaveLength(1);
    const [items, info] = onSave.mock.calls[0];
    expect(items[0]).toMatchObject({ brand_name: "Diwali Challenge", challenge: "diwali2026" });
    expect(info.entered).toHaveLength(1);
  });
  it("toggle off → saved to the portfolio only (no stamp)", async () => {
    const onSave = vi.fn(async () => true);
    render(<AddCollabsScreen diwali handle="" existing={[]} renderPicker={() => null} onClose={() => {}} onSave={onSave} />);
    await act(async () => {});
    fireEvent.click(screen.getByLabelText("Submit to Diwali Challenge"));
    fireEvent.change(screen.getByLabelText("Reel link"), { target: { value: "https://www.instagram.com/reel/DANCE02/" } });
    await waitFor(() => expect(screen.getByText("Add this reel").closest("button").disabled).toBe(false), { timeout: 3000 });
    fireEvent.click(screen.getByText("Add this reel"));
    fireEvent.click(screen.getByText("Save reel"));
    await waitFor(() => expect(onSave).toHaveBeenCalled());
    expect(state.stampCalls).toHaveLength(0);
    expect(onSave.mock.calls[0][1].entered).toHaveLength(0);
  });
});
