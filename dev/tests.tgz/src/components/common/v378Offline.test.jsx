// v378: no internet → Ravi's offline page (with the mini game); maintenance / server down → his maintenance page.
import React from "react";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import fs from "fs";
import path from "path";
import OfflineBanner, { YbexDownPage } from "./OfflineBanner";
import { maintenanceBackText } from "../../App";

afterEach(() => { cleanup(); vi.restoreAllMocks(); });
const page = fs.readFileSync(path.join(__dirname, "ybexDownPage.html"), "utf8");

describe("v378 offline / maintenance page", () => {
  it("phone offline → full-screen offline page (iframe with the design)", () => {
    vi.spyOn(window.navigator, "onLine", "get").mockReturnValue(false);
    render(<OfflineBanner />);
    const box = screen.getByTestId("no-internet-screen");
    const doc = box.querySelector("iframe").getAttribute("srcdoc");
    expect(doc).toContain('"mode":"offline"');
    expect(doc).toContain("You seem to be offline");
  });
  it("online → nothing shown", () => {
    vi.spyOn(window.navigator, "onLine", "get").mockReturnValue(true);
    render(<OfflineBanner />);
    expect(screen.queryByTestId("no-internet-screen")).toBeNull();
    expect(screen.queryByTestId("maintenance-screen")).toBeNull();
  });
  it("maintenance page gets side + back time", () => {
    render(<YbexDownPage mode="maintenance" side="brand" back="by 4:30 PM IST" />);
    const doc = screen.getByTestId("maintenance-screen").querySelector("iframe").getAttribute("srcdoc");
    expect(doc).toContain('"side":"brand"'); expect(doc).toContain("by 4:30 PM IST");
  });
  it("the page is self-contained: game, both modes, no outside files", () => {
    expect(page).toContain("Ybex is under maintenance");
    expect(page).toContain("You seem to be offline");
    expect(page).toContain("Deal Drop"); expect(page).toContain("Creator Drop");
    expect(page).not.toMatch(/<script[^>]+src=|<link[^>]+href=\"http/);
  });
  it("Back … line: auto-off time, else 1 hour after switching on, else 'in some time'", () => {
    const now = Date.parse("2026-10-27T10:00:00Z"); // 3:30 PM IST
    expect(maintenanceBackText({ creator_until: "2026-10-27T11:00:00Z" }, "creator", now)).toBe("by 4:30 PM IST");
    expect(maintenanceBackText({ enabled_at: "2026-10-27T09:30:00Z" }, "creator", now)).toBe("by 4:00 PM IST");
    expect(maintenanceBackText({ enabled_at: "2026-10-27T08:00:00Z" }, "creator", now)).toBe("in some time");
    expect(maintenanceBackText(null, "brand", now)).toBe("in some time");
  });
  it("worker carries the same page and answers with it when the server is down", () => {
    const w = fs.readFileSync(path.join(__dirname, "../../../cloudflare/ybex-proxy-worker.js"), "utf8");
    expect(w).toContain("const DOWN_PAGE = ");
    expect(w).toContain("return downAnswer(request, original);");
  });
});
