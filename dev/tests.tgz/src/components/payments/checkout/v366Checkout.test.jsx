// v366 (Ravi: "ye Review & pay bekar hai — Checkout.dc.html jaisa banao" + "updated logos ki file"). Ravi's checkout, rendered
// with a stubbed api: amounts from the server quote, the app the brand taps reaches Razorpay, 02 Cancel, 04 success.
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import React from "react";
import fs from "fs";
import { render, screen, cleanup, fireEvent, waitFor, act } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
const apiMock = vi.hoisted(() => ({ get: vi.fn(), post: vi.fn(), put: vi.fn() }));
vi.mock("../../../lib/api", () => ({ api: apiMock }));
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() }) }));
import MobileEscrowSheet from "../../chat/mobile/MobileEscrowSheet";
import CheckoutPicker from "./CheckoutPicker";
import { CheckoutSuccess, CheckoutHandoff, receiptFromPayment } from "./CheckoutScreens";
import { parseMethodChoice, choiceLabel, razorpayDisplayConfig, UPI_APPS } from "./checkoutMethods";
import PaymentLogo, { PAYMENT_KEYS, paymentKeyOf, paymentLogoUri } from "../../common/PaymentLogo";
import { PAYMENT_SVGS } from "../../common/paymentLogoSvgs";
import SocialLogo, { SOCIAL_PLATFORMS } from "../../common/SocialLogo";
import { processRazorpayPayment } from "../../../lib/razorpay";

const quote = (o = {}) => ({ feeModel: "split", gross: 10000, brandFeeBasePercent: 8, brandFeePercent: 8, brandFee: 800, brandFeeGst: 0, couponCode: null, couponDiscount: 0, total: 10800, creatorNet: 10000, creatorFeePercent: 0, ...o });
const txt = () => document.body.textContent.replace(/\s+/g, " ");
const sheet = (props = {}) => render(<MemoryRouter><MobileEscrowSheet amount={10000} isBrand isFunded={false} dealId="d1" threadId="t1" partnerName="Riya" campaignTitle="Diwali drop" onClose={() => {}} {...props} /></MemoryRouter>);

beforeEach(() => { cleanup(); apiMock.get.mockReset(); apiMock.post.mockReset(); apiMock.get.mockResolvedValue({ data: {} }); });

describe("v366 · checkout choices (pure)", () => {
  it("one choice string carries app / flow", () => {
    expect(parseMethodChoice("upi")).toEqual({ method: "upi", app: null, flow: null });
    expect(parseMethodChoice("upi:phonepe")).toEqual({ method: "upi", app: "phonepe", flow: "intent" });
    expect(parseMethodChoice("upi:collect")).toEqual({ method: "upi", app: null, flow: "collect" });
    expect(parseMethodChoice("card")).toEqual({ method: "card", app: null, flow: null });
    expect(parseMethodChoice("upi:nope")).toEqual({ method: "upi", app: null, flow: null });
    expect(parseMethodChoice("")).toEqual({ method: "", app: null, flow: null });
    expect(["upi", "upi:phonepe", "upi:gpay", "upi:collect", "card", "netbanking"].map(choiceLabel)).toEqual(["UPI", "PhonePe", "Google Pay", "UPI ID", "card", "net banking"]);
  });
  it("Razorpay display block opens on the picked app, Razorpay's own list kept below", () => {
    expect(razorpayDisplayConfig("upi")).toBeNull();
    expect(razorpayDisplayConfig("")).toBeNull();
    for (const a of UPI_APPS) {
      const c = razorpayDisplayConfig(`upi:${a.id}`);
      expect(c.display.blocks.ybex.instruments).toEqual([{ method: "upi", flows: ["intent", "qr", "collect"], apps: [a.razorpay] }]);
      expect(c.display.sequence).toEqual(["block.ybex"]);
      expect(c.display.preferences.show_default_blocks).toBe(true);
    }
    expect(razorpayDisplayConfig("upi:collect").display.blocks.ybex.instruments).toEqual([{ method: "upi", flows: ["collect"] }]);
    expect(razorpayDisplayConfig("card").display.blocks.ybex.instruments).toEqual([{ method: "card" }]);
    expect(razorpayDisplayConfig("netbanking").display.blocks.ybex.instruments).toEqual([{ method: "netbanking" }]);
  });
});

describe("v366 · logos", () => {
  it("all 11 payment marks are Ravi's real SVGs and render as offline images", () => {
    expect(PAYMENT_KEYS.sort()).toEqual(["amazonpay", "amex", "bhim", "gpay", "mastercard", "paytm", "phonepe", "razorpay", "rupay", "upi", "visa"]);
    for (const k of PAYMENT_KEYS) {
      expect(PAYMENT_SVGS[k], k).toMatch(/^<svg[\s\S]*<\/svg>\s*$/);
      expect(paymentLogoUri(k)).toMatch(/^data:image\/svg\+xml;charset=utf-8,/);
      cleanup();
      const { container } = render(<PaymentLogo name={k} height={18} />);
      const img = container.querySelector("img");
      expect(img.getAttribute("data-payment-logo")).toBe(k);
      expect(img.getAttribute("src").startsWith("data:image/svg+xml")).toBe(true);
      expect(img.style.height).toBe("18px");
    }
  });
  it("names map to keys; unknown names render nothing", () => {
    expect(["Google Pay", "google_pay", "GPay", "PhonePe", "amazon_pay", "Amazon Pay", "RuPay", "American Express", "Mastercard", "VISA", "BHIM", "paytm", "Razorpay", "UPI"].map(paymentKeyOf))
      .toEqual(["gpay", "gpay", "gpay", "phonepe", "amazonpay", "amazonpay", "rupay", "amex", "mastercard", "visa", "bhim", "paytm", "razorpay", "upi"]);
    expect(paymentKeyOf("cash")).toBeNull();
    const { container } = render(<PaymentLogo name="cash" />);
    expect(container.innerHTML).toBe("");
  });
  it("every social platform renders a mark; Instagram has the new file's edge highlight + glyph shadow", () => {
    for (const p of SOCIAL_PLATFORMS) {
      cleanup();
      const { container } = render(<SocialLogo platform={p} size={24} />);
      expect(container.querySelector("svg"), p).toBeTruthy();
    }
    cleanup();
    const { container } = render(<SocialLogo platform="instagram" size={24} />);
    expect(container.querySelector('rect[stroke-width="6"]')).toBeTruthy();
    expect(container.querySelector("filter")).toBeTruthy();
  });
  it("no logo is drawn by hand: no hand-made /pay-logos folder is needed any more", () => {
    expect(fs.readFileSync("src/components/chat/mobile/MobileEscrowSheet.jsx", "utf8")).not.toContain("/pay-logos/");
  });
});

describe("v366 · 01 Review & pay", () => {
  it("You pay / Deal amount / Service fee (8%) come from the server quote; tiles + other ways are shown", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    sheet({ onPay: vi.fn() });
    await waitFor(() => expect(screen.getByTestId("checkout-total").textContent).toBe("₹10,800"));
    expect(screen.getByTestId("fee-deal-amount").textContent).toContain("₹10,000");
    expect(screen.getByTestId("fee-service").textContent).toMatch(/Service fee \(8%\).*₹800/);
    expect(screen.queryByTestId("fee-total")).toBeNull(); // the total is the big "You pay"
    expect(screen.getByTestId("fee-coupon-open").textContent).toContain("Apply coupon");
    expect(apiMock.post).toHaveBeenCalledWith("payments/quote", expect.objectContaining({ deal_id: "d1", thread_id: "t1" }));
    for (const id of ["gpay", "phonepe", "paytm", "bhim", "amazonpay", "collect"]) expect(screen.getByTestId(`pay-app-${id}`)).toBeTruthy();
    expect(screen.getByTestId("pay-method-card").querySelectorAll("[data-payment-logo]").length).toBe(4);
    expect(screen.getByTestId("pay-method-netbanking").textContent).toContain("Net banking");
    expect(txt()).toContain("PAY WITH UPI · INSTANT");
    expect(txt()).toContain("OTHER WAYS");
    expect(screen.getByTestId("checkout-trust").textContent).toMatch(/Payments secured by.*PCI DSS/);
  });
  it("tapping PhonePe highlights it and the button reads 'Pay ₹10,800 | via PhonePe'; card → 'via card'", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    sheet({ onPay: vi.fn() });
    await waitFor(() => expect(screen.getByTestId("escrow-pay").textContent).toMatch(/Pay ₹10,800\s*via UPI/));
    fireEvent.click(screen.getByTestId("pay-app-phonepe"));
    expect(screen.getByTestId("pay-app-phonepe").getAttribute("aria-checked")).toBe("true");
    expect(screen.getByTestId("pay-app-gpay").getAttribute("aria-checked")).toBe("false");
    expect(screen.getByTestId("escrow-pay").textContent).toMatch(/Pay ₹10,800\s*via PhonePe/);
    fireEvent.click(screen.getByTestId("pay-method-card"));
    expect(screen.getByTestId("pay-app-phonepe").getAttribute("aria-checked")).toBe("false");
    expect(screen.getByTestId("escrow-pay").textContent).toMatch(/via card/);
    fireEvent.click(screen.getByTestId("pay-app-collect"));
    expect(screen.getByTestId("escrow-pay").textContent).toMatch(/via UPI ID/);
  });
  it("a coupon re-quotes the big number and the button", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } })
      .mockResolvedValueOnce({ data: { quote: quote({ couponCode: "DIWALI4", brandFeePercent: 4, couponDiscount: 400, total: 10400 }) } });
    const onPay = vi.fn().mockResolvedValue(false);
    sheet({ onPay });
    fireEvent.click(await screen.findByTestId("fee-coupon-open"));
    fireEvent.change(screen.getByTestId("fee-coupon-input"), { target: { value: "DIWALI4" } });
    fireEvent.click(screen.getByTestId("fee-coupon-apply"));
    await waitFor(() => expect(screen.getByTestId("checkout-total").textContent).toBe("₹10,400"));
    expect(screen.getByTestId("fee-coupon").textContent).toMatch(/DIWALI4 applied: 4%.*−₹400/);
    fireEvent.click(screen.getByTestId("pay-app-gpay"));
    fireEvent.click(screen.getByTestId("escrow-pay"));
    await waitFor(() => expect(onPay).toHaveBeenCalledWith("upi:gpay", "DIWALI4", expect.objectContaining({ cancel: expect.any(Object) })));
  });
});

describe("v366 · 02 handoff → 04 escrow funded", () => {
  it("while paying: 'Opening secure checkout' with payee / method / amount; Razorpay opening flips the text", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    let hooks = null; let resolve;
    const onPay = vi.fn((m, c, h) => { hooks = h; return new Promise((r) => { resolve = r; }); });
    sheet({ onPay });
    await waitFor(() => expect(screen.getByTestId("checkout-total").textContent).toBe("₹10,800"));
    fireEvent.click(screen.getByTestId("pay-app-phonepe"));
    fireEvent.click(screen.getByTestId("escrow-pay"));
    expect(await screen.findByTestId("checkout-handoff")).toBeTruthy();
    expect(txt()).toContain("Opening secure checkout");
    expect(screen.getByTestId("handoff-payee").textContent).toContain("Riya");
    expect(screen.getByTestId("handoff-method").textContent).toContain("PhonePe");
    expect(screen.getByTestId("handoff-amount").textContent).toContain("₹10,800");
    act(() => hooks.onOpen());
    expect(txt()).toContain("Finish in Razorpay");
    await act(async () => resolve({ ok: true, payment_id: "pay_Q9xYz123", order_id: "order_1", gross_amount: 10000 }));
    const paid = await screen.findByTestId("escrow-paid");
    expect(paid.textContent).toContain("Escrow funded");
    expect(screen.getByTestId("success-amount").textContent).toBe("₹10,800");
    expect(screen.getByTestId("success-method").textContent).toContain("PhonePe");
    expect(screen.getByTestId("success-payment-id").textContent).toContain("pay_Q9xYz123");
    expect(screen.getByTestId("success-date").textContent).not.toContain("—");
    expect(txt()).toContain("WHAT HAPPENS NEXT");
    expect(screen.getByTestId("success-done").textContent).toContain("Go to deal");
    fireEvent.click(screen.getByTestId("success-receipt"));
    expect(await screen.findByText("PAYMENT RECEIPT")).toBeTruthy(); // the existing InvoiceModal
    expect(txt()).toMatch(/Total Billed Amount:\s*₹10,800\.00/);
  });
  it("Cancel on 02 → back on Review & pay, the cancel flag reaches Razorpay, no 'didn't go through' screen", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    let hooks = null; let resolve;
    const onPay = vi.fn((m, c, h) => { hooks = h; return new Promise((r) => { resolve = r; }); });
    sheet({ onPay });
    await waitFor(() => expect(screen.getByTestId("checkout-total").textContent).toBe("₹10,800"));
    fireEvent.click(screen.getByTestId("escrow-pay"));
    fireEvent.click(await screen.findByTestId("checkout-cancel"));
    expect(hooks.cancel.cancelled).toBe(true);
    expect(screen.queryByTestId("checkout-handoff")).toBeNull();
    expect(screen.getByTestId("escrow-pay")).toBeTruthy();
    await act(async () => resolve(false));
    expect(screen.queryByTestId("escrow-failed")).toBeNull();
    expect(screen.getByTestId("escrow-pay")).toBeTruthy();
  });
  it("a failed payment still shows 'didn't go through' with Try again", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    sheet({ onPay: vi.fn().mockResolvedValue(false) });
    await waitFor(() => expect(screen.getByTestId("checkout-total").textContent).toBe("₹10,800"));
    fireEvent.click(screen.getByTestId("escrow-pay"));
    expect(await screen.findByTestId("escrow-failed")).toBeTruthy();
    expect(txt()).toContain("Try again · ₹10,800");
  });
  it("old callers that return just `true` still land on 04 (Razorpay ID shown later)", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    sheet({ onPay: vi.fn().mockResolvedValue(true) });
    await waitFor(() => expect(screen.getByTestId("checkout-total").textContent).toBe("₹10,800"));
    fireEvent.click(screen.getByTestId("escrow-pay"));
    expect((await screen.findByTestId("success-payment-id")).textContent).toContain("Shown in Payments shortly");
  });
  it("receipt is built from the quote + Razorpay's answer", () => {
    const r = receiptFromPayment({ payment: { payment_id: "pay_1", gross_amount: 10000 }, quote: quote({ couponCode: "DIWALI4", brandFeePercent: 4, brandFee: 400, total: 10400 }), total: 10400, campaignTitle: "Diwali drop", paidAt: "2026-10-21T10:00:00Z" });
    expect(r).toMatchObject({ id: "pay_1", gross_amount: 10000, creator_net_amount: 10000, platform_fee_amount: 0, brand_fee_pct: 4, brand_fee_amount: 400, brand_paid_amount: 10400, coupon_code: "DIWALI4", campaign_title: "Diwali drop" });
  });
});

describe("v366 · Razorpay gets the chosen method", () => {
  let created;
  const orderOk = { data: { order_id: "order_X", key_id: "rzp_live_k", amount: 1080000, currency: "INR" } };
  beforeEach(() => {
    created = [];
    window.Razorpay = vi.fn(function (opts) { created.push(opts); this.on = vi.fn(); this.open = vi.fn(() => { setTimeout(() => opts.modal.ondismiss(), 0); }); });
    apiMock.post.mockImplementation((url) => (url === "payments/razorpay/create-order" ? Promise.resolve(orderOk) : Promise.resolve({ data: { paid: false } })));
  });
  afterEach(() => { delete window.Razorpay; });

  it("PhonePe → prefill.method 'upi' + a display block for the phonepe app; onOpen fires", async () => {
    const onOpen = vi.fn();
    await processRazorpayPayment({ dealId: "d1", grossAmount: 10000, method: "upi:phonepe", quiet: true, onOpen, onError: () => {} });
    expect(created).toHaveLength(1);
    expect(created[0].prefill.method).toBe("upi");
    expect(created[0].config.display.blocks.ybex.instruments[0]).toEqual({ method: "upi", flows: ["intent", "qr", "collect"], apps: ["phonepe"] });
    expect(created[0].config.display.preferences.show_default_blocks).toBe(true);
    expect(onOpen).toHaveBeenCalled();
    expect(apiMock.post).toHaveBeenCalledWith("payments/razorpay/create-order", expect.objectContaining({ deal_id: "d1", gross_amount: 10000 }));
  });
  it("Enter UPI ID → collect flow; card / net banking → their own block; plain 'upi' → no block (as before)", async () => {
    await processRazorpayPayment({ dealId: "d1", grossAmount: 10000, method: "upi:collect", quiet: true, onError: () => {} });
    await processRazorpayPayment({ dealId: "d1", grossAmount: 10000, method: "card", quiet: true, onError: () => {} });
    await processRazorpayPayment({ dealId: "d1", grossAmount: 10000, method: "upi", quiet: true, onError: () => {} });
    expect(created[0].config.display.blocks.ybex.instruments).toEqual([{ method: "upi", flows: ["collect"] }]);
    expect(created[0].prefill.method).toBe("upi");
    expect(created[1].prefill.method).toBe("card");
    expect(created[1].config.display.blocks.ybex.instruments).toEqual([{ method: "card" }]);
    expect(created[2].prefill.method).toBe("upi");
    expect(created[2].config).toBeUndefined();
  });
  it("Razorpay refusing the block → the normal sheet opens without it", async () => {
    window.Razorpay = vi.fn(function (opts) { if (opts.config) throw new Error("invalid app"); created.push(opts); this.on = vi.fn(); this.open = vi.fn(() => { setTimeout(() => opts.modal.ondismiss(), 0); }); });
    await processRazorpayPayment({ dealId: "d1", grossAmount: 10000, method: "upi:amazonpay", quiet: true, onError: () => {} });
    expect(created).toHaveLength(1);
    expect(created[0].config).toBeUndefined();
    expect(created[0].prefill.method).toBe("upi");
  });
  it("cancelled before the order came back → Razorpay never opens", async () => {
    const onError = vi.fn();
    await processRazorpayPayment({ dealId: "d1", grossAmount: 10000, method: "upi:gpay", quiet: true, cancel: { cancelled: true }, onError });
    expect(window.Razorpay).not.toHaveBeenCalled();
    expect(onError).toHaveBeenCalledWith(expect.objectContaining({ message: "Payment cancelled" }));
  });
});

describe("v366 · every Review & pay uses the checkout", () => {
  const read = (f) => fs.readFileSync(f, "utf8");
  it("campaign (phone + desktop), UGC (phone + desktop) and PayNow render the picker and pass the method", () => {
    for (const f of ["src/components/chat/mobile/MobileEscrowSheet.jsx", "src/components/chat/chatBox/ChatBoxPaymentSheet.jsx", "src/components/chat/ChatBox.jsx", "src/pages/brand/BrandUGCMobile.jsx", "src/pages/brand/BrandUGCPost.jsx", "src/components/payments/PayNow.jsx"]) {
      const s = read(f);
      expect(s, f).toContain("<CheckoutPicker");
      expect(s, f).toContain('variant="checkout"');
    }
    expect(read("src/components/chat/ChatBox.jsx")).toContain('handleEscrowPayment(payFee.couponCode || "", payMethod)');
    expect(read("src/components/chat/chatBox/ChatBoxPaymentSheet.jsx")).toContain('handleEscrowPayment(fee.couponCode || "", method)');
    expect(read("src/pages/brand/BrandUGCMobile.jsx")).toContain("method: ugcMethod, // v366");
    expect(read("src/pages/brand/BrandUGCPost.jsx")).toContain("method: ugcMethod, // v366");
    expect(read("src/components/payments/PayNow.jsx")).toContain("method, // v366");
  });
  it("standalone pieces render: picker defaults to 'any UPI', handoff Cancel calls back, success without payee", () => {
    const onChange = vi.fn();
    render(<CheckoutPicker value="upi" onChange={onChange} />);
    expect(screen.getAllByRole("radio").filter((r) => r.getAttribute("aria-checked") === "true")).toHaveLength(0);
    fireEvent.click(screen.getByTestId("pay-app-bhim"));
    expect(onChange).toHaveBeenCalledWith("upi:bhim");
    cleanup();
    const onCancel = vi.fn();
    render(<CheckoutHandoff total={500} choice="netbanking" onCancel={onCancel} />);
    expect(screen.getByTestId("handoff-method").textContent).toContain("Net banking");
    fireEvent.click(screen.getByTestId("checkout-cancel"));
    expect(onCancel).toHaveBeenCalled();
    cleanup();
    render(<CheckoutSuccess total={500} choice="card" onDone={() => {}} />);
    expect(screen.getByTestId("success-method").textContent).toContain("Debit / credit card");
    expect(txt()).toContain("The creator gets notified");
  });
});
