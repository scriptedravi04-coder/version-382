// v373: the Diwali opening poster popped up over "Add collabs" right after "Yes, add my reel" on /challenge.
import React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, cleanup, act } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const pub = { now: Date.now(), phase: "open", starts_at: Date.now() - 86400_000, closes_at: Date.now() + 10 * 86400_000, results_at: Date.now() + 12 * 86400_000 };
const getPub = vi.fn(async () => pub);
vi.mock("../../lib/challengeApi", () => ({ getChallengePublic: () => getPub() }));
vi.mock("../../contexts/AuthContext", () => ({ useAuth: () => ({ user: { role: "creator", user_id: "c1" }, loading: false }) }));
import DiwaliEntryScreen from "./DiwaliEntryScreen";
afterEach(() => { cleanup(); sessionStorage.clear(); getPub.mockClear(); });

const mount = (path) => render(<MemoryRouter initialEntries={[path]}><DiwaliEntryScreen /></MemoryRouter>);
const wait = (ms) => act(() => new Promise((r) => setTimeout(r, ms)));

describe("v373 · opening poster", () => {
  it("shows on Home once", async () => {
    const r = mount("/creator/dashboard");
    await wait(600);
    expect(r.queryByTestId("diwali-entry-screen")).toBeTruthy();
  });
  it("after the offer page this session → not over the portfolio", async () => {
    const a = mount("/challenge"); await wait(50); a.unmount();
    const r = mount("/creator/settings");
    await wait(600);
    expect(r.queryByTestId("diwali-entry-screen")).toBeNull();
  });
});
