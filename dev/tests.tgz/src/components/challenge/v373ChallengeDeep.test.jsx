// v373 deep test (Ravi: "deep black box + white box, chote se chota bug fix"): what playing the Diwali Challenge as a
// creator in a real browser turned up — enter a reel already in the portfolio, the username hint, entry slots,
// one shared /challenge/public answer, no opening poster over "Add collabs".
import React from "react";
import { describe, it, expect, vi, afterEach, beforeEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const apiGet = vi.fn();
vi.mock("../../lib/api", () => ({ api: { get: (...a) => apiGet(...a), post: vi.fn() } }));
vi.mock("../../contexts/AuthContext", () => ({ useAuth: () => ({ user: { name: "Ravi K", role: "creator" } }) }));

import TagBrandSheet from "../portfolio/TagBrandSheet";
import { BrandSheet, canEnterExisting } from "../portfolio/PortfolioViews";
import { EntryDoneSheet } from "./ChallengeUi";
import { getChallengePublic, __resetChallengePublic } from "../../lib/challengeApi";

const url = (c) => `https://www.instagram.com/reel/${c}/`;
const open = { phase: "open", is_creator: true, eligible: true, left: 2, entries: [{ content_url: url("ENTERED1") }], sponsor_names: ["Wefrnd"] };
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
beforeEach(() => { apiGet.mockReset(); __resetChallengePublic(); });

describe("v373 · enter a reel that is already in the portfolio", () => {
  it("canEnterExisting: Ybex / sponsor / hashtag reels while open; never twice, never a YouTube link, never when full", () => {
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Ybex" }, open)).toBe(true);
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Wefrnd" }, open)).toBe(true);
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Nykaa", description: "Shot for #YbexDiwaliChallenge" }, open)).toBe(true);
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Nykaa" }, open)).toBe(true); // v377: any reel of their own
    expect(canEnterExisting({ content_url: url("ENTERED1"), brand_name: "Ybex" }, open)).toBe(false);
    expect(canEnterExisting({ content_url: "https://youtu.be/abcdefg", brand_name: "Ybex" }, open)).toBe(false);
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Ybex" }, { ...open, left: 0 })).toBe(false);
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Ybex" }, { ...open, phase: "judging" })).toBe(false);
    expect(canEnterExisting({ content_url: url("NEWREEL1"), brand_name: "Ybex", challenge: "diwali2026", challenge_at: "x", challenge_sig: "y" }, open)).toBe(false);
  });
  it("brand sheet: Enter → asks the username when the profile has none → onEnter(item, handle)", async () => {
    const onEnter = vi.fn(async () => true);
    const item = { id: "pf_1", content_url: url("NEWREEL1"), brand_name: "Ybex", platform: "instagram" };
    render(<BrandSheet group={{ key: "ybex", brand: "Ybex", items: [item] }} onClose={() => {}} onRename={() => {}} onRemove={() => {}} challenge={{ ...open, need_handle: true }} onEnter={onEnter} />);
    fireEvent.click(screen.getByTestId("enter-existing"));
    expect(onEnter).not.toHaveBeenCalled();
    fireEvent.change(screen.getByLabelText("Your Instagram username"), { target: { value: "@ravi.k" } });
    fireEvent.click(screen.getByTestId("enter-handle").querySelector("button"));
    await waitFor(() => expect(onEnter).toHaveBeenCalledWith(item, "ravi.k"));
  });
  it("removing a Diwali entry says it leaves the challenge", () => {
    const confirm = vi.spyOn(window, "confirm").mockReturnValue(false);
    const item = { id: "pf_1", content_url: url("ENTERED1"), brand_name: "Ybex" };
    render(<BrandSheet group={{ key: "ybex", brand: "Ybex", items: [item] }} onClose={() => {}} onRename={() => {}} onRemove={() => {}} challenge={open} />);
    fireEvent.click(screen.getByLabelText("Remove"));
    expect(confirm.mock.calls[0][0]).toMatch(/Diwali Challenge entry/);
  });
});

describe("v373 · small things", () => {
  it("tag sheet says a reel without the username is saved but not entered", () => {
    render(<TagBrandSheet group={{ key: "g", suggested: "Ybex", items: [{ id: "a", content_url: url("AAAAAA1"), source: "link" }] }} onTag={() => {}} onNotCollab={() => {}} onClose={() => {}} challenge={{ ...open, left: 3, need_handle: true }} />);
    expect(screen.getByTestId("need-handle-note").textContent).toMatch(/saved but not entered/);
    expect(screen.getByText("Pasted link")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Your Instagram username"), { target: { value: "ravi" } });
    expect(screen.queryByTestId("need-handle-note")).toBeNull();
  });
  it("entry slots: the count shows once", () => {
    render(<MemoryRouter><EntryDoneSheet entries={[{ item_id: "a", no: 4 }]} all={[{ item_id: "a", no: 4 }]} left={2} onClose={() => {}} /></MemoryRouter>);
    const t = screen.getByTestId("entry-slots").textContent;
    expect(t.match(/2 left/g)).toHaveLength(1);
    expect(t).toContain("Open");
  });
  it("/challenge/public: one request for screens opening together; server time keeps moving", async () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    vi.setSystemTime(new Date(1_000_000));
    apiGet.mockResolvedValue({ data: { now: 5_000_000, phase: "open" } });
    const [a, b] = await Promise.all([getChallengePublic(), getChallengePublic()]);
    expect(apiGet).toHaveBeenCalledTimes(1);
    expect(a.now).toBe(5_000_000); expect(b.phase).toBe("open");
    vi.setSystemTime(new Date(1_010_000));
    expect((await getChallengePublic()).now).toBe(5_010_000);
    expect(apiGet).toHaveBeenCalledTimes(1);
    vi.setSystemTime(new Date(1_030_000));
    await getChallengePublic();
    expect(apiGet).toHaveBeenCalledTimes(2);
    vi.useRealTimers();
  });
});
