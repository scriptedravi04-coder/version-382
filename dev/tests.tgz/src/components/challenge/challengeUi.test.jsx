import React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import TagBrandSheet from "../portfolio/TagBrandSheet";
import { EntryDoneSheet, EntryRibbon } from "./ChallengeUi";

const reel = (id, extra = {}) => ({ id, content_url: `https://www.instagram.com/reel/${id}ABCDE/`, cover: "", ...extra });
const group = (items, suggested = "") => ({ key: "g", suggested, items });
afterEach(() => cleanup());
const ok = { onboarded: true, left: 3, phase: "open", is_creator: true };

describe("v367 · Submit to Diwali Challenge toggle", () => {
  it("shows (ON) for brand Ybex and sends enter=true", () => {
    const onTag = vi.fn();
    render(<TagBrandSheet group={group([reel("a")], "Ybex")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={ok} />);
    expect(screen.getByTestId("challenge-toggle")).toBeTruthy();
    fireEvent.click(screen.getByText(/Tag as Ybex & enter/));
    expect(onTag).toHaveBeenCalledWith("Ybex", true, "");
  });
  it("shows for another brand when the caption has the hashtag; can be switched off", () => {
    const onTag = vi.fn();
    render(<TagBrandSheet group={group([reel("a", { challenge_hit: true })], "Nykaa")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={ok} />);
    fireEvent.click(screen.getByLabelText("Submit to Diwali Creator Challenge"));
    fireEvent.click(screen.getByText(/Tag 1 reel as Nykaa/));
    expect(onTag).toHaveBeenCalledWith("Nykaa", false, "");
  });
  it("shown for any reel now (v377: any reel of your own), hidden when entries are closed (no challenge prop)", () => {
    const { rerender } = render(<TagBrandSheet group={group([reel("a")], "Nykaa")} onTag={() => {}} onNotCollab={() => {}} onClose={() => {}} challenge={ok} />);
    expect(screen.queryByTestId("challenge-toggle")).toBeTruthy();
    rerender(<TagBrandSheet group={group([reel("a")], "Ybex")} onTag={() => {}} onNotCollab={() => {}} onClose={() => {}} challenge={null} />);
    expect(screen.queryByTestId("challenge-toggle")).toBeNull();
  });
  it("blocked: not onboarded / not a reel link / no entries left", () => {
    const onTag = vi.fn();
    const { rerender } = render(<TagBrandSheet group={group([reel("a")], "Ybex")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={{ ...ok, onboarded: false }} />);
    expect(screen.getByText(/Add your name and an email or phone number/)).toBeTruthy();
    rerender(<TagBrandSheet group={group([{ id: "u", content_url: "https://ybex.files/x.mp4" }], "Ybex")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={ok} />);
    expect(screen.getByText(/Only an Instagram reel or post link counts/)).toBeTruthy();
    rerender(<TagBrandSheet group={group([reel("a")], "Ybex")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={{ ...ok, left: 0 }} />);
    expect(screen.getByText(/used all 3 entries/)).toBeTruthy();
    fireEvent.click(screen.getByText(/Tag 1 reel as Ybex/));
    expect(onTag).toHaveBeenCalledWith("Ybex", false, "");
  });
});

describe("v367 · entry done sheet + ribbon", () => {
  it("Entry #N is in + share", () => {
    render(<MemoryRouter><EntryDoneSheet entries={[{ item_id: "a", no: 12, cover: "" }]} left={2} onClose={() => {}} /></MemoryRouter>);
    // v377 (Ravi): "Entry done! Results 18 Nov. ₹50 recharge if you're in the first 300 (after approval)." + WhatsApp + dashboard
    expect(screen.getByTestId("entry-done-text").textContent).toMatch(/Entry #12 is in for review\. Results on .*₹300 on UPI if you're among the first 300 creators \(after approval, with a complete profile\)/);
    expect(screen.getByText("Share on WhatsApp")).toBeTruthy();
    expect(screen.getByText("Go to dashboard")).toBeTruthy();
    expect(screen.getByText(/enter 2 more reels/)).toBeTruthy();
  });
  it("ribbon only on stamped items", () => {
    const { container, rerender } = render(<EntryRibbon item={{ challenge: "diwali2026", challenge_at: "x", challenge_sig: "s" }} />);
    expect(container.textContent).toContain("Entry");
    // a typed-in prize never shows on the ribbon (can't be checked in the browser)
    rerender(<EntryRibbon item={{ challenge: "diwali2026", challenge_at: "x", challenge_sig: "s", challenge_rank: "1st" }} />);
    expect(container.textContent).not.toContain("1st prize");
    rerender(<EntryRibbon item={{ challenge: "diwali2026", challenge_at: "x" }} />);
    expect(container.textContent).toBe("");
    rerender(<EntryRibbon item={{ brand_name: "Ybex" }} />);
    expect(container.textContent).toBe("");
  });
});

describe("v368 · a sponsor brand also shows the toggle", () => {
  it("brand typed = a sponsor name", () => {
    render(<TagBrandSheet group={group([reel("a")], "wefrnd")} onTag={() => {}} onNotCollab={() => {}} onClose={() => {}} challenge={{ ...ok, sponsor_names: ["Wefrnd"] }} />);
    expect(screen.getByTestId("challenge-toggle")).toBeTruthy();
  });
});

describe("v371 · Instagram username asked in the toggle when missing", () => {
  it("need_handle → username box; tag sends it", () => {
    const onTag = vi.fn();
    render(<TagBrandSheet group={group([reel("a")], "Ybex")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={{ ...ok, eligible: true, onboarded: false, need_handle: true }} />);
    const box = screen.getByLabelText("Your Instagram username");
    fireEvent.change(box, { target: { value: "@ravi.k" } });
    fireEvent.click(screen.getByText(/Tag as Ybex & enter/));
    expect(onTag).toHaveBeenCalledWith("Ybex", true, "ravi.k");
  });
  it("no username typed → saved without entering", () => {
    const onTag = vi.fn();
    render(<TagBrandSheet group={group([reel("a")], "Ybex")} onTag={onTag} onNotCollab={() => {}} onClose={() => {}} challenge={{ ...ok, eligible: true, need_handle: true }} />);
    fireEvent.click(screen.getByText(/Tag 1 reel as Ybex/));
    expect(onTag).toHaveBeenCalledWith("Ybex", false, "");
  });
});
