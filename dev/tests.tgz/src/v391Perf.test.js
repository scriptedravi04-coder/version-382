import { describe, it, expect } from "vitest";
import fs from "node:fs";

// v391: Speed QA + Mobile/screen-size QA fixes (1 Nov 2026).
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v391 speed", () => {
  it("newspaper slices are not rendered until the paper is in view", () => {
    for (const [v, css] of [["LandingMobileView.jsx", "landingMobile.css"], ["LandingDesktopView.jsx", "landingDesktop.css"]]) {
      expect(read(`./components/landing/v2/${v}`)).toMatch(/className=\{v\.npPlay \? undefined : "np-wait np-off"\}/);
      expect(read(`./components/landing/v2/${v}`)).toMatch(/className="np-slices"/);
      expect(read(`./components/landing/v2/${css}`)).toMatch(/\.np-off \.np-slices\{display:none\}/);
    }
  });
  it("landing images are WebP", () => {
    for (const v of ["LandingMobileView.jsx", "LandingDesktopView.jsx"]) expect(read(`./components/landing/v2/${v}`)).not.toMatch(/landing\/[\w]+\.png/);
  });
  it("popups, Signup and Dashboard are lazy; popups wait for idle", () => {
    const s = read("./App.jsx");
    expect(s).toMatch(/const Dashboard = lazyWithRetry/);
    expect(s).toMatch(/const Signup = lazyWithRetry/);
    expect(s).toMatch(/<Idle><PromoPopup \/><\/Idle>/);
  });
  it("service worker starts after the page has loaded", () => {
    expect(read("./index.jsx")).toMatch(/setTimeout\(startSW, 3000\)/);
  });
});

describe("v391 mobile", () => {
  it("viewport allows pinch-zoom", () => {
    const h = read("../index.html");
    expect(h).toMatch(/<meta name="viewport" content="[^"]*"/);
    expect(h.match(/<meta name="viewport" content="([^"]*)"/)[1]).not.toMatch(/maximum-scale|user-scalable/);
  });
  it("narrow headers keep the menu button on screen", () => {
    expect(read("./components/layout/Layout.jsx")).toMatch(/max-\[359px\]:hidden/);
    expect(read("./components/landing/v2/landingMobile.css")).toMatch(/max-width:339px\)\{\s*\.l-nav-signin\{display:none/);
  });
  it("full-height pages follow the visible height", () => {
    expect(read("./index.css")).toMatch(/\.min-h-screen \{ min-height: 100dvh; \}/);
  });
  it("no tiny Tailwind text on public pages", () => {
    for (const f of ["./pages/ChallengePage.jsx", "./components/app/AppLoginScreen.jsx"]) expect(read(f)).not.toMatch(/text-\[(8|9|10)(\.5)?px\]/);
  });
});

describe("v391 Google sign-in asks which account", () => {
  it("the remembered e-mail (login_hint) is never sent: Google asks which account on every phone", () => {
    const s = read("./pages/app/AppContinue.jsx");
    expect(s).toMatch(/if \(false && provider === "google" && !opts\.chooseAccount\)/);
  });
});

describe("v394 push report", () => {
  it("admin push sends 20 phones at a time and reports browser / Android / iPhone / refused", () => {
    const s = read("../backend/push_routes.ts");
    expect(s).toMatch(/async function sendDetailed/);
    expect(s).toMatch(/slice\(i, i \+ 20\)\.map\(one\)/);
    expect(s).toMatch(/failed: st\.failed, removed: st\.removed/);
    expect(read("./components/admin/PushNotificationsManager.jsx")).toMatch(/Browser \$\{rep\.web \?\? 0\} · Android app/);
  });
});
