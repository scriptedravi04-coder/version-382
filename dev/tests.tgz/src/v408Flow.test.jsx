import { describe, it, expect } from "vitest";
import fs from "node:fs";
import { installPopupAllowed } from "./components/common/PWAInstallPrompt";
import { shouldQuietToast } from "./lib/api";
import { appAuthTarget } from "./lib/standalone";

const read = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v408 QA fixes", () => {
  it("install popup: never on ad pages, never in Instagram's browser, only when signed in", () => {
    for (const p of ["/", "/offer", "/challenge", "/app/continue/creator", "/login"]) expect(installPopupAllowed(p, { hasSession: true })).toBe(false);
    expect(installPopupAllowed("/dashboard", { hasSession: true, inApp: true })).toBe(false);
    expect(installPopupAllowed("/dashboard", { hasSession: false })).toBe(false);
    expect(installPopupAllowed("/dashboard", { hasSession: true })).toBe(true);
  });
  it("/login opens the Log in screen", () => {
    expect(appAuthTarget("", { login: true })).toBe("/app/continue/creator?login=1");
    expect(appAuthTarget("?role=brand", { login: true })).toBe("/app/continue/brand");
    expect(appAuthTarget("")).toBe("/app");
  });
  it("sub-admin: background 403 toasts are quiet for 2.5 s only", () => {
    expect(shouldQuietToast(1000, 2000)).toBe(true);
    expect(shouldQuietToast(3000, 2000)).toBe(false);
  });
  it("welcome has 'Already on Ybex? Log in'; /admin/<anything> opens the panel", () => {
    expect(read("./components/app/AppLoginScreen.jsx")).toMatch(/app-welcome-login-2/);
    expect(read("./App.jsx")).toMatch(/path="\/admin\/\*" element=\{<AdminSubPathToPanel \/>\}/);
  });
  it("join form: Instagram card with Change (no free text box)", () => {
    const s = read("./pages/app/AppContinue.jsx");
    expect(s).toMatch(/app-join-ig-card/);
    expect(s).not.toMatch(/data-testid="app-join-ig"/);
  });
});

describe("v409 new version reaches people who opened Ybex before", () => {
  it("an untouched page loads the new version at once; a page in use waits", () => {
    const s = read("./index.jsx");
    expect(s).toMatch(/if \(!window\.__ybTouched\) applyUpdate\(\);/);
    expect(s).toMatch(/\["pointerdown", "keydown", "input"\]/);
  });
});
