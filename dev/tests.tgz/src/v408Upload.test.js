import { describe, it, expect } from "vitest";
import { needsConvert, uploadErrorText } from "./lib/prepareUpload";

// v408 (Ravi: a creator couldn't finish KYC — the PAN photo never reached the server)
describe("v408 KYC photo upload", () => {
  it("HEIC / no type / big photos are turned into JPEG first; PDF and small JPEG go as they are", () => {
    expect(needsConvert({ type: "image/heic", name: "IMG_1.HEIC", size: 2e6 })).toBe(true);
    expect(needsConvert({ type: "", name: "pan.jpg", size: 1e6 })).toBe(true);
    expect(needsConvert({ type: "image/jpeg", name: "pan.jpg", size: 8e6 })).toBe(true);
    expect(needsConvert({ type: "image/jpeg", name: "pan.jpg", size: 1e6 })).toBe(false);
    expect(needsConvert({ type: "application/pdf", name: "pan.pdf", size: 9e6 })).toBe(false);
  });
  it("shows the server's reason", () => {
    expect(uploadErrorText({ response: { data: { detail: "This file is too large (max 100 MB)." } } })).toMatch(/too large/);
    expect(uploadErrorText({})).toMatch(/Couldn't upload/);
  });
});
